; ModuleID = 'kernel.c'
source_filename = "kernel.c"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

%struct.Surf = type { i32, [0 x i16] }

@kernel = dso_local alias i32 (ptr, i32, i32), ptr @checked_shadow

; Function Attrs: noinline nounwind
define internal i32 @checked_shadow(ptr noundef %ctx, i32 noundef %x, i32 noundef %y) #0 {
entry:
  %retval = alloca i32, align 4
  %ctx.addr = alloca ptr, align 4
  %x.addr = alloca i32, align 4
  %y.addr = alloca i32, align 4
  %w = alloca ptr, align 4
  %lx = alloca i32, align 4
  %ly = alloca i32, align 4
  %norm = alloca i32, align 4
  %count = alloca i32, align 4
  %s = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %box = alloca i32, align 4
  %obj = alloca i32, align 4
  %dx = alloca i32, align 4
  %dy = alloca i32, align 4
  %dz = alloca i32, align 4
  %r = alloca i32, align 4
  %dot = alloca i32, align 4
  store ptr %ctx, ptr %ctx.addr, align 4, !tbaa !4
  store i32 %x, ptr %x.addr, align 4, !tbaa !8
  store i32 %y, ptr %y.addr, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %w) #5
  %0 = load ptr, ptr %ctx.addr, align 4, !tbaa !4
  store ptr %0, ptr %w, align 4, !tbaa !4
  call void @llvm.lifetime.start.p0(i64 4, ptr %lx) #5
  %1 = load ptr, ptr %w, align 4, !tbaa !4
  %call = call i32 @checked_read(ptr noundef %1, i32 noundef 17) #6
  %sub = sub i32 %call, 32
  store i32 %sub, ptr %lx, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %ly) #5
  %2 = load ptr, ptr %w, align 4, !tbaa !4
  %call1 = call i32 @checked_read(ptr noundef %2, i32 noundef 18) #6
  %sub2 = sub i32 %call1, 32
  store i32 %sub2, ptr %ly, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %norm) #5
  %3 = load ptr, ptr %w, align 4, !tbaa !4
  %call3 = call i32 @checked_read(ptr noundef %3, i32 noundef 19) #6
  store i32 %call3, ptr %norm, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %count) #5
  %4 = load ptr, ptr %w, align 4, !tbaa !4
  %call4 = call i32 @checked_read(ptr noundef %4, i32 noundef 16) #6
  store i32 %call4, ptr %count, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #5
  store i32 0, ptr %s, align 4, !tbaa !8
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %entry
  %5 = load i32, ptr %s, align 4, !tbaa !8
  %6 = load i32, ptr %count, align 4, !tbaa !8
  %cmp = icmp slt i32 %5, %6
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  br label %cleanup56

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %box) #5
  %7 = load i32, ptr %s, align 4, !tbaa !8
  %mul = mul i32 4, %7
  %add = add i32 21, %mul
  store i32 %add, ptr %box, align 4, !tbaa !8
  %8 = load i32, ptr %x.addr, align 4, !tbaa !8
  %mul5 = mul i32 32, %8
  %add6 = add i32 4096, %mul5
  %9 = load ptr, ptr %w, align 4, !tbaa !4
  %10 = load i32, ptr %box, align 4, !tbaa !8
  %call7 = call i32 @checked_read(ptr noundef %9, i32 noundef %10) #6
  %sub8 = sub i32 %add6, %call7
  %11 = call i32 @llvm.abs.i32(i32 %sub8, i1 false)
  %12 = load ptr, ptr %w, align 4, !tbaa !4
  %13 = load i32, ptr %box, align 4, !tbaa !8
  %add9 = add i32 %13, 2
  %call10 = call i32 @checked_read(ptr noundef %12, i32 noundef %add9) #6
  %cmp11 = icmp sgt i32 %11, %call10
  br i1 %cmp11, label %if.then, label %lor.lhs.false

lor.lhs.false:                                    ; preds = %for.body
  %14 = load i32, ptr %y.addr, align 4, !tbaa !8
  %mul12 = mul i32 32, %14
  %add13 = add i32 4096, %mul12
  %15 = load ptr, ptr %w, align 4, !tbaa !4
  %16 = load i32, ptr %box, align 4, !tbaa !8
  %add14 = add i32 %16, 1
  %call15 = call i32 @checked_read(ptr noundef %15, i32 noundef %add14) #6
  %sub16 = sub i32 %add13, %call15
  %17 = call i32 @llvm.abs.i32(i32 %sub16, i1 false)
  %18 = load ptr, ptr %w, align 4, !tbaa !4
  %19 = load i32, ptr %box, align 4, !tbaa !8
  %add17 = add i32 %19, 3
  %call18 = call i32 @checked_read(ptr noundef %18, i32 noundef %add17) #6
  %cmp19 = icmp sgt i32 %17, %call18
  br i1 %cmp19, label %if.then, label %if.end

if.then:                                          ; preds = %lor.lhs.false, %for.body
  store i32 4, ptr %cleanup.dest.slot, align 4
  br label %cleanup55

if.end:                                           ; preds = %lor.lhs.false
  call void @llvm.lifetime.start.p0(i64 4, ptr %obj) #5
  %20 = load i32, ptr %s, align 4, !tbaa !8
  %mul20 = mul i32 5, %20
  %add21 = add i32 1, %mul20
  store i32 %add21, ptr %obj, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %dx) #5
  %21 = load ptr, ptr %w, align 4, !tbaa !4
  %22 = load i32, ptr %obj, align 4, !tbaa !8
  %call22 = call i32 @checked_read(ptr noundef %21, i32 noundef %22) #6
  %23 = load i32, ptr %x.addr, align 4, !tbaa !8
  %sub23 = sub i32 %call22, %23
  store i32 %sub23, ptr %dx, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %dy) #5
  %24 = load ptr, ptr %w, align 4, !tbaa !4
  %25 = load i32, ptr %obj, align 4, !tbaa !8
  %add24 = add i32 %25, 1
  %call25 = call i32 @checked_read(ptr noundef %24, i32 noundef %add24) #6
  %26 = load i32, ptr %y.addr, align 4, !tbaa !8
  %sub26 = sub i32 %call25, %26
  store i32 %sub26, ptr %dy, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %dz) #5
  %27 = load ptr, ptr %w, align 4, !tbaa !4
  %28 = load i32, ptr %obj, align 4, !tbaa !8
  %add27 = add i32 %28, 2
  %call28 = call i32 @checked_read(ptr noundef %27, i32 noundef %add27) #6
  %sub29 = sub i32 156, %call28
  store i32 %sub29, ptr %dz, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %r) #5
  %29 = load ptr, ptr %w, align 4, !tbaa !4
  %30 = load i32, ptr %obj, align 4, !tbaa !8
  %add30 = add i32 %30, 3
  %call31 = call i32 @checked_read(ptr noundef %29, i32 noundef %add30) #6
  store i32 %call31, ptr %r, align 4, !tbaa !8
  call void @llvm.lifetime.start.p0(i64 4, ptr %dot) #5
  %31 = load i32, ptr %dx, align 4, !tbaa !8
  %32 = load i32, ptr %lx, align 4, !tbaa !8
  %mul32 = mul i32 %31, %32
  %33 = load i32, ptr %dy, align 4, !tbaa !8
  %34 = load i32, ptr %ly, align 4, !tbaa !8
  %mul33 = mul i32 %33, %34
  %add34 = add i32 %mul32, %mul33
  %35 = load i32, ptr %dz, align 4, !tbaa !8
  %mul35 = mul i32 32, %35
  %add36 = add i32 %add34, %mul35
  store i32 %add36, ptr %dot, align 4, !tbaa !8
  %36 = load i32, ptr %dot, align 4, !tbaa !8
  %cmp37 = icmp sgt i32 %36, 0
  br i1 %cmp37, label %land.lhs.true, label %if.end49

land.lhs.true:                                    ; preds = %if.end
  %37 = load i32, ptr %dx, align 4, !tbaa !8
  %38 = load i32, ptr %dx, align 4, !tbaa !8
  %mul38 = mul i32 %37, %38
  %39 = load i32, ptr %dy, align 4, !tbaa !8
  %40 = load i32, ptr %dy, align 4, !tbaa !8
  %mul39 = mul i32 %39, %40
  %add40 = add i32 %mul38, %mul39
  %41 = load i32, ptr %dz, align 4, !tbaa !8
  %42 = load i32, ptr %dz, align 4, !tbaa !8
  %mul41 = mul i32 %41, %42
  %add42 = add i32 %add40, %mul41
  %43 = load i32, ptr %r, align 4, !tbaa !8
  %44 = load i32, ptr %r, align 4, !tbaa !8
  %mul43 = mul i32 %43, %44
  %sub44 = sub i32 %add42, %mul43
  %45 = load i32, ptr %norm, align 4, !tbaa !8
  %mul45 = mul i32 %sub44, %45
  %46 = load i32, ptr %dot, align 4, !tbaa !8
  %47 = load i32, ptr %dot, align 4, !tbaa !8
  %mul46 = mul i32 %46, %47
  %cmp47 = icmp sle i32 %mul45, %mul46
  br i1 %cmp47, label %if.then48, label %if.end49

if.then48:                                        ; preds = %land.lhs.true
  store i32 1, ptr %retval, align 4
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup

if.end49:                                         ; preds = %land.lhs.true, %if.end
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup

cleanup:                                          ; preds = %if.end49, %if.then48
  call void @llvm.lifetime.end.p0(i64 4, ptr %dot) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %r) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %dz) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %dy) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %dx) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %obj) #5
  br label %cleanup55

cleanup55:                                        ; preds = %cleanup, %if.then
  call void @llvm.lifetime.end.p0(i64 4, ptr %box) #5
  %cleanup.dest = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest, label %cleanup56 [
    i32 0, label %cleanup.cont
    i32 4, label %for.inc
  ]

cleanup.cont:                                     ; preds = %cleanup55
  br label %for.inc

for.inc:                                          ; preds = %cleanup.cont, %cleanup55
  %48 = load i32, ptr %s, align 4, !tbaa !8
  %inc = add i32 %48, 1
  store i32 %inc, ptr %s, align 4, !tbaa !8
  br label %for.cond, !llvm.loop !10

cleanup56:                                        ; preds = %cleanup55, %for.cond.cleanup
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #5
  %cleanup.dest57 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest57, label %cleanup58 [
    i32 2, label %for.end
  ]

for.end:                                          ; preds = %cleanup56
  store i32 0, ptr %retval, align 4
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup58

cleanup58:                                        ; preds = %for.end, %cleanup56
  call void @llvm.lifetime.end.p0(i64 4, ptr %count) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %norm) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %ly) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %lx) #5
  call void @llvm.lifetime.end.p0(i64 4, ptr %w) #5
  %49 = load i32, ptr %retval, align 4
  ret i32 %49
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: inlinehint nounwind
define internal i32 @checked_read(ptr noundef %w, i32 noundef %i) #2 {
entry:
  %w.addr = alloca ptr, align 4
  %i.addr = alloca i32, align 4
  store ptr %w, ptr %w.addr, align 4, !tbaa !4
  store i32 %i, ptr %i.addr, align 4, !tbaa !8
  %0 = load i32, ptr %i.addr, align 4, !tbaa !8
  %1 = load ptr, ptr %w.addr, align 4, !tbaa !4
  %cap = getelementptr inbounds %struct.Surf, ptr %1, i32 0, i32 0
  %2 = load i32, ptr %cap, align 4, !tbaa !8
  %cmp = icmp uge i32 %0, %2
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %entry
  call void @llvm.trap()
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  %3 = load ptr, ptr %w.addr, align 4, !tbaa !4
  %cells = getelementptr inbounds %struct.Surf, ptr %3, i32 0, i32 1
  %4 = load i32, ptr %i.addr, align 4, !tbaa !8
  %arrayidx = getelementptr [0 x i16], ptr %cells, i32 0, i32 %4
  %5 = load i16, ptr %arrayidx, align 2, !tbaa !12
  %conv = zext i16 %5 to i32
  ret i32 %conv
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #4

attributes #0 = { noinline nounwind "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { inlinehint nounwind "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #3 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #5 = { nounwind }
attributes #6 = { nobuiltin "no-builtins" }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"target-abi", !"ilp32f"}
!2 = !{i32 8, !"SmallDataLimit", i32 8}
!3 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!4 = !{!5, !5, i64 0}
!5 = !{!"any pointer", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = !{!9, !9, i64 0}
!9 = !{!"int", !6, i64 0}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
!12 = !{!13, !13, i64 0}
!13 = !{!"short", !6, i64 0}
