; ModuleID = 'wrap-raw.ll'
source_filename = "kernel.c"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

%struct.Surf = type { i32, [0 x i16] }

; Function Attrs: noinline nounwind memory(argmem: read, inaccessiblemem: write)
define dso_local i32 @kernel(ptr nocapture noundef readonly %ctx, i32 noundef %x, i32 noundef %y) local_unnamed_addr #0 {
entry:
  %0 = load i32, ptr %ctx, align 4, !tbaa !4
  %cmp.not.i = icmp ugt i32 %0, 17
  br i1 %cmp.not.i, label %checked_read.exit, label %if.then.i

if.then.i:                                        ; preds = %entry
  tail call void @llvm.trap()
  unreachable

checked_read.exit:                                ; preds = %entry
  %arrayidx.i = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 17
  %1 = load i16, ptr %arrayidx.i, align 2, !tbaa !8
  %conv.i = zext i16 %1 to i32
  %sub = add nsw i32 %conv.i, -32
  %cmp.not.i33.not = icmp eq i32 %0, 18
  br i1 %cmp.not.i33.not, label %if.then.i34, label %checked_read.exit37

if.then.i34:                                      ; preds = %checked_read.exit
  tail call void @llvm.trap()
  unreachable

checked_read.exit37:                              ; preds = %checked_read.exit
  %arrayidx.i35 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 18
  %2 = load i16, ptr %arrayidx.i35, align 2, !tbaa !8
  %conv.i36 = zext i16 %2 to i32
  %sub2 = add nsw i32 %conv.i36, -32
  %cmp.not.i38 = icmp ugt i32 %0, 19
  br i1 %cmp.not.i38, label %checked_read.exit47, label %if.then.i39

if.then.i39:                                      ; preds = %checked_read.exit37
  tail call void @llvm.trap()
  unreachable

checked_read.exit47:                              ; preds = %checked_read.exit37
  %arrayidx.i40 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 19
  %3 = load i16, ptr %arrayidx.i40, align 2, !tbaa !8
  %conv.i41 = zext i16 %3 to i32
  %arrayidx.i45 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 16
  %4 = load i16, ptr %arrayidx.i45, align 2, !tbaa !8
  %conv.i46 = zext i16 %4 to i32
  %cmp.not97.not = icmp eq i16 %4, 0
  br i1 %cmp.not97.not, label %cleanup56, label %for.body.lr.ph

for.body.lr.ph:                                   ; preds = %checked_read.exit47
  %mul5 = shl i32 %x, 5
  %add6 = add i32 %mul5, 4096
  %mul12 = shl i32 %y, 5
  %add13 = add i32 %mul12, 4096
  br label %for.body

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %cmp.not99 = phi i1 [ true, %for.body.lr.ph ], [ %cmp.not, %for.inc ]
  %s.098 = phi i32 [ 0, %for.body.lr.ph ], [ %inc, %for.inc ]
  %mul = shl i32 %s.098, 2
  %add = add nuw nsw i32 %mul, 21
  %cmp.not.i48 = icmp ugt i32 %0, %add
  br i1 %cmp.not.i48, label %checked_read.exit52, label %if.then.i49

if.then.i49:                                      ; preds = %for.body
  tail call void @llvm.trap()
  unreachable

checked_read.exit52:                              ; preds = %for.body
  %add9 = add nuw nsw i32 %mul, 23
  %cmp.not.i53 = icmp ugt i32 %0, %add9
  br i1 %cmp.not.i53, label %checked_read.exit57, label %if.then.i54

if.then.i54:                                      ; preds = %checked_read.exit52
  tail call void @llvm.trap()
  unreachable

checked_read.exit57:                              ; preds = %checked_read.exit52
  %arrayidx.i50 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add
  %5 = load i16, ptr %arrayidx.i50, align 2, !tbaa !8
  %conv.i51 = zext i16 %5 to i32
  %sub8 = sub i32 %add6, %conv.i51
  %6 = tail call i32 @llvm.abs.i32(i32 %sub8, i1 false)
  %arrayidx.i55 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add9
  %7 = load i16, ptr %arrayidx.i55, align 2, !tbaa !8
  %conv.i56 = zext i16 %7 to i32
  %cmp11 = icmp sgt i32 %6, %conv.i56
  br i1 %cmp11, label %for.inc, label %checked_read.exit62

checked_read.exit62:                              ; preds = %checked_read.exit57
  %add17 = add nuw nsw i32 %mul, 24
  %cmp.not.i63 = icmp ugt i32 %0, %add17
  br i1 %cmp.not.i63, label %checked_read.exit67, label %if.then.i64

if.then.i64:                                      ; preds = %checked_read.exit62
  tail call void @llvm.trap()
  unreachable

checked_read.exit67:                              ; preds = %checked_read.exit62
  %add14 = add nuw nsw i32 %mul, 22
  %arrayidx.i60 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add14
  %8 = load i16, ptr %arrayidx.i60, align 2, !tbaa !8
  %conv.i61 = zext i16 %8 to i32
  %sub16 = sub i32 %add13, %conv.i61
  %9 = tail call i32 @llvm.abs.i32(i32 %sub16, i1 false)
  %arrayidx.i65 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add17
  %10 = load i16, ptr %arrayidx.i65, align 2, !tbaa !8
  %conv.i66 = zext i16 %10 to i32
  %cmp19 = icmp sgt i32 %9, %conv.i66
  br i1 %cmp19, label %for.inc, label %if.end

if.end:                                           ; preds = %checked_read.exit67
  %mul20 = mul nuw nsw i32 %s.098, 5
  %add21 = add nuw nsw i32 %mul20, 1
  %cmp.not.i68 = icmp ugt i32 %0, %add21
  br i1 %cmp.not.i68, label %checked_read.exit72, label %if.then.i69

if.then.i69:                                      ; preds = %if.end
  tail call void @llvm.trap()
  unreachable

checked_read.exit72:                              ; preds = %if.end
  %arrayidx.i70 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add21
  %11 = load i16, ptr %arrayidx.i70, align 2, !tbaa !8
  %conv.i71 = zext i16 %11 to i32
  %sub23 = sub i32 %conv.i71, %x
  %add24 = add nuw nsw i32 %mul20, 2
  %cmp.not.i73 = icmp ugt i32 %0, %add24
  br i1 %cmp.not.i73, label %checked_read.exit77, label %if.then.i74

if.then.i74:                                      ; preds = %checked_read.exit72
  tail call void @llvm.trap()
  unreachable

checked_read.exit77:                              ; preds = %checked_read.exit72
  %arrayidx.i75 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add24
  %12 = load i16, ptr %arrayidx.i75, align 2, !tbaa !8
  %conv.i76 = zext i16 %12 to i32
  %sub26 = sub i32 %conv.i76, %y
  %add27 = add nuw nsw i32 %mul20, 3
  %cmp.not.i78 = icmp ugt i32 %0, %add27
  br i1 %cmp.not.i78, label %checked_read.exit82, label %if.then.i79

if.then.i79:                                      ; preds = %checked_read.exit77
  tail call void @llvm.trap()
  unreachable

checked_read.exit82:                              ; preds = %checked_read.exit77
  %arrayidx.i80 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add27
  %13 = load i16, ptr %arrayidx.i80, align 2, !tbaa !8
  %conv.i81 = zext i16 %13 to i32
  %sub29 = sub nsw i32 156, %conv.i81
  %add30 = add nuw nsw i32 %mul20, 4
  %cmp.not.i83 = icmp ugt i32 %0, %add30
  br i1 %cmp.not.i83, label %checked_read.exit87, label %if.then.i84

if.then.i84:                                      ; preds = %checked_read.exit82
  tail call void @llvm.trap()
  unreachable

checked_read.exit87:                              ; preds = %checked_read.exit82
  %mul32 = mul i32 %sub23, %sub
  %mul33 = mul i32 %sub26, %sub2
  %add34 = add i32 %mul33, %mul32
  %mul35 = shl nsw i32 %sub29, 5
  %add36 = add i32 %add34, %mul35
  %cmp37 = icmp sgt i32 %add36, 0
  br i1 %cmp37, label %land.lhs.true, label %for.inc

land.lhs.true:                                    ; preds = %checked_read.exit87
  %arrayidx.i85 = getelementptr %struct.Surf, ptr %ctx, i32 0, i32 1, i32 %add30
  %14 = load i16, ptr %arrayidx.i85, align 2, !tbaa !8
  %conv.i86 = zext i16 %14 to i32
  %mul38 = mul i32 %sub23, %sub23
  %mul39 = mul i32 %sub26, %sub26
  %add40 = add i32 %mul39, %mul38
  %mul41 = mul i32 %sub29, %sub29
  %add42 = add i32 %add40, %mul41
  %mul43 = mul nuw i32 %conv.i86, %conv.i86
  %sub44 = sub i32 %add42, %mul43
  %mul45 = mul i32 %sub44, %conv.i41
  %mul46 = mul i32 %add36, %add36
  %cmp47.not = icmp sgt i32 %mul45, %mul46
  br i1 %cmp47.not, label %for.inc, label %cleanup56.loopexit

for.inc:                                          ; preds = %checked_read.exit87, %land.lhs.true, %checked_read.exit67, %checked_read.exit57
  %inc = add nuw nsw i32 %s.098, 1
  %cmp.not = icmp ult i32 %inc, %conv.i46
  %exitcond.not = icmp eq i32 %inc, %conv.i46
  br i1 %exitcond.not, label %cleanup56.loopexit, label %for.body, !llvm.loop !10

cleanup56.loopexit:                               ; preds = %land.lhs.true, %for.inc
  %cmp.not.lcssa.ph = phi i1 [ %cmp.not, %for.inc ], [ %cmp.not99, %land.lhs.true ]
  %15 = zext i1 %cmp.not.lcssa.ph to i32
  br label %cleanup56

cleanup56:                                        ; preds = %cleanup56.loopexit, %checked_read.exit47
  %cmp.not.lcssa = phi i32 [ 0, %checked_read.exit47 ], [ %15, %cleanup56.loopexit ]
  ret i32 %cmp.not.lcssa
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #1

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #2

attributes #0 = { noinline nounwind memory(argmem: read, inaccessiblemem: write) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { cold noreturn nounwind memory(inaccessiblemem: write) }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"target-abi", !"ilp32f"}
!2 = !{i32 8, !"SmallDataLimit", i32 8}
!3 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!4 = !{!5, !5, i64 0}
!5 = !{!"int", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = !{!9, !9, i64 0}
!9 = !{!"short", !6, i64 0}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
