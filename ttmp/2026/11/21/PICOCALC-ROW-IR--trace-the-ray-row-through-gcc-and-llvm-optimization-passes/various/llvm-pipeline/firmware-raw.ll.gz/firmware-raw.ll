; ModuleID = 'firmware.i'
source_filename = "firmware.i"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

%struct.raytrace_demo_scene = type { i32, i32, i32, i32 }
%struct.raytrace_demo_object = type { i32, i32, i32, i32, i16 }
%struct.trace = type { [3 x %struct.sphere], i32, [8 x i8], [3 x [160 x i16]], [160 x i16], [1025 x i8], [160 x i16], [160 x i8], [14 x i8] }
%struct.sphere = type { i32, i32, i32, i32, i32, i32, i32 }
%struct.light = type { i32, i32, i32, i32, [3 x i32], [3 x i32], [3 x i32], [3 x i32] }
%struct.raytrace_demo_stats = type { i32, i32, i32, i32, i32, i32, i32, i32 }

; Function Attrs: nounwind
define dso_local void @raytrace_demo_default_scene(ptr dead_on_unwind noalias writable sret(%struct.raytrace_demo_scene) align 4 %agg.result) #0 {
entry:
  %result.ptr = alloca ptr, align 4
  store ptr %agg.result, ptr %result.ptr, align 4
  %sphere_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 0
  store i32 68, ptr %sphere_x, align 4, !tbaa !4
  %sphere_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 1
  store i32 61, ptr %sphere_y, align 4, !tbaa !9
  %light_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 2
  store i32 31, ptr %light_x, align 4, !tbaa !10
  %light_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 3
  store i32 25, ptr %light_y, align 4, !tbaa !11
  ret void
}

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_has_pie() #0 {
entry:
  ret i1 true
}

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_object_fits(ptr noundef %object) #0 {
entry:
  %object.addr = alloca ptr, align 4
  store ptr %object, ptr %object.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %tobool = icmp ne ptr %0, null
  br i1 %tobool, label %land.lhs.true, label %land.end

land.lhs.true:                                    ; preds = %entry
  %1 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %x = getelementptr inbounds %struct.raytrace_demo_object, ptr %1, i32 0, i32 0
  %2 = load i32, ptr %x, align 4, !tbaa !14
  %cmp = icmp sge i32 %2, 32
  br i1 %cmp, label %land.lhs.true1, label %land.end

land.lhs.true1:                                   ; preds = %land.lhs.true
  %3 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %x2 = getelementptr inbounds %struct.raytrace_demo_object, ptr %3, i32 0, i32 0
  %4 = load i32, ptr %x2, align 4, !tbaa !14
  %cmp3 = icmp sle i32 %4, 127
  br i1 %cmp3, label %land.lhs.true4, label %land.end

land.lhs.true4:                                   ; preds = %land.lhs.true1
  %5 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %y = getelementptr inbounds %struct.raytrace_demo_object, ptr %5, i32 0, i32 1
  %6 = load i32, ptr %y, align 4, !tbaa !17
  %cmp5 = icmp sge i32 %6, 32
  br i1 %cmp5, label %land.lhs.true6, label %land.end

land.lhs.true6:                                   ; preds = %land.lhs.true4
  %7 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %y7 = getelementptr inbounds %struct.raytrace_demo_object, ptr %7, i32 0, i32 1
  %8 = load i32, ptr %y7, align 4, !tbaa !17
  %cmp8 = icmp sle i32 %8, 127
  br i1 %cmp8, label %land.lhs.true9, label %land.end

land.lhs.true9:                                   ; preds = %land.lhs.true6
  %9 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %radius = getelementptr inbounds %struct.raytrace_demo_object, ptr %9, i32 0, i32 3
  %10 = load i32, ptr %radius, align 4, !tbaa !18
  %cmp10 = icmp sge i32 %10, 1
  br i1 %cmp10, label %land.lhs.true11, label %land.end

land.lhs.true11:                                  ; preds = %land.lhs.true9
  %11 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %radius12 = getelementptr inbounds %struct.raytrace_demo_object, ptr %11, i32 0, i32 3
  %12 = load i32, ptr %radius12, align 4, !tbaa !18
  %cmp13 = icmp sle i32 %12, 32
  br i1 %cmp13, label %land.lhs.true14, label %land.end

land.lhs.true14:                                  ; preds = %land.lhs.true11
  %13 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %z = getelementptr inbounds %struct.raytrace_demo_object, ptr %13, i32 0, i32 2
  %14 = load i32, ptr %z, align 4, !tbaa !19
  %15 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %radius15 = getelementptr inbounds %struct.raytrace_demo_object, ptr %15, i32 0, i32 3
  %16 = load i32, ptr %radius15, align 4, !tbaa !18
  %cmp16 = icmp sgt i32 %14, %16
  br i1 %cmp16, label %land.rhs, label %land.end

land.rhs:                                         ; preds = %land.lhs.true14
  %17 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %z17 = getelementptr inbounds %struct.raytrace_demo_object, ptr %17, i32 0, i32 2
  %18 = load i32, ptr %z17, align 4, !tbaa !19
  %19 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %radius18 = getelementptr inbounds %struct.raytrace_demo_object, ptr %19, i32 0, i32 3
  %20 = load i32, ptr %radius18, align 4, !tbaa !18
  %sub = sub nsw i32 156, %20
  %cmp19 = icmp slt i32 %18, %sub
  br label %land.end

land.end:                                         ; preds = %land.rhs, %land.lhs.true14, %land.lhs.true11, %land.lhs.true9, %land.lhs.true6, %land.lhs.true4, %land.lhs.true1, %land.lhs.true, %entry
  %21 = phi i1 [ false, %land.lhs.true14 ], [ false, %land.lhs.true11 ], [ false, %land.lhs.true9 ], [ false, %land.lhs.true6 ], [ false, %land.lhs.true4 ], [ false, %land.lhs.true1 ], [ false, %land.lhs.true ], [ false, %entry ], [ %cmp19, %land.rhs ]
  ret i1 %21
}

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_render(ptr noundef %pixels, i32 noundef %stride_pixels, ptr noundef %scene, i32 noundef %mode, ptr noundef %stats) #0 {
entry:
  %retval = alloca i1, align 1
  %pixels.addr = alloca ptr, align 4
  %stride_pixels.addr = alloca i32, align 4
  %scene.addr = alloca ptr, align 4
  %mode.addr = alloca i32, align 4
  %stats.addr = alloca ptr, align 4
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %y = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %hits = alloca i32, align 4
  %row = alloca ptr, align 4
  %x = alloca i32, align 4
  %hit = alloca i8, align 1
  %shadow = alloca i8, align 1
  %pixel = alloca i16, align 2
  store ptr %pixels, ptr %pixels.addr, align 4, !tbaa !12
  store i32 %stride_pixels, ptr %stride_pixels.addr, align 4, !tbaa !20
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  store ptr %stats, ptr %stats.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %1 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %2 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %3 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call = call zeroext i1 @valid(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3)
  br i1 %call, label %if.end, label %if.then

if.then:                                          ; preds = %entry
  store i1 false, ptr %retval, align 1
  br label %return

if.end:                                           ; preds = %entry
  call void @llvm.lifetime.start.p0(i64 2896, ptr %work) #6
  %4 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  call void @prepare(ptr noundef %work, ptr noundef %4)
  call void @llvm.lifetime.start.p0(i64 64, ptr %lamp) #6
  %5 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %5, i32 0, i32 2
  %6 = load i32, ptr %light_x, align 4, !tbaa !10
  %7 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %7, i32 0, i32 3
  %8 = load i32, ptr %light_y, align 4, !tbaa !11
  call void @prepare_light(ptr dead_on_unwind writable sret(%struct.light) align 4 %lamp, ptr noundef %work, i32 noundef %6, i32 noundef %8)
  %9 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool = icmp ne ptr %9, null
  br i1 %tobool, label %if.then1, label %if.end2

if.then1:                                         ; preds = %if.end
  %10 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %11 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %12 = load i32, ptr %object_count, align 4, !tbaa !21
  call void @start_stats(ptr noundef %10, i32 noundef %11, i32 noundef %12)
  br label %if.end2

if.end2:                                          ; preds = %if.then1, %if.end
  call void @llvm.lifetime.start.p0(i64 4, ptr %y) #6
  store i32 0, ptr %y, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc36, %if.end2
  %13 = load i32, ptr %y, align 4, !tbaa !20
  %cmp = icmp slt i32 %13, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %y) #6
  br label %for.end38

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %hits) #6
  %14 = load i32, ptr %y, align 4, !tbaa !20
  %15 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %16 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %cmp3 = icmp ne ptr %16, null
  %call4 = call i32 @trace_row(ptr noundef %work, i32 noundef %14, i32 noundef %15, i1 noundef zeroext %cmp3)
  store i32 %call4, ptr %hits, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %row) #6
  %17 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %18 = load i32, ptr %y, align 4, !tbaa !20
  %19 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %mul = mul i32 %18, %19
  %add.ptr = getelementptr inbounds i16, ptr %17, i32 %mul
  store ptr %add.ptr, ptr %row, align 4, !tbaa !12
  %20 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool5 = icmp ne ptr %20, null
  br i1 %tobool5, label %if.then6, label %if.end7

if.then6:                                         ; preds = %for.body
  %21 = load i32, ptr %hits, align 4, !tbaa !20
  %22 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %22, i32 0, i32 2
  %23 = load i32, ptr %sphere_hits, align 4, !tbaa !23
  %add = add i32 %23, %21
  store i32 %add, ptr %sphere_hits, align 4, !tbaa !23
  br label %if.end7

if.end7:                                          ; preds = %if.then6, %for.body
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond8

for.cond8:                                        ; preds = %for.inc, %if.end7
  %24 = load i32, ptr %x, align 4, !tbaa !20
  %cmp9 = icmp slt i32 %24, 160
  br i1 %cmp9, label %for.body11, label %for.cond.cleanup10

for.cond.cleanup10:                               ; preds = %for.cond8
  store i32 5, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  br label %for.end

for.body11:                                       ; preds = %for.cond8
  call void @llvm.lifetime.start.p0(i64 1, ptr %hit) #6
  %depth = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %25 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [160 x i16], ptr %depth, i32 0, i32 %25
  %26 = load i16, ptr %arrayidx, align 2, !tbaa !26
  %conv = sext i16 %26 to i32
  %cmp12 = icmp ne i32 %conv, 0
  %frombool = zext i1 %cmp12 to i8
  store i8 %frombool, ptr %hit, align 1, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 1, ptr %shadow) #6
  %27 = load i8, ptr %hit, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool14 = trunc i8 %27 to i1
  br i1 %tobool14, label %land.end, label %land.rhs

land.rhs:                                         ; preds = %for.body11
  %28 = load i32, ptr %x, align 4, !tbaa !20
  %29 = load i32, ptr %y, align 4, !tbaa !20
  %call15 = call zeroext i1 @in_shadow(ptr noundef %work, ptr noundef %lamp, i32 noundef %28, i32 noundef %29)
  br label %land.end

land.end:                                         ; preds = %land.rhs, %for.body11
  %30 = phi i1 [ false, %for.body11 ], [ %call15, %land.rhs ]
  %frombool17 = zext i1 %30 to i8
  store i8 %frombool17, ptr %shadow, align 1, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 2, ptr %pixel) #6
  %31 = load i8, ptr %hit, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool18 = trunc i8 %31 to i1
  br i1 %tobool18, label %cond.true, label %cond.false

cond.true:                                        ; preds = %land.end
  %32 = load i32, ptr %x, align 4, !tbaa !20
  %33 = load i32, ptr %y, align 4, !tbaa !20
  %call20 = call zeroext i16 @shade_sphere(ptr noundef %work, ptr noundef %lamp, i32 noundef %32, i32 noundef %33)
  %conv21 = zext i16 %call20 to i32
  br label %cond.end

cond.false:                                       ; preds = %land.end
  %34 = load i32, ptr %x, align 4, !tbaa !20
  %35 = load i32, ptr %y, align 4, !tbaa !20
  %36 = load i8, ptr %shadow, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool22 = trunc i8 %36 to i1
  %call23 = call zeroext i16 @shade_floor(i32 noundef %34, i32 noundef %35, i1 noundef zeroext %tobool22)
  %conv24 = zext i16 %call23 to i32
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %conv21, %cond.true ], [ %conv24, %cond.false ]
  %conv25 = trunc i32 %cond to i16
  store i16 %conv25, ptr %pixel, align 2, !tbaa !26
  %37 = load i16, ptr %pixel, align 2, !tbaa !26
  %38 = load ptr, ptr %row, align 4, !tbaa !12
  %39 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx26 = getelementptr inbounds i16, ptr %38, i32 %39
  store i16 %37, ptr %arrayidx26, align 2, !tbaa !26
  %40 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool27 = icmp ne ptr %40, null
  br i1 %tobool27, label %if.then28, label %if.end35

if.then28:                                        ; preds = %cond.end
  %41 = load i8, ptr %hit, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool29 = trunc i8 %41 to i1
  %conv30 = zext i1 %tobool29 to i32
  %42 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %42, i32 0, i32 3
  %43 = load i32, ptr %hit_pixels, align 4, !tbaa !31
  %add31 = add i32 %43, %conv30
  store i32 %add31, ptr %hit_pixels, align 4, !tbaa !31
  %44 = load i8, ptr %shadow, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool32 = trunc i8 %44 to i1
  %conv33 = zext i1 %tobool32 to i32
  %45 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %shadow_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %45, i32 0, i32 4
  %46 = load i32, ptr %shadow_pixels, align 4, !tbaa !32
  %add34 = add i32 %46, %conv33
  store i32 %add34, ptr %shadow_pixels, align 4, !tbaa !32
  %47 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %48 = load i16, ptr %pixel, align 2, !tbaa !26
  call void @hash_pixel(ptr noundef %47, i16 noundef zeroext %48)
  br label %if.end35

if.end35:                                         ; preds = %if.then28, %cond.end
  call void @llvm.lifetime.end.p0(i64 2, ptr %pixel) #6
  call void @llvm.lifetime.end.p0(i64 1, ptr %shadow) #6
  call void @llvm.lifetime.end.p0(i64 1, ptr %hit) #6
  br label %for.inc

for.inc:                                          ; preds = %if.end35
  %49 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %49, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond8, !llvm.loop !33

for.end:                                          ; preds = %for.cond.cleanup10
  call void @llvm.lifetime.end.p0(i64 4, ptr %row) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %hits) #6
  br label %for.inc36

for.inc36:                                        ; preds = %for.end
  %50 = load i32, ptr %y, align 4, !tbaa !20
  %inc37 = add nsw i32 %50, 1
  store i32 %inc37, ptr %y, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !35

for.end38:                                        ; preds = %for.cond.cleanup
  %51 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool39 = icmp ne ptr %51, null
  br i1 %tobool39, label %land.lhs.true, label %if.end44

land.lhs.true:                                    ; preds = %for.end38
  %52 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp40 = icmp eq i32 %52, 1
  br i1 %cmp40, label %if.then42, label %if.end44

if.then42:                                        ; preds = %land.lhs.true
  %53 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %sphere_hits43 = getelementptr inbounds %struct.raytrace_demo_stats, ptr %53, i32 0, i32 2
  %54 = load i32, ptr %sphere_hits43, align 4, !tbaa !23
  %55 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %55, i32 0, i32 6
  store i32 %54, ptr %pie_active_lanes, align 4, !tbaa !36
  br label %if.end44

if.end44:                                         ; preds = %if.then42, %land.lhs.true, %for.end38
  store i1 true, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 64, ptr %lamp) #6
  call void @llvm.lifetime.end.p0(i64 2896, ptr %work) #6
  br label %return

return:                                           ; preds = %if.end44, %if.then
  %56 = load i1, ptr %retval, align 1
  ret i1 %56
}

; Function Attrs: nounwind
define internal zeroext i1 @valid(ptr noundef %output, i32 noundef %stride, ptr noundef %scene, i32 noundef %mode) #0 {
entry:
  %output.addr = alloca ptr, align 4
  %stride.addr = alloca i32, align 4
  %scene.addr = alloca ptr, align 4
  %mode.addr = alloca i32, align 4
  store ptr %output, ptr %output.addr, align 4, !tbaa !12
  store i32 %stride, ptr %stride.addr, align 4, !tbaa !20
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  %0 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %tobool = icmp ne ptr %0, null
  br i1 %tobool, label %land.lhs.true, label %land.end

land.lhs.true:                                    ; preds = %entry
  %1 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %sphere_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %1, i32 0, i32 0
  %2 = load i32, ptr %sphere_x, align 4, !tbaa !4
  %cmp = icmp sge i32 %2, 32
  br i1 %cmp, label %land.lhs.true1, label %land.end

land.lhs.true1:                                   ; preds = %land.lhs.true
  %3 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %sphere_x2 = getelementptr inbounds %struct.raytrace_demo_scene, ptr %3, i32 0, i32 0
  %4 = load i32, ptr %sphere_x2, align 4, !tbaa !4
  %cmp3 = icmp sle i32 %4, 127
  br i1 %cmp3, label %land.lhs.true4, label %land.end

land.lhs.true4:                                   ; preds = %land.lhs.true1
  %5 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %sphere_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %5, i32 0, i32 1
  %6 = load i32, ptr %sphere_y, align 4, !tbaa !9
  %cmp5 = icmp sge i32 %6, 32
  br i1 %cmp5, label %land.lhs.true6, label %land.end

land.lhs.true6:                                   ; preds = %land.lhs.true4
  %7 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %sphere_y7 = getelementptr inbounds %struct.raytrace_demo_scene, ptr %7, i32 0, i32 1
  %8 = load i32, ptr %sphere_y7, align 4, !tbaa !9
  %cmp8 = icmp sle i32 %8, 127
  br i1 %cmp8, label %land.rhs, label %land.end

land.rhs:                                         ; preds = %land.lhs.true6
  %9 = load ptr, ptr %output.addr, align 4, !tbaa !12
  %10 = load i32, ptr %stride.addr, align 4, !tbaa !20
  %11 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %11, i32 0, i32 2
  %12 = load i32, ptr %light_x, align 4, !tbaa !10
  %13 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %13, i32 0, i32 3
  %14 = load i32, ptr %light_y, align 4, !tbaa !11
  %15 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call = call zeroext i1 @valid_output(ptr noundef %9, i32 noundef %10, i32 noundef %12, i32 noundef %14, i32 noundef %15)
  br label %land.end

land.end:                                         ; preds = %land.rhs, %land.lhs.true6, %land.lhs.true4, %land.lhs.true1, %land.lhs.true, %entry
  %16 = phi i1 [ false, %land.lhs.true6 ], [ false, %land.lhs.true4 ], [ false, %land.lhs.true1 ], [ false, %land.lhs.true ], [ false, %entry ], [ %call, %land.rhs ]
  ret i1 %16
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
define internal void @prepare(ptr noundef %work, ptr noundef %scene) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %scene.addr = alloca ptr, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %1 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  call void @prepare_objects(ptr noundef %0, ptr noundef %1)
  %2 = load ptr, ptr %work.addr, align 4, !tbaa !12
  call void @prepare_tables(ptr noundef %2)
  ret void
}

; Function Attrs: nounwind
define internal void @prepare_light(ptr dead_on_unwind noalias writable sret(%struct.light) align 4 %agg.result, ptr noundef %work, i32 noundef %light_x, i32 noundef %light_y) #0 {
entry:
  %result.ptr = alloca ptr, align 4
  %work.addr = alloca ptr, align 4
  %light_x.addr = alloca i32, align 4
  %light_y.addr = alloca i32, align 4
  %s = alloca i32, align 4
  %object = alloca ptr, align 4
  %dz = alloca i32, align 4
  store ptr %agg.result, ptr %result.ptr, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store i32 %light_x, ptr %light_x.addr, align 4, !tbaa !20
  store i32 %light_y, ptr %light_y.addr, align 4, !tbaa !20
  call void @llvm.memset.p0.i64(ptr align 4 %agg.result, i8 0, i64 64, i1 false)
  %x = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 0
  %0 = load i32, ptr %light_x.addr, align 4, !tbaa !20
  %sub = sub nsw i32 %0, 80
  %mul = mul nsw i32 %sub, 3
  %div = sdiv i32 %mul, 10
  store i32 %div, ptr %x, align 4, !tbaa !37
  %y = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 1
  %1 = load i32, ptr %light_y.addr, align 4, !tbaa !20
  %sub1 = sub nsw i32 %1, 80
  %mul2 = mul nsw i32 %sub1, 3
  %div3 = sdiv i32 %mul2, 10
  store i32 %div3, ptr %y, align 4, !tbaa !39
  %x4 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 0
  %2 = load i32, ptr %x4, align 4, !tbaa !37
  %x5 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 0
  %3 = load i32, ptr %x5, align 4, !tbaa !37
  %mul6 = mul nsw i32 %2, %3
  %y7 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 1
  %4 = load i32, ptr %y7, align 4, !tbaa !39
  %y8 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 1
  %5 = load i32, ptr %y8, align 4, !tbaa !39
  %mul9 = mul nsw i32 %4, %5
  %add = add nsw i32 %mul6, %mul9
  %add10 = add nsw i32 %add, 1024
  %norm_squared = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 2
  store i32 %add10, ptr %norm_squared, align 4, !tbaa !40
  %norm = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 3
  store i32 32, ptr %norm, align 4, !tbaa !41
  br label %while.cond

while.cond:                                       ; preds = %while.body, %entry
  %norm11 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 3
  %6 = load i32, ptr %norm11, align 4, !tbaa !41
  %add12 = add nsw i32 %6, 1
  %norm13 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 3
  %7 = load i32, ptr %norm13, align 4, !tbaa !41
  %add14 = add nsw i32 %7, 1
  %mul15 = mul nsw i32 %add12, %add14
  %norm_squared16 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 2
  %8 = load i32, ptr %norm_squared16, align 4, !tbaa !40
  %cmp = icmp sle i32 %mul15, %8
  br i1 %cmp, label %while.body, label %while.end

while.body:                                       ; preds = %while.cond
  %norm17 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 3
  %9 = load i32, ptr %norm17, align 4, !tbaa !41
  %inc = add nsw i32 %9, 1
  store i32 %inc, ptr %norm17, align 4, !tbaa !41
  br label %while.cond, !llvm.loop !42

while.end:                                        ; preds = %while.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #6
  store i32 0, ptr %s, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %while.end
  %10 = load i32, ptr %s, align 4, !tbaa !20
  %11 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_count = getelementptr inbounds %struct.trace, ptr %11, i32 0, i32 1
  %12 = load i32, ptr %object_count, align 4, !tbaa !21
  %cmp18 = icmp ult i32 %10, %12
  br i1 %cmp18, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #6
  br label %for.end

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %object) #6
  %13 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects = getelementptr inbounds %struct.trace, ptr %13, i32 0, i32 0
  %14 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 %14
  store ptr %arrayidx, ptr %object, align 4, !tbaa !12
  call void @llvm.lifetime.start.p0(i64 4, ptr %dz) #6
  %15 = load ptr, ptr %object, align 4, !tbaa !12
  %z = getelementptr inbounds %struct.sphere, ptr %15, i32 0, i32 2
  %16 = load i32, ptr %z, align 4, !tbaa !43
  %sub19 = sub nsw i32 156, %16
  store i32 %sub19, ptr %dz, align 4, !tbaa !20
  %17 = load ptr, ptr %object, align 4, !tbaa !12
  %x20 = getelementptr inbounds %struct.sphere, ptr %17, i32 0, i32 0
  %18 = load i32, ptr %x20, align 4, !tbaa !45
  %mul21 = mul nsw i32 32, %18
  %19 = load i32, ptr %dz, align 4, !tbaa !20
  %x22 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 0
  %20 = load i32, ptr %x22, align 4, !tbaa !37
  %mul23 = mul nsw i32 %19, %20
  %sub24 = sub nsw i32 %mul21, %mul23
  %projected_x = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 4
  %21 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx25 = getelementptr inbounds [3 x i32], ptr %projected_x, i32 0, i32 %21
  store i32 %sub24, ptr %arrayidx25, align 4, !tbaa !20
  %22 = load ptr, ptr %object, align 4, !tbaa !12
  %y26 = getelementptr inbounds %struct.sphere, ptr %22, i32 0, i32 1
  %23 = load i32, ptr %y26, align 4, !tbaa !46
  %mul27 = mul nsw i32 32, %23
  %24 = load i32, ptr %dz, align 4, !tbaa !20
  %y28 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 1
  %25 = load i32, ptr %y28, align 4, !tbaa !39
  %mul29 = mul nsw i32 %24, %25
  %sub30 = sub nsw i32 %mul27, %mul29
  %projected_y = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 5
  %26 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx31 = getelementptr inbounds [3 x i32], ptr %projected_y, i32 0, i32 %26
  store i32 %sub30, ptr %arrayidx31, align 4, !tbaa !20
  %27 = load ptr, ptr %object, align 4, !tbaa !12
  %radius = getelementptr inbounds %struct.sphere, ptr %27, i32 0, i32 3
  %28 = load i32, ptr %radius, align 4, !tbaa !47
  %x32 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 0
  %29 = load i32, ptr %x32, align 4, !tbaa !37
  %30 = call i32 @llvm.abs.i32(i32 %29, i1 true)
  %add33 = add nsw i32 32, %30
  %mul34 = mul nsw i32 %28, %add33
  %reach_x = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 6
  %31 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx35 = getelementptr inbounds [3 x i32], ptr %reach_x, i32 0, i32 %31
  store i32 %mul34, ptr %arrayidx35, align 4, !tbaa !20
  %32 = load ptr, ptr %object, align 4, !tbaa !12
  %radius36 = getelementptr inbounds %struct.sphere, ptr %32, i32 0, i32 3
  %33 = load i32, ptr %radius36, align 4, !tbaa !47
  %y37 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 1
  %34 = load i32, ptr %y37, align 4, !tbaa !39
  %35 = call i32 @llvm.abs.i32(i32 %34, i1 true)
  %add38 = add nsw i32 32, %35
  %mul39 = mul nsw i32 %33, %add38
  %reach_y = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 7
  %36 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx40 = getelementptr inbounds [3 x i32], ptr %reach_y, i32 0, i32 %36
  store i32 %mul39, ptr %arrayidx40, align 4, !tbaa !20
  call void @llvm.lifetime.end.p0(i64 4, ptr %dz) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %object) #6
  br label %for.inc

for.inc:                                          ; preds = %for.body
  %37 = load i32, ptr %s, align 4, !tbaa !20
  %inc41 = add i32 %37, 1
  store i32 %inc41, ptr %s, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !48

for.end:                                          ; preds = %for.cond.cleanup
  ret void
}

; Function Attrs: nounwind
define internal void @start_stats(ptr noundef %stats, i32 noundef %mode, i32 noundef %object_count) #0 {
entry:
  %stats.addr = alloca ptr, align 4
  %mode.addr = alloca i32, align 4
  %object_count.addr = alloca i32, align 4
  %.compoundliteral = alloca %struct.raytrace_demo_stats, align 4
  store ptr %stats, ptr %stats.addr, align 4, !tbaa !12
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  store i32 %object_count, ptr %object_count.addr, align 4, !tbaa !20
  %0 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %rays = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 0
  store i32 25600, ptr %rays, align 4, !tbaa !49
  %sphere_tests = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 1
  %1 = load i32, ptr %object_count.addr, align 4, !tbaa !20
  %mul = mul i32 25600, %1
  store i32 %mul, ptr %sphere_tests, align 4, !tbaa !50
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 2
  store i32 0, ptr %sphere_hits, align 4, !tbaa !23
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 3
  store i32 0, ptr %hit_pixels, align 4, !tbaa !31
  %shadow_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 4
  store i32 0, ptr %shadow_pixels, align 4, !tbaa !32
  %pie_groups = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 5
  %2 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp = icmp eq i32 %2, 1
  br i1 %cmp, label %cond.true, label %cond.false

cond.true:                                        ; preds = %entry
  %3 = load i32, ptr %object_count.addr, align 4, !tbaa !20
  %mul1 = mul i32 25600, %3
  %div = udiv i32 %mul1, 8
  br label %cond.end

cond.false:                                       ; preds = %entry
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %div, %cond.true ], [ 0, %cond.false ]
  store i32 %cond, ptr %pie_groups, align 4, !tbaa !51
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 6
  store i32 0, ptr %pie_active_lanes, align 4, !tbaa !36
  %checksum = getelementptr inbounds %struct.raytrace_demo_stats, ptr %.compoundliteral, i32 0, i32 7
  store i32 -2128831035, ptr %checksum, align 4, !tbaa !52
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %0, ptr align 4 %.compoundliteral, i32 32, i1 false), !tbaa.struct !53
  ret void
}

; Function Attrs: nounwind
define internal i32 @trace_row(ptr noundef %work, i32 noundef %y, i32 noundef %mode, i1 noundef zeroext %count_hits) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %y.addr = alloca i32, align 4
  %mode.addr = alloca i32, align 4
  %count_hits.addr = alloca i8, align 1
  %hits = alloca i32, align 4
  %s = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %object = alloca ptr, align 4
  %dy = alloca i32, align 4
  %row_term = alloca i16, align 2
  %x = alloca i32, align 4
  %x24 = alloca i32, align 4
  %d = alloca i32, align 4
  %depth38 = alloca i16, align 2
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store i32 %y, ptr %y.addr, align 4, !tbaa !20
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  %frombool = zext i1 %count_hits to i8
  store i8 %frombool, ptr %count_hits.addr, align 1, !tbaa !27
  %0 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth = getelementptr inbounds %struct.trace, ptr %0, i32 0, i32 6
  %arraydecay = getelementptr inbounds [160 x i16], ptr %depth, i32 0, i32 0
  call void @llvm.memset.p0.i32(ptr align 2 %arraydecay, i8 0, i32 320, i1 false)
  call void @llvm.lifetime.start.p0(i64 4, ptr %hits) #6
  store i32 0, ptr %hits, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #6
  store i32 0, ptr %s, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc64, %entry
  %1 = load i32, ptr %s, align 4, !tbaa !20
  %2 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_count = getelementptr inbounds %struct.trace, ptr %2, i32 0, i32 1
  %3 = load i32, ptr %object_count, align 4, !tbaa !21
  %cmp = icmp ult i32 %1, %3
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #6
  br label %for.end67

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %object) #6
  %4 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects = getelementptr inbounds %struct.trace, ptr %4, i32 0, i32 0
  %5 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 %5
  store ptr %arrayidx, ptr %object, align 4, !tbaa !12
  call void @llvm.lifetime.start.p0(i64 4, ptr %dy) #6
  %6 = load i32, ptr %y.addr, align 4, !tbaa !20
  %7 = load ptr, ptr %object, align 4, !tbaa !12
  %y1 = getelementptr inbounds %struct.sphere, ptr %7, i32 0, i32 1
  %8 = load i32, ptr %y1, align 4, !tbaa !46
  %sub = sub nsw i32 %6, %8
  store i32 %sub, ptr %dy, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 2, ptr %row_term) #6
  %9 = load ptr, ptr %object, align 4, !tbaa !12
  %radius = getelementptr inbounds %struct.sphere, ptr %9, i32 0, i32 3
  %10 = load i32, ptr %radius, align 4, !tbaa !47
  %11 = load ptr, ptr %object, align 4, !tbaa !12
  %radius2 = getelementptr inbounds %struct.sphere, ptr %11, i32 0, i32 3
  %12 = load i32, ptr %radius2, align 4, !tbaa !47
  %mul = mul nsw i32 %10, %12
  %13 = load i32, ptr %dy, align 4, !tbaa !20
  %14 = load i32, ptr %dy, align 4, !tbaa !20
  %mul3 = mul nsw i32 %13, %14
  %sub4 = sub nsw i32 %mul, %mul3
  %conv = trunc i32 %sub4 to i16
  store i16 %conv, ptr %row_term, align 2, !tbaa !26
  %15 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp5 = icmp eq i32 %15, 1
  br i1 %cmp5, label %if.then, label %if.else

if.then:                                          ; preds = %for.body
  %16 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %x_squared = getelementptr inbounds %struct.trace, ptr %16, i32 0, i32 3
  %17 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx7 = getelementptr inbounds [3 x [160 x i16]], ptr %x_squared, i32 0, i32 %17
  %arraydecay8 = getelementptr inbounds [160 x i16], ptr %arrayidx7, i32 0, i32 0
  %18 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %discriminants = getelementptr inbounds %struct.trace, ptr %18, i32 0, i32 4
  %arraydecay9 = getelementptr inbounds [160 x i16], ptr %discriminants, i32 0, i32 0
  call void @raytrace_demo_pie_row(ptr noundef %arraydecay8, ptr noundef %row_term, ptr noundef %arraydecay9, i32 noundef 20)
  br label %if.end

if.else:                                          ; preds = %for.body
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond10

for.cond10:                                       ; preds = %for.inc, %if.else
  %19 = load i32, ptr %x, align 4, !tbaa !20
  %cmp11 = icmp slt i32 %19, 160
  br i1 %cmp11, label %for.body14, label %for.cond.cleanup13

for.cond.cleanup13:                               ; preds = %for.cond10
  store i32 5, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  br label %for.end

for.body14:                                       ; preds = %for.cond10
  %20 = load i16, ptr %row_term, align 2, !tbaa !26
  %conv15 = sext i16 %20 to i32
  %21 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %x_squared16 = getelementptr inbounds %struct.trace, ptr %21, i32 0, i32 3
  %22 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx17 = getelementptr inbounds [3 x [160 x i16]], ptr %x_squared16, i32 0, i32 %22
  %23 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx18 = getelementptr inbounds [160 x i16], ptr %arrayidx17, i32 0, i32 %23
  %24 = load i16, ptr %arrayidx18, align 2, !tbaa !26
  %conv19 = sext i16 %24 to i32
  %sub20 = sub nsw i32 %conv15, %conv19
  %conv21 = trunc i32 %sub20 to i16
  %25 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %discriminants22 = getelementptr inbounds %struct.trace, ptr %25, i32 0, i32 4
  %26 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx23 = getelementptr inbounds [160 x i16], ptr %discriminants22, i32 0, i32 %26
  store i16 %conv21, ptr %arrayidx23, align 2, !tbaa !26
  br label %for.inc

for.inc:                                          ; preds = %for.body14
  %27 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %27, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond10, !llvm.loop !55

for.end:                                          ; preds = %for.cond.cleanup13
  br label %if.end

if.end:                                           ; preds = %for.end, %if.then
  call void @llvm.lifetime.start.p0(i64 4, ptr %x24) #6
  store i32 0, ptr %x24, align 4, !tbaa !20
  br label %for.cond25

for.cond25:                                       ; preds = %for.inc60, %if.end
  %28 = load i32, ptr %x24, align 4, !tbaa !20
  %cmp26 = icmp slt i32 %28, 160
  br i1 %cmp26, label %for.body29, label %for.cond.cleanup28

for.cond.cleanup28:                               ; preds = %for.cond25
  store i32 8, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x24) #6
  br label %for.end63

for.body29:                                       ; preds = %for.cond25
  call void @llvm.lifetime.start.p0(i64 4, ptr %d) #6
  %29 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %discriminants30 = getelementptr inbounds %struct.trace, ptr %29, i32 0, i32 4
  %30 = load i32, ptr %x24, align 4, !tbaa !20
  %arrayidx31 = getelementptr inbounds [160 x i16], ptr %discriminants30, i32 0, i32 %30
  %31 = load i16, ptr %arrayidx31, align 2, !tbaa !26
  %conv32 = sext i16 %31 to i32
  store i32 %conv32, ptr %d, align 4, !tbaa !20
  %32 = load i32, ptr %d, align 4, !tbaa !20
  %cmp33 = icmp slt i32 %32, 0
  br i1 %cmp33, label %if.then35, label %if.end36

if.then35:                                        ; preds = %for.body29
  store i32 10, ptr %cleanup.dest.slot, align 4
  br label %cleanup

if.end36:                                         ; preds = %for.body29
  %33 = load i8, ptr %count_hits.addr, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool = trunc i8 %33 to i1
  %conv37 = zext i1 %tobool to i32
  %34 = load i32, ptr %hits, align 4, !tbaa !20
  %add = add i32 %34, %conv37
  store i32 %add, ptr %hits, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 2, ptr %depth38) #6
  %35 = load ptr, ptr %object, align 4, !tbaa !12
  %z = getelementptr inbounds %struct.sphere, ptr %35, i32 0, i32 2
  %36 = load i32, ptr %z, align 4, !tbaa !43
  %37 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %roots = getelementptr inbounds %struct.trace, ptr %37, i32 0, i32 5
  %38 = load i32, ptr %d, align 4, !tbaa !20
  %arrayidx39 = getelementptr inbounds [1025 x i8], ptr %roots, i32 0, i32 %38
  %39 = load i8, ptr %arrayidx39, align 1, !tbaa !56
  %conv40 = zext i8 %39 to i32
  %sub41 = sub nsw i32 %36, %conv40
  %conv42 = trunc i32 %sub41 to i16
  store i16 %conv42, ptr %depth38, align 2, !tbaa !26
  %40 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth43 = getelementptr inbounds %struct.trace, ptr %40, i32 0, i32 6
  %41 = load i32, ptr %x24, align 4, !tbaa !20
  %arrayidx44 = getelementptr inbounds [160 x i16], ptr %depth43, i32 0, i32 %41
  %42 = load i16, ptr %arrayidx44, align 2, !tbaa !26
  %conv45 = sext i16 %42 to i32
  %cmp46 = icmp eq i32 %conv45, 0
  br i1 %cmp46, label %if.then54, label %lor.lhs.false

lor.lhs.false:                                    ; preds = %if.end36
  %43 = load i16, ptr %depth38, align 2, !tbaa !26
  %conv48 = sext i16 %43 to i32
  %44 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth49 = getelementptr inbounds %struct.trace, ptr %44, i32 0, i32 6
  %45 = load i32, ptr %x24, align 4, !tbaa !20
  %arrayidx50 = getelementptr inbounds [160 x i16], ptr %depth49, i32 0, i32 %45
  %46 = load i16, ptr %arrayidx50, align 2, !tbaa !26
  %conv51 = sext i16 %46 to i32
  %cmp52 = icmp slt i32 %conv48, %conv51
  br i1 %cmp52, label %if.then54, label %if.end59

if.then54:                                        ; preds = %lor.lhs.false, %if.end36
  %47 = load i16, ptr %depth38, align 2, !tbaa !26
  %48 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth55 = getelementptr inbounds %struct.trace, ptr %48, i32 0, i32 6
  %49 = load i32, ptr %x24, align 4, !tbaa !20
  %arrayidx56 = getelementptr inbounds [160 x i16], ptr %depth55, i32 0, i32 %49
  store i16 %47, ptr %arrayidx56, align 2, !tbaa !26
  %50 = load i32, ptr %s, align 4, !tbaa !20
  %conv57 = trunc i32 %50 to i8
  %51 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_index = getelementptr inbounds %struct.trace, ptr %51, i32 0, i32 7
  %52 = load i32, ptr %x24, align 4, !tbaa !20
  %arrayidx58 = getelementptr inbounds [160 x i8], ptr %object_index, i32 0, i32 %52
  store i8 %conv57, ptr %arrayidx58, align 1, !tbaa !56
  br label %if.end59

if.end59:                                         ; preds = %if.then54, %lor.lhs.false
  call void @llvm.lifetime.end.p0(i64 2, ptr %depth38) #6
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup

cleanup:                                          ; preds = %if.end59, %if.then35
  call void @llvm.lifetime.end.p0(i64 4, ptr %d) #6
  %cleanup.dest = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest, label %unreachable [
    i32 0, label %cleanup.cont
    i32 10, label %for.inc60
  ]

cleanup.cont:                                     ; preds = %cleanup
  br label %for.inc60

for.inc60:                                        ; preds = %cleanup.cont, %cleanup
  %53 = load i32, ptr %x24, align 4, !tbaa !20
  %inc61 = add nsw i32 %53, 1
  store i32 %inc61, ptr %x24, align 4, !tbaa !20
  br label %for.cond25, !llvm.loop !57

for.end63:                                        ; preds = %for.cond.cleanup28
  call void @llvm.lifetime.end.p0(i64 2, ptr %row_term) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %dy) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %object) #6
  br label %for.inc64

for.inc64:                                        ; preds = %for.end63
  %54 = load i32, ptr %s, align 4, !tbaa !20
  %inc65 = add i32 %54, 1
  store i32 %inc65, ptr %s, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !58

for.end67:                                        ; preds = %for.cond.cleanup
  %55 = load i32, ptr %hits, align 4, !tbaa !20
  store i32 1, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %hits) #6
  ret i32 %55

unreachable:                                      ; preds = %cleanup
  unreachable
}

; Function Attrs: nounwind
define internal zeroext i1 @in_shadow(ptr noundef %work, ptr noundef %lamp, i32 noundef %x, i32 noundef %y) #0 {
entry:
  %retval = alloca i1, align 1
  %work.addr = alloca ptr, align 4
  %lamp.addr = alloca ptr, align 4
  %x.addr = alloca i32, align 4
  %y.addr = alloca i32, align 4
  %s = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %object = alloca ptr, align 4
  %dx = alloca i32, align 4
  %dy = alloca i32, align 4
  %dz = alloca i32, align 4
  %dot = alloca i32, align 4
  %distance = alloca i32, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store ptr %lamp, ptr %lamp.addr, align 4, !tbaa !12
  store i32 %x, ptr %x.addr, align 4, !tbaa !20
  store i32 %y, ptr %y.addr, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #6
  store i32 0, ptr %s, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %entry
  %0 = load i32, ptr %s, align 4, !tbaa !20
  %1 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_count = getelementptr inbounds %struct.trace, ptr %1, i32 0, i32 1
  %2 = load i32, ptr %object_count, align 4, !tbaa !21
  %cmp = icmp ult i32 %0, %2
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  br label %cleanup39

for.body:                                         ; preds = %for.cond
  %3 = load i32, ptr %x.addr, align 4, !tbaa !20
  %mul = mul nsw i32 32, %3
  %4 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %projected_x = getelementptr inbounds %struct.light, ptr %4, i32 0, i32 4
  %5 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [3 x i32], ptr %projected_x, i32 0, i32 %5
  %6 = load i32, ptr %arrayidx, align 4, !tbaa !20
  %sub = sub nsw i32 %mul, %6
  %7 = call i32 @llvm.abs.i32(i32 %sub, i1 true)
  %8 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %reach_x = getelementptr inbounds %struct.light, ptr %8, i32 0, i32 6
  %9 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx1 = getelementptr inbounds [3 x i32], ptr %reach_x, i32 0, i32 %9
  %10 = load i32, ptr %arrayidx1, align 4, !tbaa !20
  %cmp2 = icmp sgt i32 %7, %10
  br i1 %cmp2, label %if.then, label %lor.lhs.false

lor.lhs.false:                                    ; preds = %for.body
  %11 = load i32, ptr %y.addr, align 4, !tbaa !20
  %mul3 = mul nsw i32 32, %11
  %12 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %projected_y = getelementptr inbounds %struct.light, ptr %12, i32 0, i32 5
  %13 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx4 = getelementptr inbounds [3 x i32], ptr %projected_y, i32 0, i32 %13
  %14 = load i32, ptr %arrayidx4, align 4, !tbaa !20
  %sub5 = sub nsw i32 %mul3, %14
  %15 = call i32 @llvm.abs.i32(i32 %sub5, i1 true)
  %16 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %reach_y = getelementptr inbounds %struct.light, ptr %16, i32 0, i32 7
  %17 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx6 = getelementptr inbounds [3 x i32], ptr %reach_y, i32 0, i32 %17
  %18 = load i32, ptr %arrayidx6, align 4, !tbaa !20
  %cmp7 = icmp sgt i32 %15, %18
  br i1 %cmp7, label %if.then, label %if.end

if.then:                                          ; preds = %lor.lhs.false, %for.body
  br label %for.inc

if.end:                                           ; preds = %lor.lhs.false
  call void @llvm.lifetime.start.p0(i64 4, ptr %object) #6
  %19 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects = getelementptr inbounds %struct.trace, ptr %19, i32 0, i32 0
  %20 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx8 = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 %20
  store ptr %arrayidx8, ptr %object, align 4, !tbaa !12
  call void @llvm.lifetime.start.p0(i64 4, ptr %dx) #6
  %21 = load ptr, ptr %object, align 4, !tbaa !12
  %x9 = getelementptr inbounds %struct.sphere, ptr %21, i32 0, i32 0
  %22 = load i32, ptr %x9, align 4, !tbaa !45
  %23 = load i32, ptr %x.addr, align 4, !tbaa !20
  %sub10 = sub nsw i32 %22, %23
  store i32 %sub10, ptr %dx, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %dy) #6
  %24 = load ptr, ptr %object, align 4, !tbaa !12
  %y11 = getelementptr inbounds %struct.sphere, ptr %24, i32 0, i32 1
  %25 = load i32, ptr %y11, align 4, !tbaa !46
  %26 = load i32, ptr %y.addr, align 4, !tbaa !20
  %sub12 = sub nsw i32 %25, %26
  store i32 %sub12, ptr %dy, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %dz) #6
  %27 = load ptr, ptr %object, align 4, !tbaa !12
  %z = getelementptr inbounds %struct.sphere, ptr %27, i32 0, i32 2
  %28 = load i32, ptr %z, align 4, !tbaa !43
  %sub13 = sub nsw i32 156, %28
  store i32 %sub13, ptr %dz, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %dot) #6
  %29 = load i32, ptr %dx, align 4, !tbaa !20
  %30 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %x14 = getelementptr inbounds %struct.light, ptr %30, i32 0, i32 0
  %31 = load i32, ptr %x14, align 4, !tbaa !37
  %mul15 = mul nsw i32 %29, %31
  %32 = load i32, ptr %dy, align 4, !tbaa !20
  %33 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %y16 = getelementptr inbounds %struct.light, ptr %33, i32 0, i32 1
  %34 = load i32, ptr %y16, align 4, !tbaa !39
  %mul17 = mul nsw i32 %32, %34
  %add = add nsw i32 %mul15, %mul17
  %35 = load i32, ptr %dz, align 4, !tbaa !20
  %mul18 = mul nsw i32 32, %35
  %add19 = add nsw i32 %add, %mul18
  store i32 %add19, ptr %dot, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %distance) #6
  %36 = load i32, ptr %dx, align 4, !tbaa !20
  %37 = load i32, ptr %dx, align 4, !tbaa !20
  %mul20 = mul nsw i32 %36, %37
  %38 = load i32, ptr %dy, align 4, !tbaa !20
  %39 = load i32, ptr %dy, align 4, !tbaa !20
  %mul21 = mul nsw i32 %38, %39
  %add22 = add nsw i32 %mul20, %mul21
  %40 = load i32, ptr %dz, align 4, !tbaa !20
  %41 = load i32, ptr %dz, align 4, !tbaa !20
  %mul23 = mul nsw i32 %40, %41
  %add24 = add nsw i32 %add22, %mul23
  %42 = load ptr, ptr %object, align 4, !tbaa !12
  %radius = getelementptr inbounds %struct.sphere, ptr %42, i32 0, i32 3
  %43 = load i32, ptr %radius, align 4, !tbaa !47
  %44 = load ptr, ptr %object, align 4, !tbaa !12
  %radius25 = getelementptr inbounds %struct.sphere, ptr %44, i32 0, i32 3
  %45 = load i32, ptr %radius25, align 4, !tbaa !47
  %mul26 = mul nsw i32 %43, %45
  %sub27 = sub nsw i32 %add24, %mul26
  store i32 %sub27, ptr %distance, align 4, !tbaa !20
  %46 = load i32, ptr %dot, align 4, !tbaa !20
  %cmp28 = icmp sgt i32 %46, 0
  br i1 %cmp28, label %land.lhs.true, label %if.end33

land.lhs.true:                                    ; preds = %if.end
  %47 = load i32, ptr %distance, align 4, !tbaa !20
  %48 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %norm_squared = getelementptr inbounds %struct.light, ptr %48, i32 0, i32 2
  %49 = load i32, ptr %norm_squared, align 4, !tbaa !40
  %mul29 = mul nsw i32 %47, %49
  %50 = load i32, ptr %dot, align 4, !tbaa !20
  %51 = load i32, ptr %dot, align 4, !tbaa !20
  %mul30 = mul nsw i32 %50, %51
  %cmp31 = icmp sle i32 %mul29, %mul30
  br i1 %cmp31, label %if.then32, label %if.end33

if.then32:                                        ; preds = %land.lhs.true
  store i1 true, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup

if.end33:                                         ; preds = %land.lhs.true, %if.end
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup

cleanup:                                          ; preds = %if.end33, %if.then32
  call void @llvm.lifetime.end.p0(i64 4, ptr %distance) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %dot) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %dz) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %dy) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %dx) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %object) #6
  %cleanup.dest = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest, label %cleanup39 [
    i32 0, label %cleanup.cont
  ]

cleanup.cont:                                     ; preds = %cleanup
  br label %for.inc

for.inc:                                          ; preds = %cleanup.cont, %if.then
  %52 = load i32, ptr %s, align 4, !tbaa !20
  %inc = add i32 %52, 1
  store i32 %inc, ptr %s, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !59

cleanup39:                                        ; preds = %cleanup, %for.cond.cleanup
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #6
  %cleanup.dest40 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest40, label %unreachable [
    i32 2, label %for.end
    i32 1, label %return
  ]

for.end:                                          ; preds = %cleanup39
  store i1 false, ptr %retval, align 1
  br label %return

return:                                           ; preds = %for.end, %cleanup39
  %53 = load i1, ptr %retval, align 1
  ret i1 %53

unreachable:                                      ; preds = %cleanup39
  unreachable
}

; Function Attrs: nounwind
define internal zeroext i16 @shade_sphere(ptr noundef %work, ptr noundef %lamp, i32 noundef %x, i32 noundef %y) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %lamp.addr = alloca ptr, align 4
  %x.addr = alloca i32, align 4
  %y.addr = alloca i32, align 4
  %object = alloca ptr, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store ptr %lamp, ptr %lamp.addr, align 4, !tbaa !12
  store i32 %x, ptr %x.addr, align 4, !tbaa !20
  store i32 %y, ptr %y.addr, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %object) #6
  %0 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects = getelementptr inbounds %struct.trace, ptr %0, i32 0, i32 0
  %1 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_index = getelementptr inbounds %struct.trace, ptr %1, i32 0, i32 7
  %2 = load i32, ptr %x.addr, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [160 x i8], ptr %object_index, i32 0, i32 %2
  %3 = load i8, ptr %arrayidx, align 1, !tbaa !56
  %idxprom = zext i8 %3 to i32
  %arrayidx1 = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 %idxprom
  store ptr %arrayidx1, ptr %object, align 4, !tbaa !12
  %4 = load ptr, ptr %object, align 4, !tbaa !12
  %red = getelementptr inbounds %struct.sphere, ptr %4, i32 0, i32 4
  %5 = load i32, ptr %red, align 4, !tbaa !60
  %6 = load ptr, ptr %object, align 4, !tbaa !12
  %green = getelementptr inbounds %struct.sphere, ptr %6, i32 0, i32 5
  %7 = load i32, ptr %green, align 4, !tbaa !61
  %8 = load ptr, ptr %object, align 4, !tbaa !12
  %blue = getelementptr inbounds %struct.sphere, ptr %8, i32 0, i32 6
  %9 = load i32, ptr %blue, align 4, !tbaa !62
  %10 = load ptr, ptr %object, align 4, !tbaa !12
  %11 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %12 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth = getelementptr inbounds %struct.trace, ptr %12, i32 0, i32 6
  %13 = load i32, ptr %x.addr, align 4, !tbaa !20
  %arrayidx2 = getelementptr inbounds [160 x i16], ptr %depth, i32 0, i32 %13
  %14 = load i16, ptr %arrayidx2, align 2, !tbaa !26
  %conv = sext i16 %14 to i32
  %15 = load i32, ptr %x.addr, align 4, !tbaa !20
  %16 = load i32, ptr %y.addr, align 4, !tbaa !20
  %call = call i32 @sphere_scale(ptr noundef %10, ptr noundef %11, i32 noundef %conv, i32 noundef %15, i32 noundef %16)
  %call3 = call zeroext i16 @rgb565(i32 noundef %5, i32 noundef %7, i32 noundef %9, i32 noundef %call)
  call void @llvm.lifetime.end.p0(i64 4, ptr %object) #6
  ret i16 %call3
}

; Function Attrs: nounwind
define internal zeroext i16 @shade_floor(i32 noundef %x, i32 noundef %y, i1 noundef zeroext %shadow) #0 {
entry:
  %x.addr = alloca i32, align 4
  %y.addr = alloca i32, align 4
  %shadow.addr = alloca i8, align 1
  %checker = alloca i32, align 4
  %level = alloca i32, align 4
  store i32 %x, ptr %x.addr, align 4, !tbaa !20
  store i32 %y, ptr %y.addr, align 4, !tbaa !20
  %frombool = zext i1 %shadow to i8
  store i8 %frombool, ptr %shadow.addr, align 1, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 4, ptr %checker) #6
  %0 = load i32, ptr %x.addr, align 4, !tbaa !20
  %div = sdiv i32 %0, 16
  %1 = load i32, ptr %y.addr, align 4, !tbaa !20
  %div1 = sdiv i32 %1, 16
  %xor = xor i32 %div, %div1
  %and = and i32 %xor, 1
  store i32 %and, ptr %checker, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %level) #6
  %2 = load i32, ptr %checker, align 4, !tbaa !20
  %tobool = icmp ne i32 %2, 0
  %3 = zext i1 %tobool to i64
  %cond = select i1 %tobool, i32 177, i32 117
  store i32 %cond, ptr %level, align 4, !tbaa !20
  %4 = load i8, ptr %shadow.addr, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool2 = trunc i8 %4 to i1
  br i1 %tobool2, label %cond.true, label %cond.false

cond.true:                                        ; preds = %entry
  %5 = load i32, ptr %level, align 4, !tbaa !20
  %div3 = sdiv i32 %5, 3
  br label %cond.end

cond.false:                                       ; preds = %entry
  %6 = load i32, ptr %level, align 4, !tbaa !20
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond4 = phi i32 [ %div3, %cond.true ], [ %6, %cond.false ]
  %call = call zeroext i16 @rgb565(i32 noundef 105, i32 noundef 134, i32 noundef 158, i32 noundef %cond4)
  call void @llvm.lifetime.end.p0(i64 4, ptr %level) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %checker) #6
  ret i16 %call
}

; Function Attrs: nounwind
define internal void @hash_pixel(ptr noundef %stats, i16 noundef zeroext %pixel) #0 {
entry:
  %stats.addr = alloca ptr, align 4
  %pixel.addr = alloca i16, align 2
  store ptr %stats, ptr %stats.addr, align 4, !tbaa !12
  store i16 %pixel, ptr %pixel.addr, align 2, !tbaa !26
  %0 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %checksum = getelementptr inbounds %struct.raytrace_demo_stats, ptr %0, i32 0, i32 7
  %1 = load i32, ptr %checksum, align 4, !tbaa !52
  %2 = load i16, ptr %pixel.addr, align 2, !tbaa !26
  %conv = zext i16 %2 to i32
  %and = and i32 %conv, 255
  %xor = xor i32 %1, %and
  %mul = mul i32 %xor, 16777619
  %3 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %checksum1 = getelementptr inbounds %struct.raytrace_demo_stats, ptr %3, i32 0, i32 7
  store i32 %mul, ptr %checksum1, align 4, !tbaa !52
  %4 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %checksum2 = getelementptr inbounds %struct.raytrace_demo_stats, ptr %4, i32 0, i32 7
  %5 = load i32, ptr %checksum2, align 4, !tbaa !52
  %6 = load i16, ptr %pixel.addr, align 2, !tbaa !26
  %conv3 = zext i16 %6 to i32
  %shr = ashr i32 %conv3, 8
  %xor4 = xor i32 %5, %shr
  %mul5 = mul i32 %xor4, 16777619
  %7 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %checksum6 = getelementptr inbounds %struct.raytrace_demo_stats, ptr %7, i32 0, i32 7
  store i32 %mul5, ptr %checksum6, align 4, !tbaa !52
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_intersections(ptr noundef %depth, i32 noundef %stride_pixels, ptr noundef %scene, i32 noundef %mode, ptr noundef %stats) #0 {
entry:
  %retval = alloca i1, align 1
  %depth.addr = alloca ptr, align 4
  %stride_pixels.addr = alloca i32, align 4
  %scene.addr = alloca ptr, align 4
  %mode.addr = alloca i32, align 4
  %stats.addr = alloca ptr, align 4
  %work = alloca %struct.trace, align 16
  %y = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %hits = alloca i32, align 4
  %x = alloca i32, align 4
  store ptr %depth, ptr %depth.addr, align 4, !tbaa !12
  store i32 %stride_pixels, ptr %stride_pixels.addr, align 4, !tbaa !20
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  store ptr %stats, ptr %stats.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %1 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %2 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %3 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call = call zeroext i1 @valid(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3)
  br i1 %call, label %if.end, label %if.then

if.then:                                          ; preds = %entry
  store i1 false, ptr %retval, align 1
  br label %return

if.end:                                           ; preds = %entry
  call void @llvm.lifetime.start.p0(i64 2896, ptr %work) #6
  %4 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  call void @prepare(ptr noundef %work, ptr noundef %4)
  %5 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool = icmp ne ptr %5, null
  br i1 %tobool, label %if.then1, label %if.end2

if.then1:                                         ; preds = %if.end
  %6 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %7 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %8 = load i32, ptr %object_count, align 4, !tbaa !21
  call void @start_stats(ptr noundef %6, i32 noundef %7, i32 noundef %8)
  br label %if.end2

if.end2:                                          ; preds = %if.then1, %if.end
  call void @llvm.lifetime.start.p0(i64 4, ptr %y) #6
  store i32 0, ptr %y, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc19, %if.end2
  %9 = load i32, ptr %y, align 4, !tbaa !20
  %cmp = icmp slt i32 %9, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %y) #6
  br label %for.end21

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %hits) #6
  %10 = load i32, ptr %y, align 4, !tbaa !20
  %11 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %12 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %cmp3 = icmp ne ptr %12, null
  %call4 = call i32 @trace_row(ptr noundef %work, i32 noundef %10, i32 noundef %11, i1 noundef zeroext %cmp3)
  store i32 %call4, ptr %hits, align 4, !tbaa !20
  %13 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %14 = load i32, ptr %y, align 4, !tbaa !20
  %15 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %mul = mul i32 %14, %15
  %add.ptr = getelementptr inbounds i16, ptr %13, i32 %mul
  %depth5 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %arraydecay = getelementptr inbounds [160 x i16], ptr %depth5, i32 0, i32 0
  call void @llvm.memcpy.p0.p0.i32(ptr align 2 %add.ptr, ptr align 2 %arraydecay, i32 320, i1 false)
  %16 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool6 = icmp ne ptr %16, null
  br i1 %tobool6, label %if.then7, label %if.end18

if.then7:                                         ; preds = %for.body
  %17 = load i32, ptr %hits, align 4, !tbaa !20
  %18 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %18, i32 0, i32 2
  %19 = load i32, ptr %sphere_hits, align 4, !tbaa !23
  %add = add i32 %19, %17
  store i32 %add, ptr %sphere_hits, align 4, !tbaa !23
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond8

for.cond8:                                        ; preds = %for.inc, %if.then7
  %20 = load i32, ptr %x, align 4, !tbaa !20
  %cmp9 = icmp slt i32 %20, 160
  br i1 %cmp9, label %for.body11, label %for.cond.cleanup10

for.cond.cleanup10:                               ; preds = %for.cond8
  store i32 5, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  br label %for.end

for.body11:                                       ; preds = %for.cond8
  %depth12 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %21 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [160 x i16], ptr %depth12, i32 0, i32 %21
  %22 = load i16, ptr %arrayidx, align 2, !tbaa !26
  %conv = sext i16 %22 to i32
  %cmp13 = icmp ne i32 %conv, 0
  %conv14 = zext i1 %cmp13 to i32
  %23 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %23, i32 0, i32 3
  %24 = load i32, ptr %hit_pixels, align 4, !tbaa !31
  %add15 = add i32 %24, %conv14
  store i32 %add15, ptr %hit_pixels, align 4, !tbaa !31
  %25 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %depth16 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %26 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx17 = getelementptr inbounds [160 x i16], ptr %depth16, i32 0, i32 %26
  %27 = load i16, ptr %arrayidx17, align 2, !tbaa !26
  call void @hash_pixel(ptr noundef %25, i16 noundef zeroext %27)
  br label %for.inc

for.inc:                                          ; preds = %for.body11
  %28 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %28, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond8, !llvm.loop !63

for.end:                                          ; preds = %for.cond.cleanup10
  br label %if.end18

if.end18:                                         ; preds = %for.end, %for.body
  call void @llvm.lifetime.end.p0(i64 4, ptr %hits) #6
  br label %for.inc19

for.inc19:                                        ; preds = %if.end18
  %29 = load i32, ptr %y, align 4, !tbaa !20
  %inc20 = add nsw i32 %29, 1
  store i32 %inc20, ptr %y, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !64

for.end21:                                        ; preds = %for.cond.cleanup
  %30 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool22 = icmp ne ptr %30, null
  br i1 %tobool22, label %land.lhs.true, label %if.end27

land.lhs.true:                                    ; preds = %for.end21
  %31 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp23 = icmp eq i32 %31, 1
  br i1 %cmp23, label %if.then25, label %if.end27

if.then25:                                        ; preds = %land.lhs.true
  %32 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %sphere_hits26 = getelementptr inbounds %struct.raytrace_demo_stats, ptr %32, i32 0, i32 2
  %33 = load i32, ptr %sphere_hits26, align 4, !tbaa !23
  %34 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %34, i32 0, i32 6
  store i32 %33, ptr %pie_active_lanes, align 4, !tbaa !36
  br label %if.end27

if.end27:                                         ; preds = %if.then25, %land.lhs.true, %for.end21
  store i1 true, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 2896, ptr %work) #6
  br label %return

return:                                           ; preds = %if.end27, %if.then
  %35 = load i1, ptr %retval, align 1
  ret i1 %35
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i32, i1 immarg) #2

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_render_audit(ptr noundef %pixels, ptr noundef %depth, ptr noundef %ids, i32 noundef %stride_pixels, ptr noundef %scene, i32 noundef %mode) #0 {
entry:
  %retval = alloca i1, align 1
  %pixels.addr = alloca ptr, align 4
  %depth.addr = alloca ptr, align 4
  %ids.addr = alloca ptr, align 4
  %stride_pixels.addr = alloca i32, align 4
  %scene.addr = alloca ptr, align 4
  %mode.addr = alloca i32, align 4
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %y = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %row = alloca i32, align 4
  %x = alloca i32, align 4
  store ptr %pixels, ptr %pixels.addr, align 4, !tbaa !12
  store ptr %depth, ptr %depth.addr, align 4, !tbaa !12
  store ptr %ids, ptr %ids.addr, align 4, !tbaa !12
  store i32 %stride_pixels, ptr %stride_pixels.addr, align 4, !tbaa !20
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  %0 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %1 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %2 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %3 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call = call zeroext i1 @valid(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3)
  br i1 %call, label %lor.lhs.false, label %if.then

lor.lhs.false:                                    ; preds = %entry
  %4 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %5 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %6 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %7 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call1 = call zeroext i1 @valid(ptr noundef %4, i32 noundef %5, ptr noundef %6, i32 noundef %7)
  br i1 %call1, label %lor.lhs.false2, label %if.then

lor.lhs.false2:                                   ; preds = %lor.lhs.false
  %8 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %9 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %10 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %11 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call3 = call zeroext i1 @valid(ptr noundef %8, i32 noundef %9, ptr noundef %10, i32 noundef %11)
  br i1 %call3, label %if.end, label %if.then

if.then:                                          ; preds = %lor.lhs.false2, %lor.lhs.false, %entry
  store i1 false, ptr %retval, align 1
  br label %return

if.end:                                           ; preds = %lor.lhs.false2
  call void @llvm.lifetime.start.p0(i64 2896, ptr %work) #6
  %12 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  call void @prepare(ptr noundef %work, ptr noundef %12)
  call void @llvm.lifetime.start.p0(i64 64, ptr %lamp) #6
  %13 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %13, i32 0, i32 2
  %14 = load i32, ptr %light_x, align 4, !tbaa !10
  %15 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %15, i32 0, i32 3
  %16 = load i32, ptr %light_y, align 4, !tbaa !11
  call void @prepare_light(ptr dead_on_unwind writable sret(%struct.light) align 4 %lamp, ptr noundef %work, i32 noundef %14, i32 noundef %16)
  call void @llvm.lifetime.start.p0(i64 4, ptr %y) #6
  store i32 0, ptr %y, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc18, %if.end
  %17 = load i32, ptr %y, align 4, !tbaa !20
  %cmp = icmp slt i32 %17, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %y) #6
  br label %for.end20

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %row) #6
  %18 = load i32, ptr %y, align 4, !tbaa !20
  %19 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %mul = mul i32 %18, %19
  store i32 %mul, ptr %row, align 4, !tbaa !20
  %20 = load i32, ptr %y, align 4, !tbaa !20
  %21 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call4 = call i32 @trace_row(ptr noundef %work, i32 noundef %20, i32 noundef %21, i1 noundef zeroext false)
  %22 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %23 = load i32, ptr %row, align 4, !tbaa !20
  %add.ptr = getelementptr inbounds i16, ptr %22, i32 %23
  %24 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %25 = load i32, ptr %row, align 4, !tbaa !20
  %add.ptr5 = getelementptr inbounds i16, ptr %24, i32 %25
  call void @save_audit(ptr noundef %work, ptr noundef %add.ptr, ptr noundef %add.ptr5)
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond6

for.cond6:                                        ; preds = %for.inc, %for.body
  %26 = load i32, ptr %x, align 4, !tbaa !20
  %cmp7 = icmp slt i32 %26, 160
  br i1 %cmp7, label %for.body9, label %for.cond.cleanup8

for.cond.cleanup8:                                ; preds = %for.cond6
  store i32 5, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  br label %for.end

for.body9:                                        ; preds = %for.cond6
  %depth10 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %27 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [160 x i16], ptr %depth10, i32 0, i32 %27
  %28 = load i16, ptr %arrayidx, align 2, !tbaa !26
  %conv = sext i16 %28 to i32
  %tobool = icmp ne i32 %conv, 0
  br i1 %tobool, label %cond.true, label %cond.false

cond.true:                                        ; preds = %for.body9
  %29 = load i32, ptr %x, align 4, !tbaa !20
  %30 = load i32, ptr %y, align 4, !tbaa !20
  %call11 = call zeroext i16 @shade_sphere(ptr noundef %work, ptr noundef %lamp, i32 noundef %29, i32 noundef %30)
  %conv12 = zext i16 %call11 to i32
  br label %cond.end

cond.false:                                       ; preds = %for.body9
  %31 = load i32, ptr %x, align 4, !tbaa !20
  %32 = load i32, ptr %y, align 4, !tbaa !20
  %33 = load i32, ptr %x, align 4, !tbaa !20
  %34 = load i32, ptr %y, align 4, !tbaa !20
  %call13 = call zeroext i1 @in_shadow(ptr noundef %work, ptr noundef %lamp, i32 noundef %33, i32 noundef %34)
  %call14 = call zeroext i16 @shade_floor(i32 noundef %31, i32 noundef %32, i1 noundef zeroext %call13)
  %conv15 = zext i16 %call14 to i32
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %conv12, %cond.true ], [ %conv15, %cond.false ]
  %conv16 = trunc i32 %cond to i16
  %35 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %36 = load i32, ptr %row, align 4, !tbaa !20
  %37 = load i32, ptr %x, align 4, !tbaa !20
  %add = add i32 %36, %37
  %arrayidx17 = getelementptr inbounds i16, ptr %35, i32 %add
  store i16 %conv16, ptr %arrayidx17, align 2, !tbaa !26
  br label %for.inc

for.inc:                                          ; preds = %cond.end
  %38 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %38, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond6, !llvm.loop !65

for.end:                                          ; preds = %for.cond.cleanup8
  call void @llvm.lifetime.end.p0(i64 4, ptr %row) #6
  br label %for.inc18

for.inc18:                                        ; preds = %for.end
  %39 = load i32, ptr %y, align 4, !tbaa !20
  %inc19 = add nsw i32 %39, 1
  store i32 %inc19, ptr %y, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !66

for.end20:                                        ; preds = %for.cond.cleanup
  store i1 true, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 64, ptr %lamp) #6
  call void @llvm.lifetime.end.p0(i64 2896, ptr %work) #6
  br label %return

return:                                           ; preds = %for.end20, %if.then
  %40 = load i1, ptr %retval, align 1
  ret i1 %40
}

; Function Attrs: nounwind
define internal void @save_audit(ptr noundef %work, ptr noundef %depth, ptr noundef %ids) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %depth.addr = alloca ptr, align 4
  %ids.addr = alloca ptr, align 4
  %x = alloca i32, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store ptr %depth, ptr %depth.addr, align 4, !tbaa !12
  store ptr %ids, ptr %ids.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %1 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth1 = getelementptr inbounds %struct.trace, ptr %1, i32 0, i32 6
  %arraydecay = getelementptr inbounds [160 x i16], ptr %depth1, i32 0, i32 0
  call void @llvm.memcpy.p0.p0.i32(ptr align 2 %0, ptr align 2 %arraydecay, i32 320, i1 false)
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %entry
  %2 = load i32, ptr %x, align 4, !tbaa !20
  %cmp = icmp slt i32 %2, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  br label %for.end

for.body:                                         ; preds = %for.cond
  %3 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %depth2 = getelementptr inbounds %struct.trace, ptr %3, i32 0, i32 6
  %4 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [160 x i16], ptr %depth2, i32 0, i32 %4
  %5 = load i16, ptr %arrayidx, align 2, !tbaa !26
  %conv = sext i16 %5 to i32
  %tobool = icmp ne i32 %conv, 0
  br i1 %tobool, label %cond.true, label %cond.false

cond.true:                                        ; preds = %for.body
  %6 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_index = getelementptr inbounds %struct.trace, ptr %6, i32 0, i32 7
  %7 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx3 = getelementptr inbounds [160 x i8], ptr %object_index, i32 0, i32 %7
  %8 = load i8, ptr %arrayidx3, align 1, !tbaa !56
  %conv4 = zext i8 %8 to i32
  %add = add nsw i32 %conv4, 1
  %conv5 = trunc i32 %add to i16
  %conv6 = zext i16 %conv5 to i32
  br label %cond.end

cond.false:                                       ; preds = %for.body
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %conv6, %cond.true ], [ 0, %cond.false ]
  %conv7 = trunc i32 %cond to i16
  %9 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %10 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx8 = getelementptr inbounds i16, ptr %9, i32 %10
  store i16 %conv7, ptr %arrayidx8, align 2, !tbaa !26
  br label %for.inc

for.inc:                                          ; preds = %cond.end
  %11 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %11, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !67

for.end:                                          ; preds = %for.cond.cleanup
  ret void
}

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_trace_audit(ptr noundef %depth, ptr noundef %ids, i32 noundef %stride_pixels, ptr noundef %scene, i32 noundef %mode) #0 {
entry:
  %retval = alloca i1, align 1
  %depth.addr = alloca ptr, align 4
  %ids.addr = alloca ptr, align 4
  %stride_pixels.addr = alloca i32, align 4
  %scene.addr = alloca ptr, align 4
  %mode.addr = alloca i32, align 4
  %work = alloca %struct.trace, align 16
  %y = alloca i32, align 4
  %row = alloca i32, align 4
  store ptr %depth, ptr %depth.addr, align 4, !tbaa !12
  store ptr %ids, ptr %ids.addr, align 4, !tbaa !12
  store i32 %stride_pixels, ptr %stride_pixels.addr, align 4, !tbaa !20
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  %0 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %1 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %2 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %3 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call = call zeroext i1 @valid(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef %3)
  br i1 %call, label %lor.lhs.false, label %if.then

lor.lhs.false:                                    ; preds = %entry
  %4 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %5 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %6 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %7 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call1 = call zeroext i1 @valid(ptr noundef %4, i32 noundef %5, ptr noundef %6, i32 noundef %7)
  br i1 %call1, label %if.end, label %if.then

if.then:                                          ; preds = %lor.lhs.false, %entry
  store i1 false, ptr %retval, align 1
  br label %return

if.end:                                           ; preds = %lor.lhs.false
  call void @llvm.lifetime.start.p0(i64 2896, ptr %work) #6
  %8 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  call void @prepare(ptr noundef %work, ptr noundef %8)
  call void @llvm.lifetime.start.p0(i64 4, ptr %y) #6
  store i32 0, ptr %y, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %if.end
  %9 = load i32, ptr %y, align 4, !tbaa !20
  %cmp = icmp slt i32 %9, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  call void @llvm.lifetime.end.p0(i64 4, ptr %y) #6
  br label %for.end

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %row) #6
  %10 = load i32, ptr %y, align 4, !tbaa !20
  %11 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %mul = mul i32 %10, %11
  store i32 %mul, ptr %row, align 4, !tbaa !20
  %12 = load i32, ptr %y, align 4, !tbaa !20
  %13 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call2 = call i32 @trace_row(ptr noundef %work, i32 noundef %12, i32 noundef %13, i1 noundef zeroext false)
  %14 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %15 = load i32, ptr %row, align 4, !tbaa !20
  %add.ptr = getelementptr inbounds i16, ptr %14, i32 %15
  %16 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %17 = load i32, ptr %row, align 4, !tbaa !20
  %add.ptr3 = getelementptr inbounds i16, ptr %16, i32 %17
  call void @save_audit(ptr noundef %work, ptr noundef %add.ptr, ptr noundef %add.ptr3)
  call void @llvm.lifetime.end.p0(i64 4, ptr %row) #6
  br label %for.inc

for.inc:                                          ; preds = %for.body
  %18 = load i32, ptr %y, align 4, !tbaa !20
  %inc = add nsw i32 %18, 1
  store i32 %inc, ptr %y, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !68

for.end:                                          ; preds = %for.cond.cleanup
  store i1 true, ptr %retval, align 1
  call void @llvm.lifetime.end.p0(i64 2896, ptr %work) #6
  br label %return

return:                                           ; preds = %for.end, %if.then
  %19 = load i1, ptr %retval, align 1
  ret i1 %19
}

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_shade_audit(ptr noundef %pixels, ptr noundef %depth, ptr noundef %ids, i32 noundef %stride_pixels, ptr noundef %scene) #0 {
entry:
  %retval = alloca i1, align 1
  %pixels.addr = alloca ptr, align 4
  %depth.addr = alloca ptr, align 4
  %ids.addr = alloca ptr, align 4
  %stride_pixels.addr = alloca i32, align 4
  %scene.addr = alloca ptr, align 4
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %y = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %row = alloca i32, align 4
  %x = alloca i32, align 4
  %id = alloca i16, align 2
  %z = alloca i32, align 4
  %object = alloca ptr, align 4
  store ptr %pixels, ptr %pixels.addr, align 4, !tbaa !12
  store ptr %depth, ptr %depth.addr, align 4, !tbaa !12
  store ptr %ids, ptr %ids.addr, align 4, !tbaa !12
  store i32 %stride_pixels, ptr %stride_pixels.addr, align 4, !tbaa !20
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %1 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %2 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %call = call zeroext i1 @valid(ptr noundef %0, i32 noundef %1, ptr noundef %2, i32 noundef 0)
  br i1 %call, label %lor.lhs.false, label %if.then

lor.lhs.false:                                    ; preds = %entry
  %3 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %4 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %5 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %call1 = call zeroext i1 @valid(ptr noundef %3, i32 noundef %4, ptr noundef %5, i32 noundef 0)
  br i1 %call1, label %lor.lhs.false2, label %if.then

lor.lhs.false2:                                   ; preds = %lor.lhs.false
  %6 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %7 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %8 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %call3 = call zeroext i1 @valid(ptr noundef %6, i32 noundef %7, ptr noundef %8, i32 noundef 0)
  br i1 %call3, label %if.end, label %if.then

if.then:                                          ; preds = %lor.lhs.false2, %lor.lhs.false, %entry
  store i1 false, ptr %retval, align 1
  br label %return

if.end:                                           ; preds = %lor.lhs.false2
  call void @llvm.lifetime.start.p0(i64 2896, ptr %work) #6
  %9 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  call void @prepare_objects(ptr noundef %work, ptr noundef %9)
  call void @llvm.lifetime.start.p0(i64 64, ptr %lamp) #6
  %10 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %10, i32 0, i32 2
  %11 = load i32, ptr %light_x, align 4, !tbaa !10
  %12 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %light_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %12, i32 0, i32 3
  %13 = load i32, ptr %light_y, align 4, !tbaa !11
  call void @prepare_light(ptr dead_on_unwind writable sret(%struct.light) align 4 %lamp, ptr noundef %work, i32 noundef %11, i32 noundef %13)
  call void @llvm.lifetime.start.p0(i64 4, ptr %y) #6
  store i32 0, ptr %y, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc50, %if.end
  %14 = load i32, ptr %y, align 4, !tbaa !20
  %cmp = icmp slt i32 %14, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  br label %cleanup52

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %row) #6
  %15 = load i32, ptr %y, align 4, !tbaa !20
  %16 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %mul = mul i32 %15, %16
  store i32 %mul, ptr %row, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond4

for.cond4:                                        ; preds = %for.inc, %for.body
  %17 = load i32, ptr %x, align 4, !tbaa !20
  %cmp5 = icmp slt i32 %17, 160
  br i1 %cmp5, label %for.body7, label %for.cond.cleanup6

for.cond.cleanup6:                                ; preds = %for.cond4
  store i32 5, ptr %cleanup.dest.slot, align 4
  br label %cleanup45

for.body7:                                        ; preds = %for.cond4
  call void @llvm.lifetime.start.p0(i64 2, ptr %id) #6
  %18 = load ptr, ptr %ids.addr, align 4, !tbaa !12
  %19 = load i32, ptr %row, align 4, !tbaa !20
  %20 = load i32, ptr %x, align 4, !tbaa !20
  %add = add i32 %19, %20
  %arrayidx = getelementptr inbounds i16, ptr %18, i32 %add
  %21 = load i16, ptr %arrayidx, align 2, !tbaa !26
  store i16 %21, ptr %id, align 2, !tbaa !26
  call void @llvm.lifetime.start.p0(i64 4, ptr %z) #6
  %22 = load ptr, ptr %depth.addr, align 4, !tbaa !12
  %23 = load i32, ptr %row, align 4, !tbaa !20
  %24 = load i32, ptr %x, align 4, !tbaa !20
  %add8 = add i32 %23, %24
  %arrayidx9 = getelementptr inbounds i16, ptr %22, i32 %add8
  %25 = load i16, ptr %arrayidx9, align 2, !tbaa !26
  %conv = sext i16 %25 to i32
  store i32 %conv, ptr %z, align 4, !tbaa !20
  %26 = load i16, ptr %id, align 2, !tbaa !26
  %conv10 = zext i16 %26 to i32
  %cmp11 = icmp sgt i32 %conv10, 3
  br i1 %cmp11, label %if.then27, label %lor.lhs.false13

lor.lhs.false13:                                  ; preds = %for.body7
  %27 = load i32, ptr %z, align 4, !tbaa !20
  %cmp14 = icmp slt i32 %27, 0
  br i1 %cmp14, label %if.then27, label %lor.lhs.false16

lor.lhs.false16:                                  ; preds = %lor.lhs.false13
  %28 = load i32, ptr %z, align 4, !tbaa !20
  %cmp17 = icmp sgt i32 %28, 105
  br i1 %cmp17, label %if.then27, label %lor.lhs.false19

lor.lhs.false19:                                  ; preds = %lor.lhs.false16
  %29 = load i16, ptr %id, align 2, !tbaa !26
  %conv20 = zext i16 %29 to i32
  %cmp21 = icmp eq i32 %conv20, 0
  %conv22 = zext i1 %cmp21 to i32
  %30 = load i32, ptr %z, align 4, !tbaa !20
  %cmp23 = icmp eq i32 %30, 0
  %conv24 = zext i1 %cmp23 to i32
  %cmp25 = icmp ne i32 %conv22, %conv24
  br i1 %cmp25, label %if.then27, label %if.end28

if.then27:                                        ; preds = %lor.lhs.false19, %lor.lhs.false16, %lor.lhs.false13, %for.body7
  store i1 false, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup

if.end28:                                         ; preds = %lor.lhs.false19
  %31 = load i16, ptr %id, align 2, !tbaa !26
  %conv29 = zext i16 %31 to i32
  %cmp30 = icmp eq i32 %conv29, 0
  br i1 %cmp30, label %if.then32, label %if.else

if.then32:                                        ; preds = %if.end28
  %32 = load i32, ptr %x, align 4, !tbaa !20
  %33 = load i32, ptr %y, align 4, !tbaa !20
  %34 = load i32, ptr %x, align 4, !tbaa !20
  %35 = load i32, ptr %y, align 4, !tbaa !20
  %call33 = call zeroext i1 @in_shadow(ptr noundef %work, ptr noundef %lamp, i32 noundef %34, i32 noundef %35)
  %call34 = call zeroext i16 @shade_floor(i32 noundef %32, i32 noundef %33, i1 noundef zeroext %call33)
  %36 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %37 = load i32, ptr %row, align 4, !tbaa !20
  %38 = load i32, ptr %x, align 4, !tbaa !20
  %add35 = add i32 %37, %38
  %arrayidx36 = getelementptr inbounds i16, ptr %36, i32 %add35
  store i16 %call34, ptr %arrayidx36, align 2, !tbaa !26
  br label %if.end43

if.else:                                          ; preds = %if.end28
  call void @llvm.lifetime.start.p0(i64 4, ptr %object) #6
  %objects = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 0
  %39 = load i16, ptr %id, align 2, !tbaa !26
  %conv37 = zext i16 %39 to i32
  %sub = sub nsw i32 %conv37, 1
  %arrayidx38 = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 %sub
  store ptr %arrayidx38, ptr %object, align 4, !tbaa !12
  %40 = load ptr, ptr %object, align 4, !tbaa !12
  %red = getelementptr inbounds %struct.sphere, ptr %40, i32 0, i32 4
  %41 = load i32, ptr %red, align 4, !tbaa !60
  %42 = load ptr, ptr %object, align 4, !tbaa !12
  %green = getelementptr inbounds %struct.sphere, ptr %42, i32 0, i32 5
  %43 = load i32, ptr %green, align 4, !tbaa !61
  %44 = load ptr, ptr %object, align 4, !tbaa !12
  %blue = getelementptr inbounds %struct.sphere, ptr %44, i32 0, i32 6
  %45 = load i32, ptr %blue, align 4, !tbaa !62
  %46 = load ptr, ptr %object, align 4, !tbaa !12
  %47 = load i32, ptr %z, align 4, !tbaa !20
  %48 = load i32, ptr %x, align 4, !tbaa !20
  %49 = load i32, ptr %y, align 4, !tbaa !20
  %call39 = call i32 @sphere_scale(ptr noundef %46, ptr noundef %lamp, i32 noundef %47, i32 noundef %48, i32 noundef %49)
  %call40 = call zeroext i16 @rgb565(i32 noundef %41, i32 noundef %43, i32 noundef %45, i32 noundef %call39)
  %50 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %51 = load i32, ptr %row, align 4, !tbaa !20
  %52 = load i32, ptr %x, align 4, !tbaa !20
  %add41 = add i32 %51, %52
  %arrayidx42 = getelementptr inbounds i16, ptr %50, i32 %add41
  store i16 %call40, ptr %arrayidx42, align 2, !tbaa !26
  call void @llvm.lifetime.end.p0(i64 4, ptr %object) #6
  br label %if.end43

if.end43:                                         ; preds = %if.else, %if.then32
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup

cleanup:                                          ; preds = %if.end43, %if.then27
  call void @llvm.lifetime.end.p0(i64 4, ptr %z) #6
  call void @llvm.lifetime.end.p0(i64 2, ptr %id) #6
  %cleanup.dest = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest, label %cleanup45 [
    i32 0, label %cleanup.cont
  ]

cleanup.cont:                                     ; preds = %cleanup
  br label %for.inc

for.inc:                                          ; preds = %cleanup.cont
  %53 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %53, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond4, !llvm.loop !69

cleanup45:                                        ; preds = %cleanup, %for.cond.cleanup6
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  %cleanup.dest46 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest46, label %cleanup47 [
    i32 5, label %for.end
  ]

for.end:                                          ; preds = %cleanup45
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup47

cleanup47:                                        ; preds = %for.end, %cleanup45
  call void @llvm.lifetime.end.p0(i64 4, ptr %row) #6
  %cleanup.dest48 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest48, label %cleanup52 [
    i32 0, label %cleanup.cont49
  ]

cleanup.cont49:                                   ; preds = %cleanup47
  br label %for.inc50

for.inc50:                                        ; preds = %cleanup.cont49
  %54 = load i32, ptr %y, align 4, !tbaa !20
  %inc51 = add nsw i32 %54, 1
  store i32 %inc51, ptr %y, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !70

cleanup52:                                        ; preds = %cleanup47, %for.cond.cleanup
  call void @llvm.lifetime.end.p0(i64 4, ptr %y) #6
  %cleanup.dest53 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest53, label %cleanup55 [
    i32 2, label %for.end54
  ]

for.end54:                                        ; preds = %cleanup52
  store i1 true, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup55

cleanup55:                                        ; preds = %for.end54, %cleanup52
  call void @llvm.lifetime.end.p0(i64 64, ptr %lamp) #6
  call void @llvm.lifetime.end.p0(i64 2896, ptr %work) #6
  br label %return

return:                                           ; preds = %cleanup55, %if.then
  %55 = load i1, ptr %retval, align 1
  ret i1 %55
}

; Function Attrs: nounwind
define internal void @prepare_objects(ptr noundef %work, ptr noundef %scene) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %scene.addr = alloca ptr, align 4
  %.compoundliteral = alloca %struct.sphere, align 4
  %.compoundliteral3 = alloca %struct.sphere, align 4
  %.compoundliteral13 = alloca %struct.sphere, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  store ptr %scene, ptr %scene.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_count = getelementptr inbounds %struct.trace, ptr %0, i32 0, i32 1
  store i32 3, ptr %object_count, align 4, !tbaa !21
  %1 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects = getelementptr inbounds %struct.trace, ptr %1, i32 0, i32 0
  %arrayidx = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 0
  %x = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 0
  %2 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %sphere_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %2, i32 0, i32 0
  %3 = load i32, ptr %sphere_x, align 4, !tbaa !4
  store i32 %3, ptr %x, align 4, !tbaa !45
  %y = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 1
  %4 = load ptr, ptr %scene.addr, align 4, !tbaa !12
  %sphere_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %4, i32 0, i32 1
  %5 = load i32, ptr %sphere_y, align 4, !tbaa !9
  store i32 %5, ptr %y, align 4, !tbaa !46
  %z = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 2
  store i32 56, ptr %z, align 4, !tbaa !43
  %radius = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 3
  store i32 26, ptr %radius, align 4, !tbaa !47
  %red = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 4
  store i32 245, ptr %red, align 4, !tbaa !60
  %green = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 5
  store i32 83, ptr %green, align 4, !tbaa !61
  %blue = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 6
  store i32 67, ptr %blue, align 4, !tbaa !62
  call void @llvm.memcpy.p0.p0.i32(ptr align 16 %arrayidx, ptr align 4 %.compoundliteral, i32 28, i1 false), !tbaa.struct !71
  %6 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects1 = getelementptr inbounds %struct.trace, ptr %6, i32 0, i32 0
  %arrayidx2 = getelementptr inbounds [3 x %struct.sphere], ptr %objects1, i32 0, i32 1
  %x4 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 0
  store i32 100, ptr %x4, align 4, !tbaa !45
  %y5 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 1
  store i32 65, ptr %y5, align 4, !tbaa !46
  %z6 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 2
  store i32 105, ptr %z6, align 4, !tbaa !43
  %radius7 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 3
  store i32 32, ptr %radius7, align 4, !tbaa !47
  %red8 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 4
  store i32 48, ptr %red8, align 4, !tbaa !60
  %green9 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 5
  store i32 197, ptr %green9, align 4, !tbaa !61
  %blue10 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral3, i32 0, i32 6
  store i32 213, ptr %blue10, align 4, !tbaa !62
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %arrayidx2, ptr align 4 %.compoundliteral3, i32 28, i1 false), !tbaa.struct !71
  %7 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects11 = getelementptr inbounds %struct.trace, ptr %7, i32 0, i32 0
  %arrayidx12 = getelementptr inbounds [3 x %struct.sphere], ptr %objects11, i32 0, i32 2
  %x14 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 0
  store i32 58, ptr %x14, align 4, !tbaa !45
  %y15 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 1
  store i32 109, ptr %y15, align 4, !tbaa !46
  %z16 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 2
  store i32 86, ptr %z16, align 4, !tbaa !43
  %radius17 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 3
  store i32 23, ptr %radius17, align 4, !tbaa !47
  %red18 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 4
  store i32 245, ptr %red18, align 4, !tbaa !60
  %green19 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 5
  store i32 182, ptr %green19, align 4, !tbaa !61
  %blue20 = getelementptr inbounds %struct.sphere, ptr %.compoundliteral13, i32 0, i32 6
  store i32 58, ptr %blue20, align 4, !tbaa !62
  call void @llvm.memcpy.p0.p0.i32(ptr align 8 %arrayidx12, ptr align 4 %.compoundliteral13, i32 28, i1 false), !tbaa.struct !71
  ret void
}

; Function Attrs: nounwind
define internal zeroext i16 @rgb565(i32 noundef %red, i32 noundef %green, i32 noundef %blue, i32 noundef %scale) #0 {
entry:
  %red.addr = alloca i32, align 4
  %green.addr = alloca i32, align 4
  %blue.addr = alloca i32, align 4
  %scale.addr = alloca i32, align 4
  %r = alloca i32, align 4
  %g = alloca i32, align 4
  %b = alloca i32, align 4
  store i32 %red, ptr %red.addr, align 4, !tbaa !20
  store i32 %green, ptr %green.addr, align 4, !tbaa !20
  store i32 %blue, ptr %blue.addr, align 4, !tbaa !20
  store i32 %scale, ptr %scale.addr, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %r) #6
  %0 = load i32, ptr %red.addr, align 4, !tbaa !20
  %1 = load i32, ptr %scale.addr, align 4, !tbaa !20
  %mul = mul nsw i32 %0, %1
  %div = sdiv i32 %mul, 255
  store i32 %div, ptr %r, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %g) #6
  %2 = load i32, ptr %green.addr, align 4, !tbaa !20
  %3 = load i32, ptr %scale.addr, align 4, !tbaa !20
  %mul1 = mul nsw i32 %2, %3
  %div2 = sdiv i32 %mul1, 255
  store i32 %div2, ptr %g, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %b) #6
  %4 = load i32, ptr %blue.addr, align 4, !tbaa !20
  %5 = load i32, ptr %scale.addr, align 4, !tbaa !20
  %mul3 = mul nsw i32 %4, %5
  %div4 = sdiv i32 %mul3, 255
  store i32 %div4, ptr %b, align 4, !tbaa !20
  %6 = load i32, ptr %r, align 4, !tbaa !20
  %shr = ashr i32 %6, 3
  %shl = shl i32 %shr, 11
  %7 = load i32, ptr %g, align 4, !tbaa !20
  %shr5 = ashr i32 %7, 2
  %shl6 = shl i32 %shr5, 5
  %or = or i32 %shl, %shl6
  %8 = load i32, ptr %b, align 4, !tbaa !20
  %shr7 = ashr i32 %8, 3
  %or8 = or i32 %or, %shr7
  %conv = trunc i32 %or8 to i16
  call void @llvm.lifetime.end.p0(i64 4, ptr %b) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %g) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %r) #6
  ret i16 %conv
}

; Function Attrs: nounwind
define internal i32 @sphere_scale(ptr noundef %object, ptr noundef %lamp, i32 noundef %depth, i32 noundef %x, i32 noundef %y) #0 {
entry:
  %object.addr = alloca ptr, align 4
  %lamp.addr = alloca ptr, align 4
  %depth.addr = alloca i32, align 4
  %x.addr = alloca i32, align 4
  %y.addr = alloca i32, align 4
  %height = alloca i32, align 4
  %dot = alloca i32, align 4
  %bound = alloca i32, align 4
  %lit = alloca i32, align 4
  store ptr %object, ptr %object.addr, align 4, !tbaa !12
  store ptr %lamp, ptr %lamp.addr, align 4, !tbaa !12
  store i32 %depth, ptr %depth.addr, align 4, !tbaa !20
  store i32 %x, ptr %x.addr, align 4, !tbaa !20
  store i32 %y, ptr %y.addr, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %height) #6
  %0 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %z = getelementptr inbounds %struct.sphere, ptr %0, i32 0, i32 2
  %1 = load i32, ptr %z, align 4, !tbaa !43
  %2 = load i32, ptr %depth.addr, align 4, !tbaa !20
  %sub = sub nsw i32 %1, %2
  store i32 %sub, ptr %height, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %dot) #6
  %3 = load i32, ptr %x.addr, align 4, !tbaa !20
  %4 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %x1 = getelementptr inbounds %struct.sphere, ptr %4, i32 0, i32 0
  %5 = load i32, ptr %x1, align 4, !tbaa !45
  %sub2 = sub nsw i32 %3, %5
  %6 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %x3 = getelementptr inbounds %struct.light, ptr %6, i32 0, i32 0
  %7 = load i32, ptr %x3, align 4, !tbaa !37
  %mul = mul nsw i32 %sub2, %7
  %8 = load i32, ptr %y.addr, align 4, !tbaa !20
  %9 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %y4 = getelementptr inbounds %struct.sphere, ptr %9, i32 0, i32 1
  %10 = load i32, ptr %y4, align 4, !tbaa !46
  %sub5 = sub nsw i32 %8, %10
  %11 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %y6 = getelementptr inbounds %struct.light, ptr %11, i32 0, i32 1
  %12 = load i32, ptr %y6, align 4, !tbaa !39
  %mul7 = mul nsw i32 %sub5, %12
  %add = add nsw i32 %mul, %mul7
  %13 = load i32, ptr %height, align 4, !tbaa !20
  %mul8 = mul nsw i32 32, %13
  %add9 = add nsw i32 %add, %mul8
  store i32 %add9, ptr %dot, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %bound) #6
  %14 = load ptr, ptr %object.addr, align 4, !tbaa !12
  %radius = getelementptr inbounds %struct.sphere, ptr %14, i32 0, i32 3
  %15 = load i32, ptr %radius, align 4, !tbaa !47
  %16 = load ptr, ptr %lamp.addr, align 4, !tbaa !12
  %norm = getelementptr inbounds %struct.light, ptr %16, i32 0, i32 3
  %17 = load i32, ptr %norm, align 4, !tbaa !41
  %mul10 = mul nsw i32 %15, %17
  store i32 %mul10, ptr %bound, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %lit) #6
  %18 = load i32, ptr %dot, align 4, !tbaa !20
  %cmp = icmp sle i32 %18, 0
  br i1 %cmp, label %cond.true, label %cond.false

cond.true:                                        ; preds = %entry
  br label %cond.end15

cond.false:                                       ; preds = %entry
  %19 = load i32, ptr %dot, align 4, !tbaa !20
  %20 = load i32, ptr %bound, align 4, !tbaa !20
  %cmp11 = icmp sge i32 %19, %20
  br i1 %cmp11, label %cond.true12, label %cond.false13

cond.true12:                                      ; preds = %cond.false
  br label %cond.end

cond.false13:                                     ; preds = %cond.false
  %21 = load i32, ptr %dot, align 4, !tbaa !20
  %mul14 = mul nsw i32 %21, 183
  %22 = load i32, ptr %bound, align 4, !tbaa !20
  %div = sdiv i32 %mul14, %22
  br label %cond.end

cond.end:                                         ; preds = %cond.false13, %cond.true12
  %cond = phi i32 [ 183, %cond.true12 ], [ %div, %cond.false13 ]
  br label %cond.end15

cond.end15:                                       ; preds = %cond.end, %cond.true
  %cond16 = phi i32 [ 0, %cond.true ], [ %cond, %cond.end ]
  store i32 %cond16, ptr %lit, align 4, !tbaa !20
  %23 = load i32, ptr %lit, align 4, !tbaa !20
  %add17 = add nsw i32 62, %23
  call void @llvm.lifetime.end.p0(i64 4, ptr %lit) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %bound) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %dot) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %height) #6
  ret i32 %add17
}

; Function Attrs: nounwind
define dso_local zeroext i1 @raytrace_demo_render_materials(ptr noundef %pixels, i32 noundef %stride_pixels, ptr noundef %objects, i32 noundef %object_count, i16 noundef zeroext %floor_material, i32 noundef %light_x, i32 noundef %light_y, i32 noundef %mode, ptr noundef %sample, ptr noundef %context, ptr noundef %stats) #0 {
entry:
  %retval = alloca i1, align 1
  %pixels.addr = alloca ptr, align 4
  %stride_pixels.addr = alloca i32, align 4
  %objects.addr = alloca ptr, align 4
  %object_count.addr = alloca i32, align 4
  %floor_material.addr = alloca i16, align 2
  %light_x.addr = alloca i32, align 4
  %light_y.addr = alloca i32, align 4
  %mode.addr = alloca i32, align 4
  %sample.addr = alloca ptr, align 4
  %context.addr = alloca ptr, align 4
  %stats.addr = alloca ptr, align 4
  %work = alloca %struct.trace, align 16
  %s = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %object = alloca ptr, align 4
  %.compoundliteral = alloca %struct.sphere, align 4
  %lamp = alloca %struct.light, align 4
  %materials = alloca [160 x i16], align 2
  %colors = alloca [320 x i16], align 2
  %y21 = alloca i32, align 4
  %hits = alloca i32, align 4
  %row = alloca ptr, align 4
  %x28 = alloca i32, align 4
  %x53 = alloca i32, align 4
  %hit = alloca i8, align 1
  %shadow = alloca i8, align 1
  %scale = alloca i32, align 4
  %rg = alloca i16, align 2
  %b = alloca i16, align 2
  store ptr %pixels, ptr %pixels.addr, align 4, !tbaa !12
  store i32 %stride_pixels, ptr %stride_pixels.addr, align 4, !tbaa !20
  store ptr %objects, ptr %objects.addr, align 4, !tbaa !12
  store i32 %object_count, ptr %object_count.addr, align 4, !tbaa !20
  store i16 %floor_material, ptr %floor_material.addr, align 2, !tbaa !26
  store i32 %light_x, ptr %light_x.addr, align 4, !tbaa !20
  store i32 %light_y, ptr %light_y.addr, align 4, !tbaa !20
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  store ptr %sample, ptr %sample.addr, align 4, !tbaa !12
  store ptr %context, ptr %context.addr, align 4, !tbaa !12
  store ptr %stats, ptr %stats.addr, align 4, !tbaa !12
  %0 = load ptr, ptr %sample.addr, align 4, !tbaa !12
  %tobool = icmp ne ptr %0, null
  br i1 %tobool, label %lor.lhs.false, label %if.then

lor.lhs.false:                                    ; preds = %entry
  %1 = load ptr, ptr %objects.addr, align 4, !tbaa !12
  %tobool1 = icmp ne ptr %1, null
  br i1 %tobool1, label %lor.lhs.false2, label %if.then

lor.lhs.false2:                                   ; preds = %lor.lhs.false
  %2 = load i32, ptr %object_count.addr, align 4, !tbaa !20
  %cmp = icmp ugt i32 %2, 3
  br i1 %cmp, label %if.then, label %lor.lhs.false3

lor.lhs.false3:                                   ; preds = %lor.lhs.false2
  %3 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %4 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %5 = load i32, ptr %light_x.addr, align 4, !tbaa !20
  %6 = load i32, ptr %light_y.addr, align 4, !tbaa !20
  %7 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %call = call zeroext i1 @valid_output(ptr noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7)
  br i1 %call, label %if.end, label %if.then

if.then:                                          ; preds = %lor.lhs.false3, %lor.lhs.false2, %lor.lhs.false, %entry
  store i1 false, ptr %retval, align 1
  br label %return

if.end:                                           ; preds = %lor.lhs.false3
  call void @llvm.lifetime.start.p0(i64 2896, ptr %work) #6
  %8 = load i32, ptr %object_count.addr, align 4, !tbaa !20
  %object_count4 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  store i32 %8, ptr %object_count4, align 4, !tbaa !21
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #6
  store i32 0, ptr %s, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %if.end
  %9 = load i32, ptr %s, align 4, !tbaa !20
  %10 = load i32, ptr %object_count.addr, align 4, !tbaa !20
  %cmp5 = icmp ult i32 %9, %10
  br i1 %cmp5, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  br label %cleanup15

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %object) #6
  %11 = load ptr, ptr %objects.addr, align 4, !tbaa !12
  %12 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds %struct.raytrace_demo_object, ptr %11, i32 %12
  store ptr %arrayidx, ptr %object, align 4, !tbaa !12
  %13 = load ptr, ptr %object, align 4, !tbaa !12
  %call6 = call zeroext i1 @raytrace_demo_object_fits(ptr noundef %13)
  br i1 %call6, label %if.end8, label %if.then7

if.then7:                                         ; preds = %for.body
  store i1 false, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup

if.end8:                                          ; preds = %for.body
  %objects9 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 0
  %14 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx10 = getelementptr inbounds [3 x %struct.sphere], ptr %objects9, i32 0, i32 %14
  %x = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 0
  %15 = load ptr, ptr %object, align 4, !tbaa !12
  %x11 = getelementptr inbounds %struct.raytrace_demo_object, ptr %15, i32 0, i32 0
  %16 = load i32, ptr %x11, align 4, !tbaa !14
  store i32 %16, ptr %x, align 4, !tbaa !45
  %y = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 1
  %17 = load ptr, ptr %object, align 4, !tbaa !12
  %y12 = getelementptr inbounds %struct.raytrace_demo_object, ptr %17, i32 0, i32 1
  %18 = load i32, ptr %y12, align 4, !tbaa !17
  store i32 %18, ptr %y, align 4, !tbaa !46
  %z = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 2
  %19 = load ptr, ptr %object, align 4, !tbaa !12
  %z13 = getelementptr inbounds %struct.raytrace_demo_object, ptr %19, i32 0, i32 2
  %20 = load i32, ptr %z13, align 4, !tbaa !19
  store i32 %20, ptr %z, align 4, !tbaa !43
  %radius = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 3
  %21 = load ptr, ptr %object, align 4, !tbaa !12
  %radius14 = getelementptr inbounds %struct.raytrace_demo_object, ptr %21, i32 0, i32 3
  %22 = load i32, ptr %radius14, align 4, !tbaa !18
  store i32 %22, ptr %radius, align 4, !tbaa !47
  %red = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 4
  store i32 0, ptr %red, align 4, !tbaa !60
  %green = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 5
  store i32 0, ptr %green, align 4, !tbaa !61
  %blue = getelementptr inbounds %struct.sphere, ptr %.compoundliteral, i32 0, i32 6
  store i32 0, ptr %blue, align 4, !tbaa !62
  call void @llvm.memcpy.p0.p0.i32(ptr align 4 %arrayidx10, ptr align 4 %.compoundliteral, i32 28, i1 false), !tbaa.struct !71
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup

cleanup:                                          ; preds = %if.end8, %if.then7
  call void @llvm.lifetime.end.p0(i64 4, ptr %object) #6
  %cleanup.dest = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest, label %cleanup15 [
    i32 0, label %cleanup.cont
  ]

cleanup.cont:                                     ; preds = %cleanup
  br label %for.inc

for.inc:                                          ; preds = %cleanup.cont
  %23 = load i32, ptr %s, align 4, !tbaa !20
  %inc = add i32 %23, 1
  store i32 %inc, ptr %s, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !72

cleanup15:                                        ; preds = %cleanup, %for.cond.cleanup
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #6
  %cleanup.dest16 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest16, label %cleanup128 [
    i32 2, label %for.end
  ]

for.end:                                          ; preds = %cleanup15
  call void @prepare_tables(ptr noundef %work)
  call void @llvm.lifetime.start.p0(i64 64, ptr %lamp) #6
  %24 = load i32, ptr %light_x.addr, align 4, !tbaa !20
  %25 = load i32, ptr %light_y.addr, align 4, !tbaa !20
  call void @prepare_light(ptr dead_on_unwind writable sret(%struct.light) align 4 %lamp, ptr noundef %work, i32 noundef %24, i32 noundef %25)
  call void @llvm.lifetime.start.p0(i64 320, ptr %materials) #6
  call void @llvm.lifetime.start.p0(i64 640, ptr %colors) #6
  %26 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool17 = icmp ne ptr %26, null
  br i1 %tobool17, label %if.then18, label %if.end20

if.then18:                                        ; preds = %for.end
  %27 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %28 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %object_count19 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %29 = load i32, ptr %object_count19, align 4, !tbaa !21
  call void @start_stats(ptr noundef %27, i32 noundef %28, i32 noundef %29)
  br label %if.end20

if.end20:                                         ; preds = %if.then18, %for.end
  call void @llvm.lifetime.start.p0(i64 4, ptr %y21) #6
  store i32 0, ptr %y21, align 4, !tbaa !20
  br label %for.cond22

for.cond22:                                       ; preds = %for.inc114, %if.end20
  %30 = load i32, ptr %y21, align 4, !tbaa !20
  %cmp23 = icmp slt i32 %30, 160
  br i1 %cmp23, label %for.body25, label %for.cond.cleanup24

for.cond.cleanup24:                               ; preds = %for.cond22
  store i32 5, ptr %cleanup.dest.slot, align 4
  br label %cleanup116

for.body25:                                       ; preds = %for.cond22
  call void @llvm.lifetime.start.p0(i64 4, ptr %hits) #6
  %31 = load i32, ptr %y21, align 4, !tbaa !20
  %32 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %33 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %cmp26 = icmp ne ptr %33, null
  %call27 = call i32 @trace_row(ptr noundef %work, i32 noundef %31, i32 noundef %32, i1 noundef zeroext %cmp26)
  store i32 %call27, ptr %hits, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %row) #6
  %34 = load ptr, ptr %pixels.addr, align 4, !tbaa !12
  %35 = load i32, ptr %y21, align 4, !tbaa !20
  %36 = load i32, ptr %stride_pixels.addr, align 4, !tbaa !20
  %mul = mul i32 %35, %36
  %add.ptr = getelementptr inbounds i16, ptr %34, i32 %mul
  store ptr %add.ptr, ptr %row, align 4, !tbaa !12
  call void @llvm.lifetime.start.p0(i64 4, ptr %x28) #6
  store i32 0, ptr %x28, align 4, !tbaa !20
  br label %for.cond29

for.cond29:                                       ; preds = %for.inc42, %for.body25
  %37 = load i32, ptr %x28, align 4, !tbaa !20
  %cmp30 = icmp slt i32 %37, 160
  br i1 %cmp30, label %for.body32, label %for.cond.cleanup31

for.cond.cleanup31:                               ; preds = %for.cond29
  store i32 8, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x28) #6
  br label %for.end45

for.body32:                                       ; preds = %for.cond29
  %depth = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %38 = load i32, ptr %x28, align 4, !tbaa !20
  %arrayidx33 = getelementptr inbounds [160 x i16], ptr %depth, i32 0, i32 %38
  %39 = load i16, ptr %arrayidx33, align 2, !tbaa !26
  %conv = sext i16 %39 to i32
  %cmp34 = icmp ne i32 %conv, 0
  br i1 %cmp34, label %cond.true, label %cond.false

cond.true:                                        ; preds = %for.body32
  %40 = load ptr, ptr %objects.addr, align 4, !tbaa !12
  %object_index = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7
  %41 = load i32, ptr %x28, align 4, !tbaa !20
  %arrayidx36 = getelementptr inbounds [160 x i8], ptr %object_index, i32 0, i32 %41
  %42 = load i8, ptr %arrayidx36, align 1, !tbaa !56
  %idxprom = zext i8 %42 to i32
  %arrayidx37 = getelementptr inbounds %struct.raytrace_demo_object, ptr %40, i32 %idxprom
  %material = getelementptr inbounds %struct.raytrace_demo_object, ptr %arrayidx37, i32 0, i32 4
  %43 = load i16, ptr %material, align 4, !tbaa !73
  %conv38 = zext i16 %43 to i32
  br label %cond.end

cond.false:                                       ; preds = %for.body32
  %44 = load i16, ptr %floor_material.addr, align 2, !tbaa !26
  %conv39 = zext i16 %44 to i32
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i32 [ %conv38, %cond.true ], [ %conv39, %cond.false ]
  %conv40 = trunc i32 %cond to i16
  %45 = load i32, ptr %x28, align 4, !tbaa !20
  %arrayidx41 = getelementptr inbounds [160 x i16], ptr %materials, i32 0, i32 %45
  store i16 %conv40, ptr %arrayidx41, align 2, !tbaa !26
  br label %for.inc42

for.inc42:                                        ; preds = %cond.end
  %46 = load i32, ptr %x28, align 4, !tbaa !20
  %inc43 = add nsw i32 %46, 1
  store i32 %inc43, ptr %x28, align 4, !tbaa !20
  br label %for.cond29, !llvm.loop !74

for.end45:                                        ; preds = %for.cond.cleanup31
  %47 = load ptr, ptr %sample.addr, align 4, !tbaa !12
  %48 = load ptr, ptr %context.addr, align 4, !tbaa !12
  %49 = load i32, ptr %y21, align 4, !tbaa !20
  %arraydecay = getelementptr inbounds [160 x i16], ptr %materials, i32 0, i32 0
  %arraydecay46 = getelementptr inbounds [320 x i16], ptr %colors, i32 0, i32 0
  %call47 = call zeroext i1 %47(ptr noundef %48, i32 noundef %49, ptr noundef %arraydecay, ptr noundef %arraydecay46)
  br i1 %call47, label %if.end49, label %if.then48

if.then48:                                        ; preds = %for.end45
  store i1 false, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup110

if.end49:                                         ; preds = %for.end45
  %50 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool50 = icmp ne ptr %50, null
  br i1 %tobool50, label %if.then51, label %if.end52

if.then51:                                        ; preds = %if.end49
  %51 = load i32, ptr %hits, align 4, !tbaa !20
  %52 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %52, i32 0, i32 2
  %53 = load i32, ptr %sphere_hits, align 4, !tbaa !23
  %add = add i32 %53, %51
  store i32 %add, ptr %sphere_hits, align 4, !tbaa !23
  br label %if.end52

if.end52:                                         ; preds = %if.then51, %if.end49
  call void @llvm.lifetime.start.p0(i64 4, ptr %x53) #6
  store i32 0, ptr %x53, align 4, !tbaa !20
  br label %for.cond54

for.cond54:                                       ; preds = %for.inc106, %if.end52
  %54 = load i32, ptr %x53, align 4, !tbaa !20
  %cmp55 = icmp slt i32 %54, 160
  br i1 %cmp55, label %for.body58, label %for.cond.cleanup57

for.cond.cleanup57:                               ; preds = %for.cond54
  store i32 11, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x53) #6
  br label %for.end109

for.body58:                                       ; preds = %for.cond54
  call void @llvm.lifetime.start.p0(i64 1, ptr %hit) #6
  %depth59 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %55 = load i32, ptr %x53, align 4, !tbaa !20
  %arrayidx60 = getelementptr inbounds [160 x i16], ptr %depth59, i32 0, i32 %55
  %56 = load i16, ptr %arrayidx60, align 2, !tbaa !26
  %conv61 = sext i16 %56 to i32
  %cmp62 = icmp ne i32 %conv61, 0
  %frombool = zext i1 %cmp62 to i8
  store i8 %frombool, ptr %hit, align 1, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 1, ptr %shadow) #6
  %57 = load i8, ptr %hit, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool64 = trunc i8 %57 to i1
  br i1 %tobool64, label %land.end, label %land.rhs

land.rhs:                                         ; preds = %for.body58
  %58 = load i32, ptr %x53, align 4, !tbaa !20
  %59 = load i32, ptr %y21, align 4, !tbaa !20
  %call65 = call zeroext i1 @in_shadow(ptr noundef %work, ptr noundef %lamp, i32 noundef %58, i32 noundef %59)
  br label %land.end

land.end:                                         ; preds = %land.rhs, %for.body58
  %60 = phi i1 [ false, %for.body58 ], [ %call65, %land.rhs ]
  %frombool67 = zext i1 %60 to i8
  store i8 %frombool67, ptr %shadow, align 1, !tbaa !27
  call void @llvm.lifetime.start.p0(i64 4, ptr %scale) #6
  %61 = load i8, ptr %hit, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool68 = trunc i8 %61 to i1
  br i1 %tobool68, label %cond.true70, label %cond.false80

cond.true70:                                      ; preds = %land.end
  %objects71 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 0
  %object_index72 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7
  %62 = load i32, ptr %x53, align 4, !tbaa !20
  %arrayidx73 = getelementptr inbounds [160 x i8], ptr %object_index72, i32 0, i32 %62
  %63 = load i8, ptr %arrayidx73, align 1, !tbaa !56
  %idxprom74 = zext i8 %63 to i32
  %arrayidx75 = getelementptr inbounds [3 x %struct.sphere], ptr %objects71, i32 0, i32 %idxprom74
  %depth76 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %64 = load i32, ptr %x53, align 4, !tbaa !20
  %arrayidx77 = getelementptr inbounds [160 x i16], ptr %depth76, i32 0, i32 %64
  %65 = load i16, ptr %arrayidx77, align 2, !tbaa !26
  %conv78 = sext i16 %65 to i32
  %66 = load i32, ptr %x53, align 4, !tbaa !20
  %67 = load i32, ptr %y21, align 4, !tbaa !20
  %call79 = call i32 @sphere_scale(ptr noundef %arrayidx75, ptr noundef %lamp, i32 noundef %conv78, i32 noundef %66, i32 noundef %67)
  br label %cond.end84

cond.false80:                                     ; preds = %land.end
  %68 = load i8, ptr %shadow, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool81 = trunc i8 %68 to i1
  %69 = zext i1 %tobool81 to i64
  %cond83 = select i1 %tobool81, i32 85, i32 255
  br label %cond.end84

cond.end84:                                       ; preds = %cond.false80, %cond.true70
  %cond85 = phi i32 [ %call79, %cond.true70 ], [ %cond83, %cond.false80 ]
  store i32 %cond85, ptr %scale, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 2, ptr %rg) #6
  %70 = load i32, ptr %x53, align 4, !tbaa !20
  %mul86 = mul nsw i32 2, %70
  %arrayidx87 = getelementptr inbounds [320 x i16], ptr %colors, i32 0, i32 %mul86
  %71 = load i16, ptr %arrayidx87, align 2, !tbaa !26
  store i16 %71, ptr %rg, align 2, !tbaa !26
  call void @llvm.lifetime.start.p0(i64 2, ptr %b) #6
  %72 = load i32, ptr %x53, align 4, !tbaa !20
  %mul88 = mul nsw i32 2, %72
  %add89 = add nsw i32 %mul88, 1
  %arrayidx90 = getelementptr inbounds [320 x i16], ptr %colors, i32 0, i32 %add89
  %73 = load i16, ptr %arrayidx90, align 2, !tbaa !26
  store i16 %73, ptr %b, align 2, !tbaa !26
  %74 = load i16, ptr %rg, align 2, !tbaa !26
  %conv91 = zext i16 %74 to i32
  %shr = ashr i32 %conv91, 8
  %75 = load i16, ptr %rg, align 2, !tbaa !26
  %conv92 = zext i16 %75 to i32
  %and = and i32 %conv92, 255
  %76 = load i16, ptr %b, align 2, !tbaa !26
  %conv93 = zext i16 %76 to i32
  %77 = load i32, ptr %scale, align 4, !tbaa !20
  %call94 = call zeroext i16 @rgb565(i32 noundef %shr, i32 noundef %and, i32 noundef %conv93, i32 noundef %77)
  %78 = load ptr, ptr %row, align 4, !tbaa !12
  %79 = load i32, ptr %x53, align 4, !tbaa !20
  %arrayidx95 = getelementptr inbounds i16, ptr %78, i32 %79
  store i16 %call94, ptr %arrayidx95, align 2, !tbaa !26
  %80 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool96 = icmp ne ptr %80, null
  br i1 %tobool96, label %if.then97, label %if.end105

if.then97:                                        ; preds = %cond.end84
  %81 = load i8, ptr %hit, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool98 = trunc i8 %81 to i1
  %conv99 = zext i1 %tobool98 to i32
  %82 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %82, i32 0, i32 3
  %83 = load i32, ptr %hit_pixels, align 4, !tbaa !31
  %add100 = add i32 %83, %conv99
  store i32 %add100, ptr %hit_pixels, align 4, !tbaa !31
  %84 = load i8, ptr %shadow, align 1, !tbaa !27, !range !29, !noundef !30
  %tobool101 = trunc i8 %84 to i1
  %conv102 = zext i1 %tobool101 to i32
  %85 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %shadow_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %85, i32 0, i32 4
  %86 = load i32, ptr %shadow_pixels, align 4, !tbaa !32
  %add103 = add i32 %86, %conv102
  store i32 %add103, ptr %shadow_pixels, align 4, !tbaa !32
  %87 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %88 = load ptr, ptr %row, align 4, !tbaa !12
  %89 = load i32, ptr %x53, align 4, !tbaa !20
  %arrayidx104 = getelementptr inbounds i16, ptr %88, i32 %89
  %90 = load i16, ptr %arrayidx104, align 2, !tbaa !26
  call void @hash_pixel(ptr noundef %87, i16 noundef zeroext %90)
  br label %if.end105

if.end105:                                        ; preds = %if.then97, %cond.end84
  call void @llvm.lifetime.end.p0(i64 2, ptr %b) #6
  call void @llvm.lifetime.end.p0(i64 2, ptr %rg) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %scale) #6
  call void @llvm.lifetime.end.p0(i64 1, ptr %shadow) #6
  call void @llvm.lifetime.end.p0(i64 1, ptr %hit) #6
  br label %for.inc106

for.inc106:                                       ; preds = %if.end105
  %91 = load i32, ptr %x53, align 4, !tbaa !20
  %inc107 = add nsw i32 %91, 1
  store i32 %inc107, ptr %x53, align 4, !tbaa !20
  br label %for.cond54, !llvm.loop !75

for.end109:                                       ; preds = %for.cond.cleanup57
  store i32 0, ptr %cleanup.dest.slot, align 4
  br label %cleanup110

cleanup110:                                       ; preds = %for.end109, %if.then48
  call void @llvm.lifetime.end.p0(i64 4, ptr %row) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %hits) #6
  %cleanup.dest112 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest112, label %cleanup116 [
    i32 0, label %cleanup.cont113
  ]

cleanup.cont113:                                  ; preds = %cleanup110
  br label %for.inc114

for.inc114:                                       ; preds = %cleanup.cont113
  %92 = load i32, ptr %y21, align 4, !tbaa !20
  %inc115 = add nsw i32 %92, 1
  store i32 %inc115, ptr %y21, align 4, !tbaa !20
  br label %for.cond22, !llvm.loop !76

cleanup116:                                       ; preds = %cleanup110, %for.cond.cleanup24
  call void @llvm.lifetime.end.p0(i64 4, ptr %y21) #6
  %cleanup.dest117 = load i32, ptr %cleanup.dest.slot, align 4
  switch i32 %cleanup.dest117, label %cleanup125 [
    i32 5, label %for.end118
  ]

for.end118:                                       ; preds = %cleanup116
  %93 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %tobool119 = icmp ne ptr %93, null
  br i1 %tobool119, label %land.lhs.true, label %if.end124

land.lhs.true:                                    ; preds = %for.end118
  %94 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp120 = icmp eq i32 %94, 1
  br i1 %cmp120, label %if.then122, label %if.end124

if.then122:                                       ; preds = %land.lhs.true
  %95 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %sphere_hits123 = getelementptr inbounds %struct.raytrace_demo_stats, ptr %95, i32 0, i32 2
  %96 = load i32, ptr %sphere_hits123, align 4, !tbaa !23
  %97 = load ptr, ptr %stats.addr, align 4, !tbaa !12
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %97, i32 0, i32 6
  store i32 %96, ptr %pie_active_lanes, align 4, !tbaa !36
  br label %if.end124

if.end124:                                        ; preds = %if.then122, %land.lhs.true, %for.end118
  store i1 true, ptr %retval, align 1
  store i32 1, ptr %cleanup.dest.slot, align 4
  br label %cleanup125

cleanup125:                                       ; preds = %if.end124, %cleanup116
  call void @llvm.lifetime.end.p0(i64 640, ptr %colors) #6
  call void @llvm.lifetime.end.p0(i64 320, ptr %materials) #6
  call void @llvm.lifetime.end.p0(i64 64, ptr %lamp) #6
  br label %cleanup128

cleanup128:                                       ; preds = %cleanup125, %cleanup15
  call void @llvm.lifetime.end.p0(i64 2896, ptr %work) #6
  br label %return

return:                                           ; preds = %cleanup128, %if.then
  %98 = load i1, ptr %retval, align 1
  ret i1 %98
}

; Function Attrs: nounwind
define internal zeroext i1 @valid_output(ptr noundef %output, i32 noundef %stride, i32 noundef %light_x, i32 noundef %light_y, i32 noundef %mode) #0 {
entry:
  %output.addr = alloca ptr, align 4
  %stride.addr = alloca i32, align 4
  %light_x.addr = alloca i32, align 4
  %light_y.addr = alloca i32, align 4
  %mode.addr = alloca i32, align 4
  store ptr %output, ptr %output.addr, align 4, !tbaa !12
  store i32 %stride, ptr %stride.addr, align 4, !tbaa !20
  store i32 %light_x, ptr %light_x.addr, align 4, !tbaa !20
  store i32 %light_y, ptr %light_y.addr, align 4, !tbaa !20
  store i32 %mode, ptr %mode.addr, align 4, !tbaa !20
  %0 = load ptr, ptr %output.addr, align 4, !tbaa !12
  %tobool = icmp ne ptr %0, null
  br i1 %tobool, label %land.lhs.true, label %land.end16

land.lhs.true:                                    ; preds = %entry
  %1 = load ptr, ptr %output.addr, align 4, !tbaa !12
  %2 = ptrtoint ptr %1 to i32
  %rem = urem i32 %2, 2
  %cmp = icmp eq i32 %rem, 0
  br i1 %cmp, label %land.lhs.true1, label %land.end16

land.lhs.true1:                                   ; preds = %land.lhs.true
  %3 = load i32, ptr %stride.addr, align 4, !tbaa !20
  %cmp2 = icmp uge i32 %3, 160
  br i1 %cmp2, label %land.lhs.true3, label %land.end16

land.lhs.true3:                                   ; preds = %land.lhs.true1
  %4 = load i32, ptr %stride.addr, align 4, !tbaa !20
  %cmp4 = icmp ule i32 %4, 13506185
  br i1 %cmp4, label %land.lhs.true5, label %land.end16

land.lhs.true5:                                   ; preds = %land.lhs.true3
  %5 = load i32, ptr %light_x.addr, align 4, !tbaa !20
  %cmp6 = icmp sge i32 %5, 0
  br i1 %cmp6, label %land.lhs.true7, label %land.end16

land.lhs.true7:                                   ; preds = %land.lhs.true5
  %6 = load i32, ptr %light_x.addr, align 4, !tbaa !20
  %cmp8 = icmp slt i32 %6, 160
  br i1 %cmp8, label %land.lhs.true9, label %land.end16

land.lhs.true9:                                   ; preds = %land.lhs.true7
  %7 = load i32, ptr %light_y.addr, align 4, !tbaa !20
  %cmp10 = icmp sge i32 %7, 0
  br i1 %cmp10, label %land.lhs.true11, label %land.end16

land.lhs.true11:                                  ; preds = %land.lhs.true9
  %8 = load i32, ptr %light_y.addr, align 4, !tbaa !20
  %cmp12 = icmp slt i32 %8, 160
  br i1 %cmp12, label %land.rhs, label %land.end16

land.rhs:                                         ; preds = %land.lhs.true11
  %9 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp13 = icmp eq i32 %9, 0
  br i1 %cmp13, label %lor.end, label %lor.rhs

lor.rhs:                                          ; preds = %land.rhs
  %10 = load i32, ptr %mode.addr, align 4, !tbaa !20
  %cmp14 = icmp eq i32 %10, 1
  br i1 %cmp14, label %land.rhs15, label %land.end

land.rhs15:                                       ; preds = %lor.rhs
  br label %land.end

land.end:                                         ; preds = %land.rhs15, %lor.rhs
  %11 = phi i1 [ false, %lor.rhs ], [ true, %land.rhs15 ]
  br label %lor.end

lor.end:                                          ; preds = %land.end, %land.rhs
  %12 = phi i1 [ true, %land.rhs ], [ %11, %land.end ]
  br label %land.end16

land.end16:                                       ; preds = %lor.end, %land.lhs.true11, %land.lhs.true9, %land.lhs.true7, %land.lhs.true5, %land.lhs.true3, %land.lhs.true1, %land.lhs.true, %entry
  %13 = phi i1 [ false, %land.lhs.true11 ], [ false, %land.lhs.true9 ], [ false, %land.lhs.true7 ], [ false, %land.lhs.true5 ], [ false, %land.lhs.true3 ], [ false, %land.lhs.true1 ], [ false, %land.lhs.true ], [ false, %entry ], [ %12, %lor.end ]
  ret i1 %13
}

; Function Attrs: nounwind
define internal void @prepare_tables(ptr noundef %work) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %s = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %x = alloca i32, align 4
  %dx = alloca i32, align 4
  %root = alloca i32, align 4
  %next_square = alloca i32, align 4
  %i = alloca i32, align 4
  store ptr %work, ptr %work.addr, align 4, !tbaa !12
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #6
  store i32 0, ptr %s, align 4, !tbaa !20
  br label %for.cond

for.cond:                                         ; preds = %for.inc8, %entry
  %0 = load i32, ptr %s, align 4, !tbaa !20
  %1 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %object_count = getelementptr inbounds %struct.trace, ptr %1, i32 0, i32 1
  %2 = load i32, ptr %object_count, align 4, !tbaa !21
  %cmp = icmp ult i32 %0, %2
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #6
  br label %for.end10

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #6
  store i32 0, ptr %x, align 4, !tbaa !20
  br label %for.cond1

for.cond1:                                        ; preds = %for.inc, %for.body
  %3 = load i32, ptr %x, align 4, !tbaa !20
  %cmp2 = icmp slt i32 %3, 160
  br i1 %cmp2, label %for.body4, label %for.cond.cleanup3

for.cond.cleanup3:                                ; preds = %for.cond1
  store i32 5, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #6
  br label %for.end

for.body4:                                        ; preds = %for.cond1
  call void @llvm.lifetime.start.p0(i64 4, ptr %dx) #6
  %4 = load i32, ptr %x, align 4, !tbaa !20
  %5 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %objects = getelementptr inbounds %struct.trace, ptr %5, i32 0, i32 0
  %6 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx = getelementptr inbounds [3 x %struct.sphere], ptr %objects, i32 0, i32 %6
  %x5 = getelementptr inbounds %struct.sphere, ptr %arrayidx, i32 0, i32 0
  %7 = load i32, ptr %x5, align 4, !tbaa !45
  %sub = sub nsw i32 %4, %7
  store i32 %sub, ptr %dx, align 4, !tbaa !20
  %8 = load i32, ptr %dx, align 4, !tbaa !20
  %9 = load i32, ptr %dx, align 4, !tbaa !20
  %mul = mul nsw i32 %8, %9
  %conv = trunc i32 %mul to i16
  %10 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %x_squared = getelementptr inbounds %struct.trace, ptr %10, i32 0, i32 3
  %11 = load i32, ptr %s, align 4, !tbaa !20
  %arrayidx6 = getelementptr inbounds [3 x [160 x i16]], ptr %x_squared, i32 0, i32 %11
  %12 = load i32, ptr %x, align 4, !tbaa !20
  %arrayidx7 = getelementptr inbounds [160 x i16], ptr %arrayidx6, i32 0, i32 %12
  store i16 %conv, ptr %arrayidx7, align 2, !tbaa !26
  call void @llvm.lifetime.end.p0(i64 4, ptr %dx) #6
  br label %for.inc

for.inc:                                          ; preds = %for.body4
  %13 = load i32, ptr %x, align 4, !tbaa !20
  %inc = add nsw i32 %13, 1
  store i32 %inc, ptr %x, align 4, !tbaa !20
  br label %for.cond1, !llvm.loop !77

for.end:                                          ; preds = %for.cond.cleanup3
  br label %for.inc8

for.inc8:                                         ; preds = %for.end
  %14 = load i32, ptr %s, align 4, !tbaa !20
  %inc9 = add i32 %14, 1
  store i32 %inc9, ptr %s, align 4, !tbaa !20
  br label %for.cond, !llvm.loop !78

for.end10:                                        ; preds = %for.cond.cleanup
  call void @llvm.lifetime.start.p0(i64 4, ptr %root) #6
  store i32 0, ptr %root, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %next_square) #6
  store i32 1, ptr %next_square, align 4, !tbaa !20
  call void @llvm.lifetime.start.p0(i64 4, ptr %i) #6
  store i32 0, ptr %i, align 4, !tbaa !20
  br label %for.cond11

for.cond11:                                       ; preds = %for.inc23, %for.end10
  %15 = load i32, ptr %i, align 4, !tbaa !20
  %cmp12 = icmp sle i32 %15, 1024
  br i1 %cmp12, label %for.body15, label %for.cond.cleanup14

for.cond.cleanup14:                               ; preds = %for.cond11
  store i32 8, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %i) #6
  br label %for.end25

for.body15:                                       ; preds = %for.cond11
  %16 = load i32, ptr %i, align 4, !tbaa !20
  %17 = load i32, ptr %next_square, align 4, !tbaa !20
  %cmp16 = icmp eq i32 %16, %17
  br i1 %cmp16, label %if.then, label %if.end

if.then:                                          ; preds = %for.body15
  %18 = load i32, ptr %root, align 4, !tbaa !20
  %inc18 = add nsw i32 %18, 1
  store i32 %inc18, ptr %root, align 4, !tbaa !20
  %19 = load i32, ptr %root, align 4, !tbaa !20
  %mul19 = mul nsw i32 2, %19
  %add = add nsw i32 %mul19, 1
  %20 = load i32, ptr %next_square, align 4, !tbaa !20
  %add20 = add nsw i32 %20, %add
  store i32 %add20, ptr %next_square, align 4, !tbaa !20
  br label %if.end

if.end:                                           ; preds = %if.then, %for.body15
  %21 = load i32, ptr %root, align 4, !tbaa !20
  %conv21 = trunc i32 %21 to i8
  %22 = load ptr, ptr %work.addr, align 4, !tbaa !12
  %roots = getelementptr inbounds %struct.trace, ptr %22, i32 0, i32 5
  %23 = load i32, ptr %i, align 4, !tbaa !20
  %arrayidx22 = getelementptr inbounds [1025 x i8], ptr %roots, i32 0, i32 %23
  store i8 %conv21, ptr %arrayidx22, align 1, !tbaa !56
  br label %for.inc23

for.inc23:                                        ; preds = %if.end
  %24 = load i32, ptr %i, align 4, !tbaa !20
  %inc24 = add nsw i32 %24, 1
  store i32 %inc24, ptr %i, align 4, !tbaa !20
  br label %for.cond11, !llvm.loop !79

for.end25:                                        ; preds = %for.cond.cleanup14
  call void @llvm.lifetime.end.p0(i64 4, ptr %next_square) #6
  call void @llvm.lifetime.end.p0(i64 4, ptr %root) #6
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr nocapture writeonly, i8, i32, i1 immarg) #3

declare dso_local void @raytrace_demo_pie_row(ptr noundef, ptr noundef, ptr noundef, i32 noundef) #5

attributes #0 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #6 = { nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"target-abi", !"ilp32f"}
!2 = !{i32 8, !"SmallDataLimit", i32 8}
!3 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!4 = !{!5, !6, i64 0}
!5 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12}
!6 = !{!"int", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C/C++ TBAA"}
!9 = !{!5, !6, i64 4}
!10 = !{!5, !6, i64 8}
!11 = !{!5, !6, i64 12}
!12 = !{!13, !13, i64 0}
!13 = !{!"any pointer", !7, i64 0}
!14 = !{!15, !6, i64 0}
!15 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !16, i64 16}
!16 = !{!"short", !7, i64 0}
!17 = !{!15, !6, i64 4}
!18 = !{!15, !6, i64 12}
!19 = !{!15, !6, i64 8}
!20 = !{!6, !6, i64 0}
!21 = !{!22, !6, i64 84}
!22 = !{!"", !7, i64 0, !6, i64 84, !7, i64 96, !7, i64 1056, !7, i64 1376, !7, i64 2402, !7, i64 2722}
!23 = !{!24, !25, i64 8}
!24 = !{!"", !25, i64 0, !25, i64 4, !25, i64 8, !25, i64 12, !25, i64 16, !25, i64 20, !25, i64 24, !25, i64 28}
!25 = !{!"long", !7, i64 0}
!26 = !{!16, !16, i64 0}
!27 = !{!28, !28, i64 0}
!28 = !{!"_Bool", !7, i64 0}
!29 = !{i8 0, i8 2}
!30 = !{}
!31 = !{!24, !25, i64 12}
!32 = !{!24, !25, i64 16}
!33 = distinct !{!33, !34}
!34 = !{!"llvm.loop.mustprogress"}
!35 = distinct !{!35, !34}
!36 = !{!24, !25, i64 24}
!37 = !{!38, !6, i64 0}
!38 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !7, i64 16, !7, i64 28, !7, i64 40, !7, i64 52}
!39 = !{!38, !6, i64 4}
!40 = !{!38, !6, i64 8}
!41 = !{!38, !6, i64 12}
!42 = distinct !{!42, !34}
!43 = !{!44, !6, i64 8}
!44 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !6, i64 16, !6, i64 20, !6, i64 24}
!45 = !{!44, !6, i64 0}
!46 = !{!44, !6, i64 4}
!47 = !{!44, !6, i64 12}
!48 = distinct !{!48, !34}
!49 = !{!24, !25, i64 0}
!50 = !{!24, !25, i64 4}
!51 = !{!24, !25, i64 20}
!52 = !{!24, !25, i64 28}
!53 = !{i64 0, i64 4, !54, i64 4, i64 4, !54, i64 8, i64 4, !54, i64 12, i64 4, !54, i64 16, i64 4, !54, i64 20, i64 4, !54, i64 24, i64 4, !54, i64 28, i64 4, !54}
!54 = !{!25, !25, i64 0}
!55 = distinct !{!55, !34}
!56 = !{!7, !7, i64 0}
!57 = distinct !{!57, !34}
!58 = distinct !{!58, !34}
!59 = distinct !{!59, !34}
!60 = !{!44, !6, i64 16}
!61 = !{!44, !6, i64 20}
!62 = !{!44, !6, i64 24}
!63 = distinct !{!63, !34}
!64 = distinct !{!64, !34}
!65 = distinct !{!65, !34}
!66 = distinct !{!66, !34}
!67 = distinct !{!67, !34}
!68 = distinct !{!68, !34}
!69 = distinct !{!69, !34}
!70 = distinct !{!70, !34}
!71 = !{i64 0, i64 4, !20, i64 4, i64 4, !20, i64 8, i64 4, !20, i64 12, i64 4, !20, i64 16, i64 4, !20, i64 20, i64 4, !20, i64 24, i64 4, !20}
!72 = distinct !{!72, !34}
!73 = !{!15, !16, i64 16}
!74 = distinct !{!74, !34}
!75 = distinct !{!75, !34}
!76 = distinct !{!76, !34}
!77 = distinct !{!77, !34}
!78 = distinct !{!78, !34}
!79 = distinct !{!79, !34}
