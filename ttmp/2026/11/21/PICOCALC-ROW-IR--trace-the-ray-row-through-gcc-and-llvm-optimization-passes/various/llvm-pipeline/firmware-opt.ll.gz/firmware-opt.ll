; ModuleID = 'raw.ll'
source_filename = "firmware.i"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

%struct.raytrace_demo_scene = type { i32, i32, i32, i32 }
%struct.raytrace_demo_object = type { i32, i32, i32, i32, i16 }
%struct.trace = type { [3 x %struct.sphere], i32, [8 x i8], [3 x [160 x i16]], [160 x i16], [1025 x i8], [160 x i16], [160 x i8], [14 x i8] }
%struct.sphere = type { i32, i32, i32, i32, i32, i32, i32 }
%struct.light = type { i32, i32, i32, i32, [3 x i32], [3 x i32], [3 x i32], [3 x i32] }
%struct.raytrace_demo_stats = type { i32, i32, i32, i32, i32, i32, i32, i32 }

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define dso_local void @raytrace_demo_default_scene(ptr dead_on_unwind noalias nocapture writable writeonly sret(%struct.raytrace_demo_scene) align 4 %agg.result) local_unnamed_addr #0 {
entry:
  store i32 68, ptr %agg.result, align 4, !tbaa !4
  %sphere_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 1
  store i32 61, ptr %sphere_y, align 4, !tbaa !9
  %light_x = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 2
  store i32 31, ptr %light_x, align 4, !tbaa !10
  %light_y = getelementptr inbounds %struct.raytrace_demo_scene, ptr %agg.result, i32 0, i32 3
  store i32 25, ptr %light_y, align 4, !tbaa !11
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define dso_local noundef zeroext i1 @raytrace_demo_has_pie() local_unnamed_addr #1 {
entry:
  ret i1 true
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define dso_local zeroext i1 @raytrace_demo_object_fits(ptr noundef readonly %object) local_unnamed_addr #2 {
entry:
  %tobool.not = icmp eq ptr %object, null
  br i1 %tobool.not, label %land.end, label %land.lhs.true

land.lhs.true:                                    ; preds = %entry
  %0 = load i32, ptr %object, align 4, !tbaa !12
  %1 = add i32 %0, -32
  %or.cond = icmp ult i32 %1, 96
  br i1 %or.cond, label %land.lhs.true4, label %land.end

land.lhs.true4:                                   ; preds = %land.lhs.true
  %y = getelementptr inbounds %struct.raytrace_demo_object, ptr %object, i32 0, i32 1
  %2 = load i32, ptr %y, align 4, !tbaa !15
  %3 = add i32 %2, -32
  %or.cond14 = icmp ult i32 %3, 96
  br i1 %or.cond14, label %land.lhs.true9, label %land.end

land.lhs.true9:                                   ; preds = %land.lhs.true4
  %radius = getelementptr inbounds %struct.raytrace_demo_object, ptr %object, i32 0, i32 3
  %4 = load i32, ptr %radius, align 4, !tbaa !16
  %5 = add i32 %4, -1
  %or.cond15 = icmp ult i32 %5, 32
  br i1 %or.cond15, label %land.lhs.true14, label %land.end

land.lhs.true14:                                  ; preds = %land.lhs.true9
  %z = getelementptr inbounds %struct.raytrace_demo_object, ptr %object, i32 0, i32 2
  %6 = load i32, ptr %z, align 4, !tbaa !17
  %cmp16 = icmp sgt i32 %6, %4
  br i1 %cmp16, label %land.rhs, label %land.end

land.rhs:                                         ; preds = %land.lhs.true14
  %sub = sub nuw nsw i32 156, %4
  %cmp19 = icmp ult i32 %6, %sub
  br label %land.end

land.end:                                         ; preds = %land.rhs, %land.lhs.true14, %land.lhs.true9, %land.lhs.true4, %land.lhs.true, %entry
  %7 = phi i1 [ false, %land.lhs.true14 ], [ false, %land.lhs.true9 ], [ false, %land.lhs.true4 ], [ false, %land.lhs.true ], [ false, %entry ], [ %cmp19, %land.rhs ]
  ret i1 %7
}

; Function Attrs: nounwind
define dso_local noundef zeroext i1 @raytrace_demo_render(ptr noundef %pixels, i32 noundef %stride_pixels, ptr noundef readonly %scene, i32 noundef %mode, ptr noundef %stats) local_unnamed_addr #3 {
entry:
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %tobool.not.i = icmp eq ptr %scene, null
  br i1 %tobool.not.i, label %return, label %land.lhs.true.i

land.lhs.true.i:                                  ; preds = %entry
  %0 = load i32, ptr %scene, align 4, !tbaa !4
  %1 = add i32 %0, -32
  %or.cond.i = icmp ult i32 %1, 96
  br i1 %or.cond.i, label %land.lhs.true4.i, label %return

land.lhs.true4.i:                                 ; preds = %land.lhs.true.i
  %sphere_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 1
  %2 = load i32, ptr %sphere_y.i, align 4, !tbaa !9
  %3 = add i32 %2, -128
  %or.cond8.i = icmp ult i32 %3, -96
  %tobool.not.i.i = icmp eq ptr %pixels, null
  %or.cond9.i = or i1 %tobool.not.i.i, %or.cond8.i
  br i1 %or.cond9.i, label %return, label %valid.exit

valid.exit:                                       ; preds = %land.lhs.true4.i
  %light_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 3
  %4 = load i32, ptr %light_y.i, align 4, !tbaa !11
  %light_x.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 2
  %5 = load i32, ptr %light_x.i, align 4, !tbaa !10
  %6 = ptrtoint ptr %pixels to i32
  %rem.i.i = and i32 %6, 1
  %cmp.i.i = icmp eq i32 %rem.i.i, 0
  %7 = add i32 %stride_pixels, -160
  %8 = icmp ult i32 %7, 13506026
  %or.cond1.i.i = and i1 %cmp.i.i, %8
  %9 = icmp ult i32 %5, 160
  %or.cond3.i.i = and i1 %or.cond1.i.i, %9
  %10 = icmp ult i32 %4, 160
  %or.cond5.i.i = and i1 %10, %or.cond3.i.i
  %spec.select.i.i = icmp ult i32 %mode, 2
  %spec.select11.i.i = and i1 %spec.select.i.i, %or.cond5.i.i
  br i1 %spec.select11.i.i, label %if.end, label %return

if.end:                                           ; preds = %valid.exit
  call void @llvm.lifetime.start.p0(i64 2896, ptr nonnull %work) #11
  call fastcc void @prepare(ptr noundef nonnull %work, ptr noundef nonnull %scene)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %lamp) #11
  call fastcc void @prepare_light(ptr dead_on_unwind nonnull writable sret(%struct.light) align 4 %lamp, ptr noundef nonnull %work, i32 noundef %5, i32 noundef %4)
  %tobool = icmp ne ptr %stats, null
  br i1 %tobool, label %if.then1, label %if.end2

if.then1:                                         ; preds = %if.end
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %11 = load i32, ptr %object_count, align 4, !tbaa !18
  %mul.i = mul i32 %11, 25600
  %cmp.i = icmp eq i32 %mode, 1
  %div2.i = lshr exact i32 %mul.i, 3
  %spec.select.i = select i1 %cmp.i, i32 %div2.i, i32 0
  store i32 25600, ptr %stats, align 4, !tbaa.struct !20
  %.compoundliteral.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 4
  store i32 %mul.i, ptr %.compoundliteral.sroa.2.0..sroa_idx.i, align 4, !tbaa.struct !23
  %.compoundliteral.sroa.3.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 8
  store i32 0, ptr %.compoundliteral.sroa.3.0..sroa_idx.i, align 4, !tbaa.struct !24
  %.compoundliteral.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 12
  store i32 0, ptr %.compoundliteral.sroa.4.0..sroa_idx.i, align 4, !tbaa.struct !25
  %.compoundliteral.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 16
  store i32 0, ptr %.compoundliteral.sroa.5.0..sroa_idx.i, align 4, !tbaa.struct !26
  %.compoundliteral.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 20
  store i32 %spec.select.i, ptr %.compoundliteral.sroa.6.0..sroa_idx.i, align 4, !tbaa.struct !27
  %.compoundliteral.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 24
  store i32 0, ptr %.compoundliteral.sroa.7.0..sroa_idx.i, align 4, !tbaa.struct !28
  %.compoundliteral.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 28
  store i32 -2128831035, ptr %.compoundliteral.sroa.8.0..sroa_idx.i, align 4, !tbaa.struct !29
  br label %if.end2

if.end2:                                          ; preds = %if.then1, %if.end
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 2
  %12 = load i32, ptr %lamp, align 4
  %y6.i.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 1
  %13 = load i32, ptr %y6.i.i, align 4
  %norm.i.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 3
  %14 = load i32, ptr %norm.i.i, align 4
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 3
  %shadow_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 4
  %checksum.i = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 7
  br label %for.body

for.cond.cleanup:                                 ; preds = %for.cond.cleanup10
  %cmp40 = icmp eq i32 %mode, 1
  %or.cond = and i1 %cmp40, %tobool
  br i1 %or.cond, label %if.then42, label %if.end44

for.body:                                         ; preds = %if.end2, %for.cond.cleanup10
  %y.048 = phi i32 [ 0, %if.end2 ], [ %inc37, %for.cond.cleanup10 ]
  %call4 = call fastcc i32 @trace_row(ptr noundef nonnull %work, i32 noundef %y.048, i32 noundef %mode, i1 noundef zeroext %tobool)
  %mul = mul i32 %y.048, %stride_pixels
  %add.ptr = getelementptr inbounds i16, ptr %pixels, i32 %mul
  br i1 %tobool, label %if.then6, label %for.body11.preheader

for.body11.preheader:                             ; preds = %if.then6, %for.body
  br label %for.body11

if.then6:                                         ; preds = %for.body
  %15 = load i32, ptr %sphere_hits, align 4, !tbaa !30
  %add = add i32 %15, %call4
  store i32 %add, ptr %sphere_hits, align 4, !tbaa !30
  br label %for.body11.preheader

for.cond.cleanup10:                               ; preds = %if.end35
  %inc37 = add nuw nsw i32 %y.048, 1
  %exitcond49.not = icmp eq i32 %inc37, 160
  br i1 %exitcond49.not, label %for.cond.cleanup, label %for.body, !llvm.loop !32

for.body11:                                       ; preds = %for.body11.preheader, %if.end35
  %x.047 = phi i32 [ %inc, %if.end35 ], [ 0, %for.body11.preheader ]
  %arrayidx = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x.047
  %16 = load i16, ptr %arrayidx, align 2, !tbaa !34
  %cmp12 = icmp ne i16 %16, 0
  br i1 %cmp12, label %cond.true, label %cond.false

cond.true:                                        ; preds = %for.body11
  %arrayidx.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x.047
  %17 = load i8, ptr %arrayidx.i, align 1, !tbaa !35
  %idxprom.i = zext i8 %17 to i32
  %arrayidx1.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i
  %red.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 4
  %18 = load i32, ptr %red.i, align 4, !tbaa !36
  %green.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 5
  %19 = load i32, ptr %green.i, align 4, !tbaa !38
  %blue.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 6
  %20 = load i32, ptr %blue.i, align 4, !tbaa !39
  %conv.i = sext i16 %16 to i32
  %z.i.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 2
  %21 = load i32, ptr %z.i.i, align 4, !tbaa !40
  %sub.i.i = sub nsw i32 %21, %conv.i
  %22 = load i32, ptr %arrayidx1.i, align 4, !tbaa !41
  %sub2.i.i = sub nsw i32 %x.047, %22
  %mul.i.i = mul nsw i32 %sub2.i.i, %12
  %y4.i.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 1
  %23 = load i32, ptr %y4.i.i, align 4, !tbaa !42
  %sub5.i.i = sub nsw i32 %y.048, %23
  %mul7.i.i = mul nsw i32 %sub5.i.i, %13
  %mul8.i.i = shl nsw i32 %sub.i.i, 5
  %add.i.i = add i32 %mul.i.i, %mul8.i.i
  %add9.i.i = add i32 %add.i.i, %mul7.i.i
  %radius.i.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 3
  %24 = load i32, ptr %radius.i.i, align 4, !tbaa !43
  %mul10.i.i = mul nsw i32 %14, %24
  %cmp.i.i36 = icmp slt i32 %add9.i.i, 1
  br i1 %cmp.i.i36, label %shade_sphere.exit, label %cond.false.i.i

cond.false.i.i:                                   ; preds = %cond.true
  %cmp11.not.i.i = icmp slt i32 %add9.i.i, %mul10.i.i
  br i1 %cmp11.not.i.i, label %cond.false13.i.i, label %shade_sphere.exit

cond.false13.i.i:                                 ; preds = %cond.false.i.i
  %mul14.i.i = mul nsw i32 %add9.i.i, 183
  %div.i.i = sdiv i32 %mul14.i.i, %mul10.i.i
  %25 = add nsw i32 %div.i.i, 62
  br label %shade_sphere.exit

shade_sphere.exit:                                ; preds = %cond.true, %cond.false.i.i, %cond.false13.i.i
  %cond16.i.i = phi i32 [ 62, %cond.true ], [ %25, %cond.false13.i.i ], [ 245, %cond.false.i.i ]
  %mul.i8.i = mul nsw i32 %cond16.i.i, %18
  %div.i9.i = sdiv i32 %mul.i8.i, 255
  %mul1.i.i = mul nsw i32 %cond16.i.i, %19
  %div2.i.i = sdiv i32 %mul1.i.i, 255
  %mul3.i.i = mul nsw i32 %cond16.i.i, %20
  %div4.i.i = sdiv i32 %mul3.i.i, 255
  %26 = shl i32 %div.i9.i, 8
  %shl.i.i = and i32 %26, 63488
  %27 = shl nsw i32 %div2.i.i, 3
  %shl6.i.i = and i32 %27, 65504
  %shr7.i.i = lshr i32 %div4.i.i, 3
  %or.i.i = or i32 %shl6.i.i, %shr7.i.i
  %or8.i.i = or i32 %or.i.i, %shl.i.i
  %conv.i.i = trunc i32 %or8.i.i to i16
  br label %cond.end

cond.false:                                       ; preds = %for.body11
  %call15 = call fastcc zeroext i1 @in_shadow(ptr noundef nonnull %work, ptr noundef nonnull %lamp, i32 noundef %x.047, i32 noundef %y.048)
  %div1.i4546 = xor i32 %x.047, %y.048
  %28 = and i32 %div1.i4546, 16
  %tobool.not.i37 = icmp eq i32 %28, 0
  %cond.i = select i1 %tobool.not.i37, i32 117, i32 177
  %div3.lhs.trunc.i = trunc i32 %cond.i to i8
  %div32.i = udiv i8 %div3.lhs.trunc.i, 3
  %div3.zext.i = zext nneg i8 %div32.i to i32
  %cond4.i = select i1 %call15, i32 %div3.zext.i, i32 %cond.i
  %29 = trunc i32 %cond4.i to i16
  %div.i3.lhs.trunc.i = mul nuw nsw i16 %29, 105
  %div.i34.i = udiv i16 %div.i3.lhs.trunc.i, 255
  %div2.i5.lhs.trunc.i = mul nuw nsw i16 %29, 134
  %div2.i56.i = udiv i16 %div2.i5.lhs.trunc.i, 255
  %div4.i7.lhs.trunc.i = mul nuw nsw i16 %29, 158
  %div4.i78.i = udiv i16 %div4.i7.lhs.trunc.i, 255
  %30 = shl nuw nsw i16 %div.i34.i, 8
  %31 = and i16 %30, 30720
  %32 = shl nuw nsw i16 %div2.i56.i, 3
  %33 = and i16 %32, 4064
  %34 = lshr i16 %div4.i78.i, 3
  %or.i9.i = or i16 %33, %34
  %or8.i10.i = or i16 %or.i9.i, %31
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %shade_sphere.exit
  %35 = phi i1 [ false, %shade_sphere.exit ], [ %call15, %cond.false ]
  %cond.in = phi i16 [ %conv.i.i, %shade_sphere.exit ], [ %or8.i10.i, %cond.false ]
  %arrayidx26 = getelementptr inbounds i16, ptr %add.ptr, i32 %x.047
  store i16 %cond.in, ptr %arrayidx26, align 2, !tbaa !34
  br i1 %tobool, label %if.then28, label %if.end35

if.then28:                                        ; preds = %cond.end
  %conv30 = zext i1 %cmp12 to i32
  %36 = load i32, ptr %hit_pixels, align 4, !tbaa !44
  %add31 = add i32 %36, %conv30
  store i32 %add31, ptr %hit_pixels, align 4, !tbaa !44
  %conv33 = zext i1 %35 to i32
  %37 = load i32, ptr %shadow_pixels, align 4, !tbaa !45
  %add34 = add i32 %37, %conv33
  store i32 %add34, ptr %shadow_pixels, align 4, !tbaa !45
  %38 = load i32, ptr %checksum.i, align 4, !tbaa !46
  %conv.i38 = zext i16 %cond.in to i32
  %and.i39 = and i32 %conv.i38, 255
  %xor.i40 = xor i32 %38, %and.i39
  %mul.i41 = mul i32 %xor.i40, 16777619
  %shr.i = lshr i32 %conv.i38, 8
  %xor4.i = xor i32 %mul.i41, %shr.i
  %mul5.i = mul i32 %xor4.i, 16777619
  store i32 %mul5.i, ptr %checksum.i, align 4, !tbaa !46
  br label %if.end35

if.end35:                                         ; preds = %if.then28, %cond.end
  %inc = add nuw nsw i32 %x.047, 1
  %exitcond.not = icmp eq i32 %inc, 160
  br i1 %exitcond.not, label %for.cond.cleanup10, label %for.body11, !llvm.loop !47

if.then42:                                        ; preds = %for.cond.cleanup
  %39 = load i32, ptr %sphere_hits, align 4, !tbaa !30
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 6
  store i32 %39, ptr %pie_active_lanes, align 4, !tbaa !48
  br label %if.end44

if.end44:                                         ; preds = %if.then42, %for.cond.cleanup
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %lamp) #11
  call void @llvm.lifetime.end.p0(i64 2896, ptr nonnull %work) #11
  br label %return

return:                                           ; preds = %entry, %land.lhs.true.i, %land.lhs.true4.i, %valid.exit, %if.end44
  %40 = phi i1 [ false, %valid.exit ], [ true, %if.end44 ], [ false, %land.lhs.true4.i ], [ false, %land.lhs.true.i ], [ false, %entry ]
  ret i1 %40
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc void @prepare(ptr nocapture noundef writeonly %work, ptr nocapture noundef readonly %scene) unnamed_addr #5 {
entry:
  %object_count.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  store i32 3, ptr %object_count.i, align 4, !tbaa !18
  %0 = load i32, ptr %scene, align 4, !tbaa !4
  %sphere_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 1
  %1 = load i32, ptr %sphere_y.i, align 4, !tbaa !9
  store i32 %0, ptr %work, align 16, !tbaa.struct !49
  %.compoundliteral.sroa.2.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 4
  store i32 %1, ptr %.compoundliteral.sroa.2.0.arrayidx.sroa_idx.i, align 4, !tbaa.struct !51
  %.compoundliteral.sroa.3.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 8
  store i32 56, ptr %.compoundliteral.sroa.3.0.arrayidx.sroa_idx.i, align 8, !tbaa.struct !52
  %.compoundliteral.sroa.4.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 12
  store i32 26, ptr %.compoundliteral.sroa.4.0.arrayidx.sroa_idx.i, align 4, !tbaa.struct !53
  %.compoundliteral.sroa.5.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 16
  store i32 245, ptr %.compoundliteral.sroa.5.0.arrayidx.sroa_idx.i, align 16, !tbaa.struct !54
  %.compoundliteral.sroa.6.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 20
  store i32 83, ptr %.compoundliteral.sroa.6.0.arrayidx.sroa_idx.i, align 4, !tbaa.struct !55
  %.compoundliteral.sroa.7.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 24
  store i32 67, ptr %.compoundliteral.sroa.7.0.arrayidx.sroa_idx.i, align 8, !tbaa.struct !56
  %arrayidx2.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1
  store i32 100, ptr %arrayidx2.i, align 4, !tbaa.struct !49
  %.compoundliteral3.sroa.2.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 1
  store i32 65, ptr %.compoundliteral3.sroa.2.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !51
  %.compoundliteral3.sroa.3.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 2
  store i32 105, ptr %.compoundliteral3.sroa.3.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !52
  %.compoundliteral3.sroa.4.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 3
  store i32 32, ptr %.compoundliteral3.sroa.4.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !53
  %.compoundliteral3.sroa.5.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 4
  store i32 48, ptr %.compoundliteral3.sroa.5.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !54
  %.compoundliteral3.sroa.6.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 5
  store i32 197, ptr %.compoundliteral3.sroa.6.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !55
  %.compoundliteral3.sroa.7.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 6
  store i32 213, ptr %.compoundliteral3.sroa.7.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !56
  %arrayidx12.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2
  store i32 58, ptr %arrayidx12.i, align 8, !tbaa.struct !49
  %.compoundliteral13.sroa.2.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 1
  store i32 109, ptr %.compoundliteral13.sroa.2.0.arrayidx12.sroa_idx.i, align 4, !tbaa.struct !51
  %.compoundliteral13.sroa.3.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 2
  store i32 86, ptr %.compoundliteral13.sroa.3.0.arrayidx12.sroa_idx.i, align 8, !tbaa.struct !52
  %.compoundliteral13.sroa.4.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 3
  store i32 23, ptr %.compoundliteral13.sroa.4.0.arrayidx12.sroa_idx.i, align 4, !tbaa.struct !53
  %.compoundliteral13.sroa.5.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 4
  store i32 245, ptr %.compoundliteral13.sroa.5.0.arrayidx12.sroa_idx.i, align 8, !tbaa.struct !54
  %.compoundliteral13.sroa.6.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 5
  store i32 182, ptr %.compoundliteral13.sroa.6.0.arrayidx12.sroa_idx.i, align 4, !tbaa.struct !55
  %.compoundliteral13.sroa.7.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 6
  store i32 58, ptr %.compoundliteral13.sroa.7.0.arrayidx12.sroa_idx.i, align 8, !tbaa.struct !56
  br label %for.body4.i

for.body4.i.1:                                    ; preds = %for.body4.i, %for.body4.i.1
  %x.017.i.1 = phi i32 [ %inc.i.1, %for.body4.i.1 ], [ 0, %for.body4.i ]
  %sub.i.1 = add nsw i32 %x.017.i.1, -100
  %mul.i.1 = mul nsw i32 %sub.i.1, %sub.i.1
  %conv.i.1 = trunc i32 %mul.i.1 to i16
  %arrayidx7.i.1 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 3, i32 1, i32 %x.017.i.1
  store i16 %conv.i.1, ptr %arrayidx7.i.1, align 2, !tbaa !34
  %inc.i.1 = add nuw nsw i32 %x.017.i.1, 1
  %exitcond.not.i.1 = icmp eq i32 %inc.i.1, 160
  br i1 %exitcond.not.i.1, label %for.body4.i.2, label %for.body4.i.1, !llvm.loop !57

for.body4.i.2:                                    ; preds = %for.body4.i.1, %for.body4.i.2
  %x.017.i.2 = phi i32 [ %inc.i.2, %for.body4.i.2 ], [ 0, %for.body4.i.1 ]
  %sub.i.2 = add nsw i32 %x.017.i.2, -58
  %mul.i.2 = mul nsw i32 %sub.i.2, %sub.i.2
  %conv.i.2 = trunc i32 %mul.i.2 to i16
  %arrayidx7.i.2 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 3, i32 2, i32 %x.017.i.2
  store i16 %conv.i.2, ptr %arrayidx7.i.2, align 2, !tbaa !34
  %inc.i.2 = add nuw nsw i32 %x.017.i.2, 1
  %exitcond.not.i.2 = icmp eq i32 %inc.i.2, 160
  br i1 %exitcond.not.i.2, label %for.body15.i, label %for.body4.i.2, !llvm.loop !57

for.body4.i:                                      ; preds = %for.body4.i, %entry
  %x.017.i = phi i32 [ 0, %entry ], [ %inc.i, %for.body4.i ]
  %sub.i = sub nsw i32 %x.017.i, %0
  %mul.i = mul nsw i32 %sub.i, %sub.i
  %conv.i = trunc i32 %mul.i to i16
  %arrayidx7.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 3, i32 0, i32 %x.017.i
  store i16 %conv.i, ptr %arrayidx7.i, align 2, !tbaa !34
  %inc.i = add nuw nsw i32 %x.017.i, 1
  %exitcond.not.i = icmp eq i32 %inc.i, 160
  br i1 %exitcond.not.i, label %for.body4.i.1, label %for.body4.i, !llvm.loop !57

for.body15.i:                                     ; preds = %for.body4.i.2, %for.body15.i
  %i.022.i = phi i32 [ %inc24.i, %for.body15.i ], [ 0, %for.body4.i.2 ]
  %next_square.021.i = phi i32 [ %next_square.1.i, %for.body15.i ], [ 1, %for.body4.i.2 ]
  %root.020.i = phi i32 [ %root.1.i, %for.body15.i ], [ 0, %for.body4.i.2 ]
  %cmp16.i = icmp eq i32 %i.022.i, %next_square.021.i
  %inc18.i = add nsw i32 %root.020.i, 1
  %mul19.i = shl nsw i32 %inc18.i, 1
  %add.i = or disjoint i32 %mul19.i, 1
  %root.1.i = select i1 %cmp16.i, i32 %inc18.i, i32 %root.020.i
  %add20.i = select i1 %cmp16.i, i32 %add.i, i32 0
  %next_square.1.i = add nsw i32 %add20.i, %next_square.021.i
  %conv21.i = trunc i32 %root.1.i to i8
  %arrayidx22.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 5, i32 %i.022.i
  store i8 %conv21.i, ptr %arrayidx22.i, align 1, !tbaa !35
  %inc24.i = add nuw nsw i32 %i.022.i, 1
  %exitcond24.not.i = icmp eq i32 %inc24.i, 1025
  br i1 %exitcond24.not.i, label %prepare_tables.exit, label %for.body15.i, !llvm.loop !58

prepare_tables.exit:                              ; preds = %for.body15.i
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc void @prepare_light(ptr dead_on_unwind noalias nocapture writable sret(%struct.light) align 4 %agg.result, ptr nocapture noundef readonly %work, i32 noundef %light_x, i32 noundef %light_y) unnamed_addr #5 {
entry:
  %0 = getelementptr inbounds i8, ptr %agg.result, i32 16
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(64) %0, i8 0, i64 48, i1 false)
  %1 = mul i32 %light_x, 3
  %mul = add i32 %1, -240
  %div = sdiv i32 %mul, 10
  store i32 %div, ptr %agg.result, align 4, !tbaa !59
  %y = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 1
  %2 = mul i32 %light_y, 3
  %mul2 = add i32 %2, -240
  %div3 = sdiv i32 %mul2, 10
  store i32 %div3, ptr %y, align 4, !tbaa !61
  %mul6 = mul nsw i32 %div, %div
  %mul9 = mul nsw i32 %div3, %div3
  %add = add nuw i32 %mul6, 1024
  %add10 = add nuw i32 %add, %mul9
  %norm_squared = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 2
  store i32 %add10, ptr %norm_squared, align 4, !tbaa !62
  br label %while.cond

while.cond:                                       ; preds = %while.cond, %entry
  %storemerge = phi i32 [ 32, %entry ], [ %add12, %while.cond ]
  %add12 = add nuw nsw i32 %storemerge, 1
  %mul15 = mul nsw i32 %add12, %add12
  %cmp.not = icmp ugt i32 %mul15, %add10
  br i1 %cmp.not, label %for.cond.preheader, label %while.cond, !llvm.loop !63

for.cond.preheader:                               ; preds = %while.cond
  %norm = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 3
  store i32 %storemerge, ptr %norm, align 4, !tbaa !64
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %3 = load i32, ptr %object_count, align 4, !tbaa !18
  %cmp1813.not = icmp eq i32 %3, 0
  br i1 %cmp1813.not, label %for.cond.cleanup, label %for.body

for.cond.cleanup:                                 ; preds = %for.body, %for.cond.preheader
  ret void

for.body:                                         ; preds = %for.cond.preheader, %for.body
  %s.014 = phi i32 [ %inc41, %for.body ], [ 0, %for.cond.preheader ]
  %arrayidx = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.014
  %z = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.014, i32 2
  %4 = load i32, ptr %z, align 4, !tbaa !40
  %sub19 = sub nsw i32 156, %4
  %5 = load i32, ptr %arrayidx, align 4, !tbaa !41
  %mul21 = shl nsw i32 %5, 5
  %6 = load i32, ptr %agg.result, align 4, !tbaa !59
  %mul23 = mul nsw i32 %6, %sub19
  %sub24 = sub nsw i32 %mul21, %mul23
  %arrayidx25 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 4, i32 %s.014
  store i32 %sub24, ptr %arrayidx25, align 4, !tbaa !50
  %y26 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.014, i32 1
  %7 = load i32, ptr %y26, align 4, !tbaa !42
  %mul27 = shl nsw i32 %7, 5
  %8 = load i32, ptr %y, align 4, !tbaa !61
  %mul29 = mul nsw i32 %8, %sub19
  %sub30 = sub nsw i32 %mul27, %mul29
  %arrayidx31 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 5, i32 %s.014
  store i32 %sub30, ptr %arrayidx31, align 4, !tbaa !50
  %radius = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.014, i32 3
  %9 = load i32, ptr %radius, align 4, !tbaa !43
  %10 = load i32, ptr %agg.result, align 4, !tbaa !59
  %11 = tail call i32 @llvm.abs.i32(i32 %10, i1 true)
  %add33 = add nuw nsw i32 %11, 32
  %mul34 = mul nsw i32 %add33, %9
  %arrayidx35 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 6, i32 %s.014
  store i32 %mul34, ptr %arrayidx35, align 4, !tbaa !50
  %12 = load i32, ptr %y, align 4, !tbaa !61
  %13 = tail call i32 @llvm.abs.i32(i32 %12, i1 true)
  %add38 = add nuw nsw i32 %13, 32
  %mul39 = mul nsw i32 %add38, %9
  %arrayidx40 = getelementptr inbounds %struct.light, ptr %agg.result, i32 0, i32 7, i32 %s.014
  store i32 %mul39, ptr %arrayidx40, align 4, !tbaa !50
  %inc41 = add nuw i32 %s.014, 1
  %exitcond.not = icmp eq i32 %inc41, %3
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !llvm.loop !65
}

; Function Attrs: nounwind
define internal fastcc i32 @trace_row(ptr noundef %work, i32 noundef %y, i32 noundef %mode, i1 noundef zeroext %count_hits) unnamed_addr #3 {
entry:
  %row_term = alloca i16, align 2
  %depth = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  tail call void @llvm.memset.p0.i32(ptr noundef nonnull align 2 dereferenceable(320) %depth, i8 0, i32 320, i1 false)
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %0 = load i32, ptr %object_count, align 4, !tbaa !18
  %cmp39.not = icmp eq i32 %0, 0
  br i1 %cmp39.not, label %for.cond.cleanup, label %for.body.lr.ph

for.body.lr.ph:                                   ; preds = %entry
  %cmp5 = icmp eq i32 %mode, 1
  %discriminants = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 4
  %conv37 = zext i1 %count_hits to i32
  br label %for.body

for.cond.cleanup:                                 ; preds = %for.cond.cleanup28, %entry
  %hits.0.lcssa = phi i32 [ 0, %entry ], [ %hits.2, %for.cond.cleanup28 ]
  ret i32 %hits.0.lcssa

for.body:                                         ; preds = %for.body.lr.ph, %for.cond.cleanup28
  %hits.041 = phi i32 [ 0, %for.body.lr.ph ], [ %hits.2, %for.cond.cleanup28 ]
  %s.040 = phi i32 [ 0, %for.body.lr.ph ], [ %inc65, %for.cond.cleanup28 ]
  %y1 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.040, i32 1
  %1 = load i32, ptr %y1, align 4, !tbaa !42
  %sub = sub nsw i32 %y, %1
  call void @llvm.lifetime.start.p0(i64 2, ptr nonnull %row_term) #11
  %radius = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.040, i32 3
  %2 = load i32, ptr %radius, align 4, !tbaa !43
  %add34 = add nsw i32 %2, %sub
  %sub35 = sub nsw i32 %2, %sub
  %sub4 = mul nsw i32 %add34, %sub35
  %conv = trunc i32 %sub4 to i16
  store i16 %conv, ptr %row_term, align 2, !tbaa !34
  br i1 %cmp5, label %if.then, label %for.body14

if.then:                                          ; preds = %for.body
  %arrayidx7 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 3, i32 %s.040
  call void @raytrace_demo_pie_row(ptr noundef nonnull %arrayidx7, ptr noundef nonnull %row_term, ptr noundef nonnull %discriminants, i32 noundef 20) #11
  br label %if.end

for.body14:                                       ; preds = %for.body, %for.body14
  %x.036 = phi i32 [ %inc, %for.body14 ], [ 0, %for.body ]
  %arrayidx18 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 3, i32 %s.040, i32 %x.036
  %3 = load i16, ptr %arrayidx18, align 2, !tbaa !34
  %sub20 = sub i16 %conv, %3
  %arrayidx23 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 4, i32 %x.036
  store i16 %sub20, ptr %arrayidx23, align 2, !tbaa !34
  %inc = add nuw nsw i32 %x.036, 1
  %exitcond.not = icmp eq i32 %inc, 160
  br i1 %exitcond.not, label %if.end, label %for.body14, !llvm.loop !66

if.end:                                           ; preds = %for.body14, %if.then
  %z = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.040, i32 2
  %conv57 = trunc i32 %s.040 to i8
  br label %for.body29

for.cond.cleanup28:                               ; preds = %cleanup
  call void @llvm.lifetime.end.p0(i64 2, ptr nonnull %row_term) #11
  %inc65 = add nuw i32 %s.040, 1
  %4 = load i32, ptr %object_count, align 4, !tbaa !18
  %cmp = icmp ult i32 %inc65, %4
  br i1 %cmp, label %for.body, label %for.cond.cleanup, !llvm.loop !67

for.body29:                                       ; preds = %if.end, %cleanup
  %hits.138 = phi i32 [ %hits.041, %if.end ], [ %hits.2, %cleanup ]
  %x24.037 = phi i32 [ 0, %if.end ], [ %inc61, %cleanup ]
  %arrayidx31 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 4, i32 %x24.037
  %5 = load i16, ptr %arrayidx31, align 2, !tbaa !34
  %cmp33 = icmp slt i16 %5, 0
  br i1 %cmp33, label %cleanup, label %if.end36

if.end36:                                         ; preds = %for.body29
  %conv32 = zext nneg i16 %5 to i32
  %add = add i32 %hits.138, %conv37
  %6 = load i32, ptr %z, align 4, !tbaa !40
  %arrayidx39 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 5, i32 %conv32
  %7 = load i8, ptr %arrayidx39, align 1, !tbaa !35
  %conv40 = zext i8 %7 to i32
  %sub41 = sub nsw i32 %6, %conv40
  %conv42 = trunc i32 %sub41 to i16
  %arrayidx44 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x24.037
  %8 = load i16, ptr %arrayidx44, align 2, !tbaa !34
  %cmp46 = icmp eq i16 %8, 0
  br i1 %cmp46, label %if.then54, label %lor.lhs.false

lor.lhs.false:                                    ; preds = %if.end36
  %conv45 = sext i16 %8 to i32
  %sext = shl i32 %sub41, 16
  %conv48 = ashr exact i32 %sext, 16
  %cmp52 = icmp slt i32 %conv48, %conv45
  br i1 %cmp52, label %if.then54, label %cleanup

if.then54:                                        ; preds = %lor.lhs.false, %if.end36
  store i16 %conv42, ptr %arrayidx44, align 2, !tbaa !34
  %arrayidx58 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x24.037
  store i8 %conv57, ptr %arrayidx58, align 1, !tbaa !35
  br label %cleanup

cleanup:                                          ; preds = %lor.lhs.false, %if.then54, %for.body29
  %hits.2 = phi i32 [ %hits.138, %for.body29 ], [ %add, %if.then54 ], [ %add, %lor.lhs.false ]
  %inc61 = add nuw nsw i32 %x24.037, 1
  %exitcond42.not = icmp eq i32 %inc61, 160
  br i1 %exitcond42.not, label %for.cond.cleanup28, label %for.body29, !llvm.loop !68
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc zeroext i1 @in_shadow(ptr nocapture noundef readonly %work, ptr nocapture noundef readonly %lamp, i32 noundef %x, i32 noundef %y) unnamed_addr #6 {
entry:
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %0 = load i32, ptr %object_count, align 4, !tbaa !18
  %cmp.not29.not = icmp eq i32 %0, 0
  br i1 %cmp.not29.not, label %cleanup39, label %for.body.lr.ph

for.body.lr.ph:                                   ; preds = %entry
  %mul = shl nsw i32 %x, 5
  %mul3 = shl nsw i32 %y, 5
  %y16 = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 1
  %norm_squared = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 2
  br label %for.body

for.body:                                         ; preds = %for.body.lr.ph, %for.inc
  %cmp.not31 = phi i1 [ true, %for.body.lr.ph ], [ %cmp.not, %for.inc ]
  %s.030 = phi i32 [ 0, %for.body.lr.ph ], [ %inc, %for.inc ]
  %arrayidx = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 4, i32 %s.030
  %1 = load i32, ptr %arrayidx, align 4, !tbaa !50
  %sub = sub nsw i32 %mul, %1
  %2 = tail call i32 @llvm.abs.i32(i32 %sub, i1 true)
  %arrayidx1 = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 6, i32 %s.030
  %3 = load i32, ptr %arrayidx1, align 4, !tbaa !50
  %cmp2 = icmp sgt i32 %2, %3
  br i1 %cmp2, label %for.inc, label %lor.lhs.false

lor.lhs.false:                                    ; preds = %for.body
  %arrayidx4 = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 5, i32 %s.030
  %4 = load i32, ptr %arrayidx4, align 4, !tbaa !50
  %sub5 = sub nsw i32 %mul3, %4
  %5 = tail call i32 @llvm.abs.i32(i32 %sub5, i1 true)
  %arrayidx6 = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 7, i32 %s.030
  %6 = load i32, ptr %arrayidx6, align 4, !tbaa !50
  %cmp7 = icmp sgt i32 %5, %6
  br i1 %cmp7, label %for.inc, label %if.end

if.end:                                           ; preds = %lor.lhs.false
  %arrayidx8 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.030
  %7 = load i32, ptr %arrayidx8, align 4, !tbaa !41
  %sub10 = sub nsw i32 %7, %x
  %y11 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.030, i32 1
  %8 = load i32, ptr %y11, align 4, !tbaa !42
  %sub12 = sub nsw i32 %8, %y
  %z = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.030, i32 2
  %9 = load i32, ptr %z, align 4, !tbaa !40
  %sub13 = sub nsw i32 156, %9
  %10 = load i32, ptr %lamp, align 4, !tbaa !59
  %mul15 = mul nsw i32 %10, %sub10
  %11 = load i32, ptr %y16, align 4, !tbaa !61
  %mul17 = mul nsw i32 %11, %sub12
  %mul18 = shl nsw i32 %sub13, 5
  %add = add i32 %mul18, %mul15
  %add19 = add i32 %add, %mul17
  %cmp28 = icmp sgt i32 %add19, 0
  br i1 %cmp28, label %land.lhs.true, label %for.inc

land.lhs.true:                                    ; preds = %if.end
  %mul20 = mul nsw i32 %sub10, %sub10
  %mul21 = mul nsw i32 %sub12, %sub12
  %add22 = add nuw nsw i32 %mul21, %mul20
  %mul23 = mul nsw i32 %sub13, %sub13
  %add24 = add nuw nsw i32 %add22, %mul23
  %radius = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.030, i32 3
  %12 = load i32, ptr %radius, align 4, !tbaa !43
  %mul26 = mul nsw i32 %12, %12
  %sub27 = sub nsw i32 %add24, %mul26
  %13 = load i32, ptr %norm_squared, align 4, !tbaa !62
  %mul29 = mul nsw i32 %sub27, %13
  %mul30 = mul nsw i32 %add19, %add19
  %cmp31.not = icmp sgt i32 %mul29, %mul30
  br i1 %cmp31.not, label %for.inc, label %cleanup39

for.inc:                                          ; preds = %if.end, %land.lhs.true, %for.body, %lor.lhs.false
  %inc = add nuw i32 %s.030, 1
  %cmp.not = icmp ult i32 %inc, %0
  %exitcond.not = icmp eq i32 %inc, %0
  br i1 %exitcond.not, label %cleanup39, label %for.body, !llvm.loop !69

cleanup39:                                        ; preds = %for.inc, %land.lhs.true, %entry
  %cmp.not.lcssa = phi i1 [ false, %entry ], [ %cmp.not31, %land.lhs.true ], [ %cmp.not, %for.inc ]
  ret i1 %cmp.not.lcssa
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #4

; Function Attrs: nounwind
define dso_local noundef zeroext i1 @raytrace_demo_intersections(ptr noundef %depth, i32 noundef %stride_pixels, ptr noundef readonly %scene, i32 noundef %mode, ptr noundef %stats) local_unnamed_addr #3 {
entry:
  %work = alloca %struct.trace, align 16
  %tobool.not.i = icmp eq ptr %scene, null
  br i1 %tobool.not.i, label %return, label %land.lhs.true.i

land.lhs.true.i:                                  ; preds = %entry
  %0 = load i32, ptr %scene, align 4, !tbaa !4
  %1 = add i32 %0, -32
  %or.cond.i = icmp ult i32 %1, 96
  br i1 %or.cond.i, label %land.lhs.true4.i, label %return

land.lhs.true4.i:                                 ; preds = %land.lhs.true.i
  %sphere_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 1
  %2 = load i32, ptr %sphere_y.i, align 4, !tbaa !9
  %3 = add i32 %2, -128
  %or.cond8.i = icmp ult i32 %3, -96
  %tobool.not.i.i = icmp eq ptr %depth, null
  %or.cond9.i = or i1 %tobool.not.i.i, %or.cond8.i
  br i1 %or.cond9.i, label %return, label %valid.exit

valid.exit:                                       ; preds = %land.lhs.true4.i
  %light_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 3
  %4 = load i32, ptr %light_y.i, align 4, !tbaa !11
  %light_x.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 2
  %5 = load i32, ptr %light_x.i, align 4, !tbaa !10
  %6 = ptrtoint ptr %depth to i32
  %rem.i.i = and i32 %6, 1
  %cmp.i.i = icmp eq i32 %rem.i.i, 0
  %7 = add i32 %stride_pixels, -160
  %8 = icmp ult i32 %7, 13506026
  %or.cond1.i.i = and i1 %cmp.i.i, %8
  %9 = icmp ult i32 %5, 160
  %or.cond3.i.i = and i1 %or.cond1.i.i, %9
  %10 = icmp ult i32 %4, 160
  %or.cond5.i.i = and i1 %10, %or.cond3.i.i
  %spec.select.i.i = icmp ult i32 %mode, 2
  %spec.select11.i.i = and i1 %spec.select.i.i, %or.cond5.i.i
  br i1 %spec.select11.i.i, label %if.end, label %return

if.end:                                           ; preds = %valid.exit
  call void @llvm.lifetime.start.p0(i64 2896, ptr nonnull %work) #11
  call fastcc void @prepare(ptr noundef nonnull %work, ptr noundef nonnull %scene)
  %tobool = icmp ne ptr %stats, null
  br i1 %tobool, label %if.then1, label %if.end2

if.then1:                                         ; preds = %if.end
  %object_count = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  %11 = load i32, ptr %object_count, align 4, !tbaa !18
  %mul.i = mul i32 %11, 25600
  %cmp.i = icmp eq i32 %mode, 1
  %div2.i = lshr exact i32 %mul.i, 3
  %spec.select.i = select i1 %cmp.i, i32 %div2.i, i32 0
  store i32 25600, ptr %stats, align 4, !tbaa.struct !20
  %.compoundliteral.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 4
  store i32 %mul.i, ptr %.compoundliteral.sroa.2.0..sroa_idx.i, align 4, !tbaa.struct !23
  %.compoundliteral.sroa.3.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 8
  store i32 0, ptr %.compoundliteral.sroa.3.0..sroa_idx.i, align 4, !tbaa.struct !24
  %.compoundliteral.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 12
  store i32 0, ptr %.compoundliteral.sroa.4.0..sroa_idx.i, align 4, !tbaa.struct !25
  %.compoundliteral.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 16
  store i32 0, ptr %.compoundliteral.sroa.5.0..sroa_idx.i, align 4, !tbaa.struct !26
  %.compoundliteral.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 20
  store i32 %spec.select.i, ptr %.compoundliteral.sroa.6.0..sroa_idx.i, align 4, !tbaa.struct !27
  %.compoundliteral.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 24
  store i32 0, ptr %.compoundliteral.sroa.7.0..sroa_idx.i, align 4, !tbaa.struct !28
  %.compoundliteral.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 28
  store i32 -2128831035, ptr %.compoundliteral.sroa.8.0..sroa_idx.i, align 4, !tbaa.struct !29
  br label %if.end2

if.end2:                                          ; preds = %if.then1, %if.end
  %depth5 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 2
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 3
  %checksum.i = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 7
  br label %for.body

for.cond.cleanup:                                 ; preds = %if.end18
  %cmp23 = icmp eq i32 %mode, 1
  %or.cond = and i1 %cmp23, %tobool
  br i1 %or.cond, label %if.then25, label %if.end27

for.body:                                         ; preds = %if.end2, %if.end18
  %y.028 = phi i32 [ 0, %if.end2 ], [ %inc20, %if.end18 ]
  %call4 = call fastcc i32 @trace_row(ptr noundef nonnull %work, i32 noundef %y.028, i32 noundef %mode, i1 noundef zeroext %tobool)
  %mul = mul i32 %y.028, %stride_pixels
  %add.ptr = getelementptr inbounds i16, ptr %depth, i32 %mul
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 2 dereferenceable(320) %add.ptr, ptr noundef nonnull align 2 dereferenceable(320) %depth5, i32 320, i1 false)
  br i1 %tobool, label %if.then7, label %if.end18

if.then7:                                         ; preds = %for.body
  %12 = load i32, ptr %sphere_hits, align 4, !tbaa !30
  %add = add i32 %12, %call4
  store i32 %add, ptr %sphere_hits, align 4, !tbaa !30
  %hit_pixels.promoted = load i32, ptr %hit_pixels, align 4, !tbaa !44
  %checksum.i.promoted = load i32, ptr %checksum.i, align 4, !tbaa !46
  br label %for.body11

for.body11:                                       ; preds = %if.then7, %for.body11
  %x.027 = phi i32 [ 0, %if.then7 ], [ %inc, %for.body11 ]
  %add152326 = phi i32 [ %hit_pixels.promoted, %if.then7 ], [ %add15, %for.body11 ]
  %mul5.i2425 = phi i32 [ %checksum.i.promoted, %if.then7 ], [ %mul5.i, %for.body11 ]
  %arrayidx = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x.027
  %13 = load i16, ptr %arrayidx, align 2, !tbaa !34
  %cmp13 = icmp ne i16 %13, 0
  %conv14 = zext i1 %cmp13 to i32
  %add15 = add i32 %add152326, %conv14
  %conv.i = zext i16 %13 to i32
  %and.i = and i32 %conv.i, 255
  %xor.i = xor i32 %mul5.i2425, %and.i
  %mul.i22 = mul i32 %xor.i, 16777619
  %shr.i = lshr i32 %conv.i, 8
  %xor4.i = xor i32 %mul.i22, %shr.i
  %mul5.i = mul i32 %xor4.i, 16777619
  %inc = add nuw nsw i32 %x.027, 1
  %exitcond.not = icmp eq i32 %inc, 160
  br i1 %exitcond.not, label %if.end18.loopexit, label %for.body11, !llvm.loop !70

if.end18.loopexit:                                ; preds = %for.body11
  store i32 %add15, ptr %hit_pixels, align 4, !tbaa !44
  store i32 %mul5.i, ptr %checksum.i, align 4, !tbaa !46
  br label %if.end18

if.end18:                                         ; preds = %if.end18.loopexit, %for.body
  %inc20 = add nuw nsw i32 %y.028, 1
  %exitcond29.not = icmp eq i32 %inc20, 160
  br i1 %exitcond29.not, label %for.cond.cleanup, label %for.body, !llvm.loop !71

if.then25:                                        ; preds = %for.cond.cleanup
  %14 = load i32, ptr %sphere_hits, align 4, !tbaa !30
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 6
  store i32 %14, ptr %pie_active_lanes, align 4, !tbaa !48
  br label %if.end27

if.end27:                                         ; preds = %if.then25, %for.cond.cleanup
  call void @llvm.lifetime.end.p0(i64 2896, ptr nonnull %work) #11
  br label %return

return:                                           ; preds = %entry, %land.lhs.true.i, %land.lhs.true4.i, %valid.exit, %if.end27
  %15 = phi i1 [ false, %valid.exit ], [ true, %if.end27 ], [ false, %land.lhs.true4.i ], [ false, %land.lhs.true.i ], [ false, %entry ]
  ret i1 %15
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i32, i1 immarg) #7

; Function Attrs: nounwind
define dso_local noundef zeroext i1 @raytrace_demo_render_audit(ptr noundef %pixels, ptr noundef %depth, ptr noundef %ids, i32 noundef %stride_pixels, ptr noundef readonly %scene, i32 noundef %mode) local_unnamed_addr #3 {
entry:
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %tobool.not.i = icmp eq ptr %scene, null
  br i1 %tobool.not.i, label %return, label %land.lhs.true.i

land.lhs.true.i:                                  ; preds = %entry
  %0 = load i32, ptr %scene, align 4, !tbaa !4
  %1 = add i32 %0, -32
  %or.cond.i = icmp ult i32 %1, 96
  br i1 %or.cond.i, label %land.lhs.true4.i, label %return

land.lhs.true4.i:                                 ; preds = %land.lhs.true.i
  %sphere_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 1
  %2 = load i32, ptr %sphere_y.i, align 4, !tbaa !9
  %3 = add i32 %2, -128
  %or.cond8.i = icmp ult i32 %3, -96
  %tobool.not.i.i = icmp eq ptr %pixels, null
  %or.cond9.i = or i1 %tobool.not.i.i, %or.cond8.i
  br i1 %or.cond9.i, label %return, label %valid.exit

valid.exit:                                       ; preds = %land.lhs.true4.i
  %light_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 3
  %4 = load i32, ptr %light_y.i, align 4, !tbaa !11
  %light_x.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 2
  %5 = load i32, ptr %light_x.i, align 4, !tbaa !10
  %6 = ptrtoint ptr %pixels to i32
  %rem.i.i = and i32 %6, 1
  %cmp.i.i = icmp eq i32 %rem.i.i, 0
  %7 = add i32 %stride_pixels, -160
  %8 = icmp ult i32 %7, 13506026
  %or.cond1.i.i = and i1 %cmp.i.i, %8
  %9 = icmp ult i32 %5, 160
  %or.cond3.i.i = and i1 %or.cond1.i.i, %9
  %10 = icmp ult i32 %4, 160
  %or.cond5.i.i = and i1 %10, %or.cond3.i.i
  %spec.select.i.i = icmp ult i32 %mode, 2
  %spec.select11.i.i = and i1 %spec.select.i.i, %or.cond5.i.i
  %tobool.not.i.i35 = icmp ne ptr %depth, null
  %or.cond.not83 = and i1 %tobool.not.i.i35, %spec.select11.i.i
  %11 = ptrtoint ptr %depth to i32
  %rem.i.i40 = and i32 %11, 1
  %cmp.i.i41 = icmp eq i32 %rem.i.i40, 0
  %or.cond80 = and i1 %or.cond.not83, %cmp.i.i41
  %tobool.not.i.i54 = icmp ne ptr %ids, null
  %or.cond81.not84 = and i1 %tobool.not.i.i54, %or.cond80
  %12 = ptrtoint ptr %ids to i32
  %rem.i.i59 = and i32 %12, 1
  %cmp.i.i60 = icmp eq i32 %rem.i.i59, 0
  %or.cond82 = and i1 %or.cond81.not84, %cmp.i.i60
  br i1 %or.cond82, label %if.end, label %return

if.end:                                           ; preds = %valid.exit
  call void @llvm.lifetime.start.p0(i64 2896, ptr nonnull %work) #11
  call fastcc void @prepare(ptr noundef nonnull %work, ptr noundef nonnull %scene)
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %lamp) #11
  call fastcc void @prepare_light(ptr dead_on_unwind nonnull writable sret(%struct.light) align 4 %lamp, ptr noundef nonnull %work, i32 noundef %5, i32 noundef %4)
  %depth1.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  %13 = load i32, ptr %lamp, align 4
  %y6.i.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 1
  %14 = load i32, ptr %y6.i.i, align 4
  %norm.i.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 3
  %15 = load i32, ptr %norm.i.i, align 4
  br label %for.body

for.cond.cleanup:                                 ; preds = %for.cond.cleanup8
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %lamp) #11
  call void @llvm.lifetime.end.p0(i64 2896, ptr nonnull %work) #11
  br label %return

for.body:                                         ; preds = %if.end, %for.cond.cleanup8
  %y.078 = phi i32 [ 0, %if.end ], [ %inc19, %for.cond.cleanup8 ]
  %mul = mul i32 %y.078, %stride_pixels
  %call4 = call fastcc i32 @trace_row(ptr noundef nonnull %work, i32 noundef %y.078, i32 noundef %mode, i1 noundef zeroext false)
  %add.ptr = getelementptr inbounds i16, ptr %depth, i32 %mul
  %add.ptr5 = getelementptr inbounds i16, ptr %ids, i32 %mul
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 2 dereferenceable(320) %add.ptr, ptr noundef nonnull align 2 dereferenceable(320) %depth1.i, i32 320, i1 false)
  br label %for.body.i

for.body.i:                                       ; preds = %cond.end.i, %for.body
  %x.07.i = phi i32 [ 0, %for.body ], [ %inc.i, %cond.end.i ]
  %arrayidx.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x.07.i
  %16 = load i16, ptr %arrayidx.i, align 2, !tbaa !34
  %tobool.not.i67 = icmp eq i16 %16, 0
  br i1 %tobool.not.i67, label %cond.end.i, label %cond.true.i

cond.true.i:                                      ; preds = %for.body.i
  %arrayidx3.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x.07.i
  %17 = load i8, ptr %arrayidx3.i, align 1, !tbaa !35
  %conv4.i = zext i8 %17 to i16
  %add.i = add nuw nsw i16 %conv4.i, 1
  br label %cond.end.i

cond.end.i:                                       ; preds = %cond.true.i, %for.body.i
  %cond.i = phi i16 [ %add.i, %cond.true.i ], [ 0, %for.body.i ]
  %arrayidx8.i = getelementptr inbounds i16, ptr %add.ptr5, i32 %x.07.i
  store i16 %cond.i, ptr %arrayidx8.i, align 2, !tbaa !34
  %inc.i = add nuw nsw i32 %x.07.i, 1
  %exitcond.not.i = icmp eq i32 %inc.i, 160
  br i1 %exitcond.not.i, label %for.cond6.preheader, label %for.body.i, !llvm.loop !72

for.cond6.preheader:                              ; preds = %cond.end.i
  %18 = getelementptr i16, ptr %pixels, i32 %mul
  br label %for.body9

for.cond.cleanup8:                                ; preds = %cond.end
  %inc19 = add nuw nsw i32 %y.078, 1
  %exitcond79.not = icmp eq i32 %inc19, 160
  br i1 %exitcond79.not, label %for.cond.cleanup, label %for.body, !llvm.loop !73

for.body9:                                        ; preds = %for.cond6.preheader, %cond.end
  %x.077 = phi i32 [ 0, %for.cond6.preheader ], [ %inc, %cond.end ]
  %arrayidx = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x.077
  %19 = load i16, ptr %arrayidx, align 2, !tbaa !34
  %tobool.not = icmp eq i16 %19, 0
  br i1 %tobool.not, label %cond.false, label %cond.true

cond.true:                                        ; preds = %for.body9
  %arrayidx.i68 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x.077
  %20 = load i8, ptr %arrayidx.i68, align 1, !tbaa !35
  %idxprom.i = zext i8 %20 to i32
  %arrayidx1.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i
  %red.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 4
  %21 = load i32, ptr %red.i, align 4, !tbaa !36
  %green.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 5
  %22 = load i32, ptr %green.i, align 4, !tbaa !38
  %blue.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 6
  %23 = load i32, ptr %blue.i, align 4, !tbaa !39
  %conv.i = sext i16 %19 to i32
  %z.i.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 2
  %24 = load i32, ptr %z.i.i, align 4, !tbaa !40
  %sub.i.i = sub nsw i32 %24, %conv.i
  %25 = load i32, ptr %arrayidx1.i, align 4, !tbaa !41
  %sub2.i.i = sub nsw i32 %x.077, %25
  %mul.i.i = mul nsw i32 %sub2.i.i, %13
  %y4.i.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 1
  %26 = load i32, ptr %y4.i.i, align 4, !tbaa !42
  %sub5.i.i = sub nsw i32 %y.078, %26
  %mul7.i.i = mul nsw i32 %sub5.i.i, %14
  %mul8.i.i = shl nsw i32 %sub.i.i, 5
  %add.i.i = add i32 %mul.i.i, %mul8.i.i
  %add9.i.i = add i32 %add.i.i, %mul7.i.i
  %radius.i.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom.i, i32 3
  %27 = load i32, ptr %radius.i.i, align 4, !tbaa !43
  %mul10.i.i = mul nsw i32 %15, %27
  %cmp.i.i69 = icmp slt i32 %add9.i.i, 1
  br i1 %cmp.i.i69, label %shade_sphere.exit, label %cond.false.i.i

cond.false.i.i:                                   ; preds = %cond.true
  %cmp11.not.i.i = icmp slt i32 %add9.i.i, %mul10.i.i
  br i1 %cmp11.not.i.i, label %cond.false13.i.i, label %shade_sphere.exit

cond.false13.i.i:                                 ; preds = %cond.false.i.i
  %mul14.i.i = mul nsw i32 %add9.i.i, 183
  %div.i.i = sdiv i32 %mul14.i.i, %mul10.i.i
  %28 = add nsw i32 %div.i.i, 62
  br label %shade_sphere.exit

shade_sphere.exit:                                ; preds = %cond.true, %cond.false.i.i, %cond.false13.i.i
  %cond16.i.i = phi i32 [ 62, %cond.true ], [ %28, %cond.false13.i.i ], [ 245, %cond.false.i.i ]
  %mul.i8.i = mul nsw i32 %cond16.i.i, %21
  %div.i9.i = sdiv i32 %mul.i8.i, 255
  %mul1.i.i = mul nsw i32 %cond16.i.i, %22
  %div2.i.i = sdiv i32 %mul1.i.i, 255
  %mul3.i.i = mul nsw i32 %cond16.i.i, %23
  %div4.i.i = sdiv i32 %mul3.i.i, 255
  %29 = shl i32 %div.i9.i, 8
  %shl.i.i = and i32 %29, 63488
  %30 = shl nsw i32 %div2.i.i, 3
  %shl6.i.i = and i32 %30, 65504
  %shr7.i.i = lshr i32 %div4.i.i, 3
  %or.i.i = or i32 %shl6.i.i, %shr7.i.i
  %or8.i.i = or i32 %or.i.i, %shl.i.i
  %conv.i.i = trunc i32 %or8.i.i to i16
  br label %cond.end

cond.false:                                       ; preds = %for.body9
  %call13 = call fastcc zeroext i1 @in_shadow(ptr noundef nonnull %work, ptr noundef nonnull %lamp, i32 noundef %x.077, i32 noundef %y.078)
  %div1.i7576 = xor i32 %x.077, %y.078
  %31 = and i32 %div1.i7576, 16
  %tobool.not.i70 = icmp eq i32 %31, 0
  %cond.i71 = select i1 %tobool.not.i70, i32 117, i32 177
  %div3.lhs.trunc.i = trunc i32 %cond.i71 to i8
  %div32.i = udiv i8 %div3.lhs.trunc.i, 3
  %div3.zext.i = zext nneg i8 %div32.i to i32
  %cond4.i = select i1 %call13, i32 %div3.zext.i, i32 %cond.i71
  %32 = trunc i32 %cond4.i to i16
  %div.i3.lhs.trunc.i = mul nuw nsw i16 %32, 105
  %div.i34.i = udiv i16 %div.i3.lhs.trunc.i, 255
  %div2.i5.lhs.trunc.i = mul nuw nsw i16 %32, 134
  %div2.i56.i = udiv i16 %div2.i5.lhs.trunc.i, 255
  %div4.i7.lhs.trunc.i = mul nuw nsw i16 %32, 158
  %div4.i78.i = udiv i16 %div4.i7.lhs.trunc.i, 255
  %33 = shl nuw nsw i16 %div.i34.i, 8
  %34 = and i16 %33, 30720
  %35 = shl nuw nsw i16 %div2.i56.i, 3
  %36 = and i16 %35, 4064
  %37 = lshr i16 %div4.i78.i, 3
  %or.i9.i = or i16 %36, %37
  %or8.i10.i = or i16 %or.i9.i, %34
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %shade_sphere.exit
  %cond.in = phi i16 [ %conv.i.i, %shade_sphere.exit ], [ %or8.i10.i, %cond.false ]
  %arrayidx17 = getelementptr i16, ptr %18, i32 %x.077
  store i16 %cond.in, ptr %arrayidx17, align 2, !tbaa !34
  %inc = add nuw nsw i32 %x.077, 1
  %exitcond.not = icmp eq i32 %inc, 160
  br i1 %exitcond.not, label %for.cond.cleanup8, label %for.body9, !llvm.loop !74

return:                                           ; preds = %entry, %land.lhs.true.i, %land.lhs.true4.i, %valid.exit, %for.cond.cleanup
  %retval.0 = phi i1 [ true, %for.cond.cleanup ], [ false, %valid.exit ], [ false, %land.lhs.true4.i ], [ false, %land.lhs.true.i ], [ false, %entry ]
  ret i1 %retval.0
}

; Function Attrs: nounwind
define dso_local noundef zeroext i1 @raytrace_demo_trace_audit(ptr noundef %depth, ptr noundef %ids, i32 noundef %stride_pixels, ptr noundef readonly %scene, i32 noundef %mode) local_unnamed_addr #3 {
entry:
  %work = alloca %struct.trace, align 16
  %tobool.not.i = icmp eq ptr %scene, null
  br i1 %tobool.not.i, label %return, label %land.lhs.true.i

land.lhs.true.i:                                  ; preds = %entry
  %0 = load i32, ptr %scene, align 4, !tbaa !4
  %1 = add i32 %0, -32
  %or.cond.i = icmp ult i32 %1, 96
  br i1 %or.cond.i, label %land.lhs.true4.i, label %return

land.lhs.true4.i:                                 ; preds = %land.lhs.true.i
  %sphere_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 1
  %2 = load i32, ptr %sphere_y.i, align 4, !tbaa !9
  %3 = add i32 %2, -128
  %or.cond8.i = icmp ult i32 %3, -96
  %tobool.not.i.i = icmp eq ptr %depth, null
  %or.cond9.i = or i1 %tobool.not.i.i, %or.cond8.i
  br i1 %or.cond9.i, label %return, label %valid.exit

valid.exit:                                       ; preds = %land.lhs.true4.i
  %light_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 3
  %4 = load i32, ptr %light_y.i, align 4, !tbaa !11
  %light_x.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 2
  %5 = load i32, ptr %light_x.i, align 4, !tbaa !10
  %6 = ptrtoint ptr %depth to i32
  %rem.i.i = and i32 %6, 1
  %cmp.i.i = icmp eq i32 %rem.i.i, 0
  %7 = add i32 %stride_pixels, -160
  %8 = icmp ult i32 %7, 13506026
  %or.cond1.i.i = and i1 %cmp.i.i, %8
  %9 = icmp ult i32 %5, 160
  %or.cond3.i.i = and i1 %or.cond1.i.i, %9
  %10 = icmp ult i32 %4, 160
  %or.cond5.i.i = and i1 %10, %or.cond3.i.i
  %spec.select.i.i = icmp ult i32 %mode, 2
  %spec.select11.i.i = and i1 %spec.select.i.i, %or.cond5.i.i
  %tobool.not.i.i19 = icmp ne ptr %ids, null
  %or.cond.not35 = and i1 %tobool.not.i.i19, %spec.select11.i.i
  %11 = ptrtoint ptr %ids to i32
  %rem.i.i24 = and i32 %11, 1
  %cmp.i.i25 = icmp eq i32 %rem.i.i24, 0
  %or.cond34 = and i1 %or.cond.not35, %cmp.i.i25
  br i1 %or.cond34, label %if.end, label %return

if.end:                                           ; preds = %valid.exit
  call void @llvm.lifetime.start.p0(i64 2896, ptr nonnull %work) #11
  call fastcc void @prepare(ptr noundef nonnull %work, ptr noundef nonnull %scene)
  %depth1.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6
  br label %for.body

for.cond.cleanup:                                 ; preds = %save_audit.exit
  call void @llvm.lifetime.end.p0(i64 2896, ptr nonnull %work) #11
  br label %return

for.body:                                         ; preds = %if.end, %save_audit.exit
  %y.033 = phi i32 [ 0, %if.end ], [ %inc, %save_audit.exit ]
  %mul = mul i32 %y.033, %stride_pixels
  %call2 = call fastcc i32 @trace_row(ptr noundef nonnull %work, i32 noundef %y.033, i32 noundef %mode, i1 noundef zeroext false)
  %add.ptr = getelementptr inbounds i16, ptr %depth, i32 %mul
  %add.ptr3 = getelementptr inbounds i16, ptr %ids, i32 %mul
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 2 dereferenceable(320) %add.ptr, ptr noundef nonnull align 2 dereferenceable(320) %depth1.i, i32 320, i1 false)
  br label %for.body.i

for.body.i:                                       ; preds = %cond.end.i, %for.body
  %x.07.i = phi i32 [ 0, %for.body ], [ %inc.i, %cond.end.i ]
  %arrayidx.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x.07.i
  %12 = load i16, ptr %arrayidx.i, align 2, !tbaa !34
  %tobool.not.i32 = icmp eq i16 %12, 0
  br i1 %tobool.not.i32, label %cond.end.i, label %cond.true.i

cond.true.i:                                      ; preds = %for.body.i
  %arrayidx3.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x.07.i
  %13 = load i8, ptr %arrayidx3.i, align 1, !tbaa !35
  %conv4.i = zext i8 %13 to i16
  %add.i = add nuw nsw i16 %conv4.i, 1
  br label %cond.end.i

cond.end.i:                                       ; preds = %cond.true.i, %for.body.i
  %cond.i = phi i16 [ %add.i, %cond.true.i ], [ 0, %for.body.i ]
  %arrayidx8.i = getelementptr inbounds i16, ptr %add.ptr3, i32 %x.07.i
  store i16 %cond.i, ptr %arrayidx8.i, align 2, !tbaa !34
  %inc.i = add nuw nsw i32 %x.07.i, 1
  %exitcond.not.i = icmp eq i32 %inc.i, 160
  br i1 %exitcond.not.i, label %save_audit.exit, label %for.body.i, !llvm.loop !72

save_audit.exit:                                  ; preds = %cond.end.i
  %inc = add nuw nsw i32 %y.033, 1
  %exitcond.not = icmp eq i32 %inc, 160
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !llvm.loop !75

return:                                           ; preds = %entry, %land.lhs.true.i, %land.lhs.true4.i, %valid.exit, %for.cond.cleanup
  %retval.0 = phi i1 [ true, %for.cond.cleanup ], [ false, %valid.exit ], [ false, %land.lhs.true4.i ], [ false, %land.lhs.true.i ], [ false, %entry ]
  ret i1 %retval.0
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define dso_local zeroext i1 @raytrace_demo_shade_audit(ptr noundef %pixels, ptr noundef %depth, ptr noundef %ids, i32 noundef %stride_pixels, ptr noundef readonly %scene) local_unnamed_addr #5 {
entry:
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %tobool.not.i = icmp eq ptr %scene, null
  br i1 %tobool.not.i, label %return, label %land.lhs.true.i

land.lhs.true.i:                                  ; preds = %entry
  %0 = load i32, ptr %scene, align 4, !tbaa !4
  %1 = add i32 %0, -32
  %or.cond.i = icmp ult i32 %1, 96
  br i1 %or.cond.i, label %land.lhs.true4.i, label %return

land.lhs.true4.i:                                 ; preds = %land.lhs.true.i
  %sphere_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 1
  %2 = load i32, ptr %sphere_y.i, align 4, !tbaa !9
  %3 = add i32 %2, -128
  %or.cond8.i = icmp ult i32 %3, -96
  %tobool.not.i.i = icmp eq ptr %pixels, null
  %or.cond9.i = or i1 %tobool.not.i.i, %or.cond8.i
  br i1 %or.cond9.i, label %return, label %valid.exit

valid.exit:                                       ; preds = %land.lhs.true4.i
  %light_y.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 3
  %4 = load i32, ptr %light_y.i, align 4, !tbaa !11
  %light_x.i = getelementptr inbounds %struct.raytrace_demo_scene, ptr %scene, i32 0, i32 2
  %5 = load i32, ptr %light_x.i, align 4, !tbaa !10
  %6 = ptrtoint ptr %pixels to i32
  %rem.i.i = and i32 %6, 1
  %cmp.i.i = icmp eq i32 %rem.i.i, 0
  %7 = add i32 %stride_pixels, -160
  %8 = icmp ult i32 %7, 13506026
  %or.cond1.i.i = and i1 %cmp.i.i, %8
  %9 = icmp ult i32 %5, 160
  %or.cond3.i.i = and i1 %or.cond1.i.i, %9
  %10 = icmp ult i32 %4, 160
  %or.cond5.i.i = and i1 %10, %or.cond3.i.i
  %tobool.not.i.i51 = icmp ne ptr %depth, null
  %or.cond100.not104 = and i1 %tobool.not.i.i51, %or.cond5.i.i
  %11 = ptrtoint ptr %depth to i32
  %rem.i.i56 = and i32 %11, 1
  %cmp.i.i57 = icmp eq i32 %rem.i.i56, 0
  %or.cond101 = and i1 %or.cond100.not104, %cmp.i.i57
  %tobool.not.i.i68 = icmp ne ptr %ids, null
  %or.cond102.not105 = and i1 %tobool.not.i.i68, %or.cond101
  %12 = ptrtoint ptr %ids to i32
  %rem.i.i73 = and i32 %12, 1
  %cmp.i.i74 = icmp eq i32 %rem.i.i73, 0
  %or.cond103 = and i1 %or.cond102.not105, %cmp.i.i74
  br i1 %or.cond103, label %if.end, label %return

if.end:                                           ; preds = %valid.exit
  call void @llvm.lifetime.start.p0(i64 2896, ptr nonnull %work) #11
  %object_count.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  store i32 3, ptr %object_count.i, align 4, !tbaa !18
  store i32 %0, ptr %work, align 16, !tbaa.struct !49
  %.compoundliteral.sroa.2.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 4
  store i32 %2, ptr %.compoundliteral.sroa.2.0.arrayidx.sroa_idx.i, align 4, !tbaa.struct !51
  %.compoundliteral.sroa.3.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 8
  store i32 56, ptr %.compoundliteral.sroa.3.0.arrayidx.sroa_idx.i, align 8, !tbaa.struct !52
  %.compoundliteral.sroa.4.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 12
  store i32 26, ptr %.compoundliteral.sroa.4.0.arrayidx.sroa_idx.i, align 4, !tbaa.struct !53
  %.compoundliteral.sroa.5.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 16
  store i32 245, ptr %.compoundliteral.sroa.5.0.arrayidx.sroa_idx.i, align 16, !tbaa.struct !54
  %.compoundliteral.sroa.6.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 20
  store i32 83, ptr %.compoundliteral.sroa.6.0.arrayidx.sroa_idx.i, align 4, !tbaa.struct !55
  %.compoundliteral.sroa.7.0.arrayidx.sroa_idx.i = getelementptr inbounds i8, ptr %work, i32 24
  store i32 67, ptr %.compoundliteral.sroa.7.0.arrayidx.sroa_idx.i, align 8, !tbaa.struct !56
  %arrayidx2.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1
  store i32 100, ptr %arrayidx2.i, align 4, !tbaa.struct !49
  %.compoundliteral3.sroa.2.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 1
  store i32 65, ptr %.compoundliteral3.sroa.2.0.arrayidx2.sroa_idx.i, align 16, !tbaa.struct !51
  %.compoundliteral3.sroa.3.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 2
  store i32 105, ptr %.compoundliteral3.sroa.3.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !52
  %.compoundliteral3.sroa.4.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 3
  store i32 32, ptr %.compoundliteral3.sroa.4.0.arrayidx2.sroa_idx.i, align 8, !tbaa.struct !53
  %.compoundliteral3.sroa.5.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 4
  store i32 48, ptr %.compoundliteral3.sroa.5.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !54
  %.compoundliteral3.sroa.6.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 5
  store i32 197, ptr %.compoundliteral3.sroa.6.0.arrayidx2.sroa_idx.i, align 16, !tbaa.struct !55
  %.compoundliteral3.sroa.7.0.arrayidx2.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 1, i32 6
  store i32 213, ptr %.compoundliteral3.sroa.7.0.arrayidx2.sroa_idx.i, align 4, !tbaa.struct !56
  %arrayidx12.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2
  store i32 58, ptr %arrayidx12.i, align 8, !tbaa.struct !49
  %.compoundliteral13.sroa.2.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 1
  store i32 109, ptr %.compoundliteral13.sroa.2.0.arrayidx12.sroa_idx.i, align 4, !tbaa.struct !51
  %.compoundliteral13.sroa.3.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 2
  store i32 86, ptr %.compoundliteral13.sroa.3.0.arrayidx12.sroa_idx.i, align 16, !tbaa.struct !52
  %.compoundliteral13.sroa.4.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 3
  store i32 23, ptr %.compoundliteral13.sroa.4.0.arrayidx12.sroa_idx.i, align 4, !tbaa.struct !53
  %.compoundliteral13.sroa.5.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 4
  store i32 245, ptr %.compoundliteral13.sroa.5.0.arrayidx12.sroa_idx.i, align 8, !tbaa.struct !54
  %.compoundliteral13.sroa.6.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 5
  store i32 182, ptr %.compoundliteral13.sroa.6.0.arrayidx12.sroa_idx.i, align 4, !tbaa.struct !55
  %.compoundliteral13.sroa.7.0.arrayidx12.sroa_idx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 2, i32 6
  store i32 58, ptr %.compoundliteral13.sroa.7.0.arrayidx12.sroa_idx.i, align 16, !tbaa.struct !56
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %lamp) #11
  call fastcc void @prepare_light(ptr dead_on_unwind nonnull writable sret(%struct.light) align 4 %lamp, ptr noundef nonnull %work, i32 noundef %5, i32 noundef %4)
  %13 = load i32, ptr %lamp, align 4
  %y6.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 1
  %14 = load i32, ptr %y6.i, align 4
  %norm.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 3
  %15 = load i32, ptr %norm.i, align 4
  br label %for.body

for.body:                                         ; preds = %if.end, %for.inc50
  %cmp94 = phi i1 [ false, %if.end ], [ %cmp, %for.inc50 ]
  %y.093 = phi i32 [ 0, %if.end ], [ %inc51, %for.inc50 ]
  %mul = mul i32 %y.093, %stride_pixels
  br label %for.body7

for.body7:                                        ; preds = %for.body, %for.inc
  %x.092 = phi i32 [ 0, %for.body ], [ %inc, %for.inc ]
  %add = add i32 %x.092, %mul
  %arrayidx = getelementptr inbounds i16, ptr %ids, i32 %add
  %16 = load i16, ptr %arrayidx, align 2, !tbaa !34
  %arrayidx9 = getelementptr inbounds i16, ptr %depth, i32 %add
  %17 = load i16, ptr %arrayidx9, align 2, !tbaa !34
  %conv = sext i16 %17 to i32
  %conv10 = zext i16 %16 to i32
  %cmp11 = icmp ugt i16 %16, 3
  %cmp14 = icmp slt i16 %17, 0
  %or.cond = select i1 %cmp11, i1 true, i1 %cmp14
  %cmp17 = icmp sgt i16 %17, 105
  %or.cond4 = select i1 %or.cond, i1 true, i1 %cmp17
  br i1 %or.cond4, label %cleanup55, label %lor.lhs.false19

lor.lhs.false19:                                  ; preds = %for.body7
  %cmp21 = icmp eq i16 %16, 0
  %18 = icmp ne i16 %17, 0
  %cmp25.not = xor i1 %cmp21, %18
  br i1 %cmp25.not, label %if.end28, label %cleanup55

if.end28:                                         ; preds = %lor.lhs.false19
  br i1 %cmp21, label %if.then32, label %if.else

if.then32:                                        ; preds = %if.end28
  %call33 = call fastcc zeroext i1 @in_shadow(ptr noundef nonnull %work, ptr noundef nonnull %lamp, i32 noundef %x.092, i32 noundef %y.093)
  %div1.i8788 = xor i32 %x.092, %y.093
  %19 = and i32 %div1.i8788, 16
  %tobool.not.i80 = icmp eq i32 %19, 0
  %cond.i = select i1 %tobool.not.i80, i32 117, i32 177
  %div3.lhs.trunc.i = trunc i32 %cond.i to i8
  %div32.i = udiv i8 %div3.lhs.trunc.i, 3
  %div3.zext.i = zext nneg i8 %div32.i to i32
  %cond4.i = select i1 %call33, i32 %div3.zext.i, i32 %cond.i
  %20 = trunc i32 %cond4.i to i16
  %div.i3.lhs.trunc.i = mul nuw nsw i16 %20, 105
  %div.i34.i = udiv i16 %div.i3.lhs.trunc.i, 255
  %div2.i5.lhs.trunc.i = mul nuw nsw i16 %20, 134
  %div2.i56.i = udiv i16 %div2.i5.lhs.trunc.i, 255
  %div4.i7.lhs.trunc.i = mul nuw nsw i16 %20, 158
  %div4.i78.i = udiv i16 %div4.i7.lhs.trunc.i, 255
  %21 = shl nuw nsw i16 %div.i34.i, 8
  %22 = and i16 %21, 30720
  %23 = shl nuw nsw i16 %div2.i56.i, 3
  %24 = and i16 %23, 4064
  %25 = lshr i16 %div4.i78.i, 3
  %or.i9.i = or i16 %24, %25
  %or8.i10.i = or i16 %or.i9.i, %22
  br label %for.inc

if.else:                                          ; preds = %if.end28
  %sub = add nsw i32 %conv10, -1
  %arrayidx38 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub
  %red = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub, i32 4
  %26 = load i32, ptr %red, align 4, !tbaa !36
  %green = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub, i32 5
  %27 = load i32, ptr %green, align 4, !tbaa !38
  %blue = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub, i32 6
  %28 = load i32, ptr %blue, align 4, !tbaa !39
  %z.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub, i32 2
  %29 = load i32, ptr %z.i, align 4, !tbaa !40
  %sub.i = sub nsw i32 %29, %conv
  %30 = load i32, ptr %arrayidx38, align 4, !tbaa !41
  %sub2.i = sub nsw i32 %x.092, %30
  %mul.i = mul nsw i32 %sub2.i, %13
  %y4.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub, i32 1
  %31 = load i32, ptr %y4.i, align 4, !tbaa !42
  %sub5.i = sub nsw i32 %y.093, %31
  %mul7.i = mul nsw i32 %sub5.i, %14
  %mul8.i = shl nsw i32 %sub.i, 5
  %add.i = add i32 %mul.i, %mul8.i
  %add9.i = add i32 %add.i, %mul7.i
  %radius.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %sub, i32 3
  %32 = load i32, ptr %radius.i, align 4, !tbaa !43
  %mul10.i = mul nsw i32 %15, %32
  %cmp.i = icmp slt i32 %add9.i, 1
  br i1 %cmp.i, label %sphere_scale.exit, label %cond.false.i

cond.false.i:                                     ; preds = %if.else
  %cmp11.not.i = icmp slt i32 %add9.i, %mul10.i
  br i1 %cmp11.not.i, label %cond.false13.i, label %sphere_scale.exit

cond.false13.i:                                   ; preds = %cond.false.i
  %mul14.i = mul nsw i32 %add9.i, 183
  %div.i81 = sdiv i32 %mul14.i, %mul10.i
  %33 = add nsw i32 %div.i81, 62
  br label %sphere_scale.exit

sphere_scale.exit:                                ; preds = %if.else, %cond.false.i, %cond.false13.i
  %cond16.i = phi i32 [ 62, %if.else ], [ %33, %cond.false13.i ], [ 245, %cond.false.i ]
  %mul.i82 = mul nsw i32 %cond16.i, %26
  %div.i83 = sdiv i32 %mul.i82, 255
  %mul1.i = mul nsw i32 %cond16.i, %27
  %div2.i = sdiv i32 %mul1.i, 255
  %mul3.i = mul nsw i32 %cond16.i, %28
  %div4.i = sdiv i32 %mul3.i, 255
  %34 = shl i32 %div.i83, 8
  %shl.i = and i32 %34, 63488
  %35 = shl nsw i32 %div2.i, 3
  %shl6.i = and i32 %35, 65504
  %shr7.i = lshr i32 %div4.i, 3
  %or.i = or i32 %shl6.i, %shr7.i
  %or8.i = or i32 %or.i, %shl.i
  %conv.i = trunc i32 %or8.i to i16
  br label %for.inc

for.inc:                                          ; preds = %sphere_scale.exit, %if.then32
  %conv.i.sink = phi i16 [ %conv.i, %sphere_scale.exit ], [ %or8.i10.i, %if.then32 ]
  %arrayidx42 = getelementptr inbounds i16, ptr %pixels, i32 %add
  store i16 %conv.i.sink, ptr %arrayidx42, align 2, !tbaa !34
  %inc = add nuw nsw i32 %x.092, 1
  %exitcond = icmp eq i32 %inc, 160
  br i1 %exitcond, label %for.inc50, label %for.body7, !llvm.loop !76

for.inc50:                                        ; preds = %for.inc
  %inc51 = add nuw nsw i32 %y.093, 1
  %cmp = icmp ugt i32 %y.093, 158
  %exitcond97 = icmp eq i32 %inc51, 160
  br i1 %exitcond97, label %cleanup55, label %for.body, !llvm.loop !77

cleanup55:                                        ; preds = %for.inc50, %for.body7, %lor.lhs.false19
  %cmp91 = phi i1 [ %cmp94, %lor.lhs.false19 ], [ %cmp94, %for.body7 ], [ %cmp, %for.inc50 ]
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %lamp) #11
  call void @llvm.lifetime.end.p0(i64 2896, ptr nonnull %work) #11
  br label %return

return:                                           ; preds = %entry, %land.lhs.true.i, %land.lhs.true4.i, %valid.exit, %cleanup55
  %retval.6 = phi i1 [ %cmp91, %cleanup55 ], [ false, %valid.exit ], [ false, %land.lhs.true4.i ], [ false, %land.lhs.true.i ], [ false, %entry ]
  ret i1 %retval.6
}

; Function Attrs: nounwind
define dso_local noundef zeroext i1 @raytrace_demo_render_materials(ptr noundef %pixels, i32 noundef %stride_pixels, ptr noundef readonly %objects, i32 noundef %object_count, i16 noundef zeroext %floor_material, i32 noundef %light_x, i32 noundef %light_y, i32 noundef %mode, ptr noundef readonly %sample, ptr noundef %context, ptr noundef %stats) local_unnamed_addr #3 {
entry:
  %work = alloca %struct.trace, align 16
  %lamp = alloca %struct.light, align 4
  %materials = alloca [160 x i16], align 2
  %colors = alloca [320 x i16], align 2
  %tobool = icmp eq ptr %sample, null
  %tobool1 = icmp eq ptr %objects, null
  %or.cond.not65 = or i1 %tobool1, %tobool
  %cmp = icmp ugt i32 %object_count, 3
  %or.cond5 = or i1 %cmp, %or.cond.not65
  %tobool.not.i = icmp eq ptr %pixels, null
  %or.cond = or i1 %tobool.not.i, %or.cond5
  br i1 %or.cond, label %return, label %valid_output.exit

valid_output.exit:                                ; preds = %entry
  %0 = ptrtoint ptr %pixels to i32
  %rem.i = and i32 %0, 1
  %cmp.i = icmp eq i32 %rem.i, 0
  %1 = add i32 %stride_pixels, -160
  %2 = icmp ult i32 %1, 13506026
  %or.cond1.i = and i1 %cmp.i, %2
  %3 = icmp ult i32 %light_x, 160
  %or.cond3.i = and i1 %or.cond1.i, %3
  %4 = icmp ult i32 %light_y, 160
  %or.cond5.i = and i1 %4, %or.cond3.i
  %spec.select.i = icmp ult i32 %mode, 2
  %spec.select11.i = and i1 %or.cond5.i, %spec.select.i
  br i1 %spec.select11.i, label %if.end, label %return

if.end:                                           ; preds = %valid_output.exit
  call void @llvm.lifetime.start.p0(i64 2896, ptr nonnull %work) #11
  %object_count4 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 1
  store i32 %object_count, ptr %object_count4, align 4, !tbaa !18
  %cmp5.not88.not = icmp eq i32 %object_count, 0
  br i1 %cmp5.not88.not, label %for.cond11.preheader.i, label %for.body

for.body:                                         ; preds = %if.end, %if.end8
  %s.089 = phi i32 [ %inc, %if.end8 ], [ 0, %if.end ]
  %arrayidx = getelementptr inbounds %struct.raytrace_demo_object, ptr %objects, i32 %s.089
  %5 = load i32, ptr %arrayidx, align 4, !tbaa !12
  %6 = add i32 %5, -32
  %or.cond.i = icmp ult i32 %6, 96
  br i1 %or.cond.i, label %land.lhs.true4.i, label %cleanup128

land.lhs.true4.i:                                 ; preds = %for.body
  %y.i = getelementptr inbounds %struct.raytrace_demo_object, ptr %objects, i32 %s.089, i32 1
  %7 = load i32, ptr %y.i, align 4, !tbaa !15
  %8 = add i32 %7, -32
  %or.cond14.i = icmp ult i32 %8, 96
  br i1 %or.cond14.i, label %land.lhs.true9.i, label %cleanup128

land.lhs.true9.i:                                 ; preds = %land.lhs.true4.i
  %radius.i = getelementptr inbounds %struct.raytrace_demo_object, ptr %objects, i32 %s.089, i32 3
  %9 = load i32, ptr %radius.i, align 4, !tbaa !16
  %10 = add i32 %9, -1
  %or.cond15.i = icmp ult i32 %10, 32
  br i1 %or.cond15.i, label %land.lhs.true14.i, label %cleanup128

land.lhs.true14.i:                                ; preds = %land.lhs.true9.i
  %z.i = getelementptr inbounds %struct.raytrace_demo_object, ptr %objects, i32 %s.089, i32 2
  %11 = load i32, ptr %z.i, align 4, !tbaa !17
  %cmp16.i = icmp sgt i32 %11, %9
  %sub.i = sub nuw nsw i32 156, %9
  %cmp19.i = icmp ult i32 %11, %sub.i
  %or.cond85 = select i1 %cmp16.i, i1 %cmp19.i, i1 false
  br i1 %or.cond85, label %if.end8, label %cleanup128

if.end8:                                          ; preds = %land.lhs.true14.i
  %arrayidx10 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.089
  store i32 %5, ptr %arrayidx10, align 4, !tbaa.struct !49
  %.compoundliteral.sroa.2.0.arrayidx10.sroa_idx = getelementptr inbounds i8, ptr %arrayidx10, i32 4
  store i32 %7, ptr %.compoundliteral.sroa.2.0.arrayidx10.sroa_idx, align 4, !tbaa.struct !51
  %.compoundliteral.sroa.3.0.arrayidx10.sroa_idx = getelementptr inbounds i8, ptr %arrayidx10, i32 8
  store i32 %11, ptr %.compoundliteral.sroa.3.0.arrayidx10.sroa_idx, align 4, !tbaa.struct !52
  %.compoundliteral.sroa.4.0.arrayidx10.sroa_idx = getelementptr inbounds i8, ptr %arrayidx10, i32 12
  store i32 %9, ptr %.compoundliteral.sroa.4.0.arrayidx10.sroa_idx, align 4, !tbaa.struct !53
  %.compoundliteral.sroa.5.0.arrayidx10.sroa_idx = getelementptr inbounds i8, ptr %arrayidx10, i32 16
  store i32 0, ptr %.compoundliteral.sroa.5.0.arrayidx10.sroa_idx, align 4, !tbaa.struct !54
  %.compoundliteral.sroa.6.0.arrayidx10.sroa_idx = getelementptr inbounds i8, ptr %arrayidx10, i32 20
  store i32 0, ptr %.compoundliteral.sroa.6.0.arrayidx10.sroa_idx, align 4, !tbaa.struct !55
  %.compoundliteral.sroa.7.0.arrayidx10.sroa_idx = getelementptr inbounds i8, ptr %arrayidx10, i32 24
  store i32 0, ptr %.compoundliteral.sroa.7.0.arrayidx10.sroa_idx, align 4, !tbaa.struct !56
  %inc = add nuw i32 %s.089, 1
  %exitcond.not = icmp eq i32 %inc, %object_count
  br i1 %exitcond.not, label %for.end, label %for.body, !llvm.loop !78

for.end:                                          ; preds = %if.end8
  %.pre = load i32, ptr %object_count4, align 4, !tbaa !18
  %cmp18.not.i = icmp eq i32 %.pre, 0
  br i1 %cmp18.not.i, label %for.cond11.preheader.i, label %for.cond1.preheader.i

for.cond1.preheader.i:                            ; preds = %for.end, %for.cond.cleanup3.i
  %s.019.i = phi i32 [ %inc9.i, %for.cond.cleanup3.i ], [ 0, %for.end ]
  %arrayidx.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %s.019.i
  %12 = load i32, ptr %arrayidx.i, align 4, !tbaa !41
  br label %for.body4.i

for.cond11.preheader.i.loopexit:                  ; preds = %for.cond.cleanup3.i
  %13 = mul i32 %.pre, 25600
  br label %for.cond11.preheader.i

for.cond11.preheader.i:                           ; preds = %for.cond11.preheader.i.loopexit, %if.end, %for.end
  %mul.i70 = phi i32 [ 0, %for.end ], [ 0, %if.end ], [ %13, %for.cond11.preheader.i.loopexit ]
  br label %for.body15.i

for.cond.cleanup3.i:                              ; preds = %for.body4.i
  %inc9.i = add nuw i32 %s.019.i, 1
  %exitcond23.not.i = icmp eq i32 %inc9.i, %.pre
  br i1 %exitcond23.not.i, label %for.cond11.preheader.i.loopexit, label %for.cond1.preheader.i, !llvm.loop !79

for.body4.i:                                      ; preds = %for.body4.i, %for.cond1.preheader.i
  %x.017.i = phi i32 [ 0, %for.cond1.preheader.i ], [ %inc.i, %for.body4.i ]
  %sub.i68 = sub nsw i32 %x.017.i, %12
  %mul.i = mul nsw i32 %sub.i68, %sub.i68
  %conv.i = trunc i32 %mul.i to i16
  %arrayidx7.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 3, i32 %s.019.i, i32 %x.017.i
  store i16 %conv.i, ptr %arrayidx7.i, align 2, !tbaa !34
  %inc.i = add nuw nsw i32 %x.017.i, 1
  %exitcond.not.i = icmp eq i32 %inc.i, 160
  br i1 %exitcond.not.i, label %for.cond.cleanup3.i, label %for.body4.i, !llvm.loop !57

for.body15.i:                                     ; preds = %for.body15.i, %for.cond11.preheader.i
  %i.022.i = phi i32 [ 0, %for.cond11.preheader.i ], [ %inc24.i, %for.body15.i ]
  %next_square.021.i = phi i32 [ 1, %for.cond11.preheader.i ], [ %next_square.1.i, %for.body15.i ]
  %root.020.i = phi i32 [ 0, %for.cond11.preheader.i ], [ %root.1.i, %for.body15.i ]
  %cmp16.i69 = icmp eq i32 %i.022.i, %next_square.021.i
  %inc18.i = add nsw i32 %root.020.i, 1
  %mul19.i = shl nsw i32 %inc18.i, 1
  %add.i = or disjoint i32 %mul19.i, 1
  %root.1.i = select i1 %cmp16.i69, i32 %inc18.i, i32 %root.020.i
  %add20.i = select i1 %cmp16.i69, i32 %add.i, i32 0
  %next_square.1.i = add nsw i32 %add20.i, %next_square.021.i
  %conv21.i = trunc i32 %root.1.i to i8
  %arrayidx22.i = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 5, i32 %i.022.i
  store i8 %conv21.i, ptr %arrayidx22.i, align 1, !tbaa !35
  %inc24.i = add nuw nsw i32 %i.022.i, 1
  %exitcond24.not.i = icmp eq i32 %inc24.i, 1025
  br i1 %exitcond24.not.i, label %prepare_tables.exit, label %for.body15.i, !llvm.loop !58

prepare_tables.exit:                              ; preds = %for.body15.i
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %lamp) #11
  call fastcc void @prepare_light(ptr dead_on_unwind nonnull writable sret(%struct.light) align 4 %lamp, ptr noundef nonnull %work, i32 noundef %light_x, i32 noundef %light_y)
  call void @llvm.lifetime.start.p0(i64 320, ptr nonnull %materials) #11
  call void @llvm.lifetime.start.p0(i64 640, ptr nonnull %colors) #11
  %tobool17 = icmp ne ptr %stats, null
  br i1 %tobool17, label %if.then18, label %if.end20

if.then18:                                        ; preds = %prepare_tables.exit
  %cmp.i71 = icmp eq i32 %mode, 1
  %div2.i = lshr exact i32 %mul.i70, 3
  %spec.select.i72 = select i1 %cmp.i71, i32 %div2.i, i32 0
  store i32 25600, ptr %stats, align 4, !tbaa.struct !20
  %.compoundliteral.sroa.2.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 4
  store i32 %mul.i70, ptr %.compoundliteral.sroa.2.0..sroa_idx.i, align 4, !tbaa.struct !23
  %.compoundliteral.sroa.3.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 8
  store i32 0, ptr %.compoundliteral.sroa.3.0..sroa_idx.i, align 4, !tbaa.struct !24
  %.compoundliteral.sroa.4.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 12
  store i32 0, ptr %.compoundliteral.sroa.4.0..sroa_idx.i, align 4, !tbaa.struct !25
  %.compoundliteral.sroa.5.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 16
  store i32 0, ptr %.compoundliteral.sroa.5.0..sroa_idx.i, align 4, !tbaa.struct !26
  %.compoundliteral.sroa.6.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 20
  store i32 %spec.select.i72, ptr %.compoundliteral.sroa.6.0..sroa_idx.i, align 4, !tbaa.struct !27
  %.compoundliteral.sroa.7.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 24
  store i32 0, ptr %.compoundliteral.sroa.7.0..sroa_idx.i, align 4, !tbaa.struct !28
  %.compoundliteral.sroa.8.0..sroa_idx.i = getelementptr inbounds i8, ptr %stats, i32 28
  store i32 -2128831035, ptr %.compoundliteral.sroa.8.0..sroa_idx.i, align 4, !tbaa.struct !29
  br label %if.end20

if.end20:                                         ; preds = %if.then18, %prepare_tables.exit
  %sphere_hits = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 2
  %14 = load i32, ptr %lamp, align 4
  %y6.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 1
  %15 = load i32, ptr %y6.i, align 4
  %norm.i = getelementptr inbounds %struct.light, ptr %lamp, i32 0, i32 3
  %16 = load i32, ptr %norm.i, align 4
  %hit_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 3
  %shadow_pixels = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 4
  %checksum.i = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 7
  br label %for.body25

for.cond22:                                       ; preds = %if.end105
  %inc115 = add nuw nsw i32 %y21.092, 1
  %cmp23 = icmp ugt i32 %y21.092, 158
  %exitcond97 = icmp eq i32 %inc115, 160
  br i1 %exitcond97, label %for.end118, label %for.body25, !llvm.loop !80

for.body25:                                       ; preds = %if.end20, %for.cond22
  %cmp2393 = phi i1 [ false, %if.end20 ], [ %cmp23, %for.cond22 ]
  %y21.092 = phi i32 [ 0, %if.end20 ], [ %inc115, %for.cond22 ]
  %call27 = call fastcc i32 @trace_row(ptr noundef nonnull %work, i32 noundef %y21.092, i32 noundef %mode, i1 noundef zeroext %tobool17)
  %mul = mul i32 %y21.092, %stride_pixels
  br label %for.body32

for.cond.cleanup31:                               ; preds = %cond.end
  %add.ptr = getelementptr inbounds i16, ptr %pixels, i32 %mul
  %call47 = call zeroext i1 %sample(ptr noundef %context, i32 noundef %y21.092, ptr noundef nonnull %materials, ptr noundef nonnull %colors) #11
  br i1 %call47, label %if.end49, label %cleanup125

for.body32:                                       ; preds = %for.body25, %cond.end
  %x28.090 = phi i32 [ 0, %for.body25 ], [ %inc43, %cond.end ]
  %arrayidx33 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x28.090
  %17 = load i16, ptr %arrayidx33, align 2, !tbaa !34
  %cmp34.not = icmp eq i16 %17, 0
  br i1 %cmp34.not, label %cond.end, label %cond.true

cond.true:                                        ; preds = %for.body32
  %arrayidx36 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x28.090
  %18 = load i8, ptr %arrayidx36, align 1, !tbaa !35
  %idxprom = zext i8 %18 to i32
  %material = getelementptr inbounds %struct.raytrace_demo_object, ptr %objects, i32 %idxprom, i32 4
  %19 = load i16, ptr %material, align 4, !tbaa !81
  br label %cond.end

cond.end:                                         ; preds = %for.body32, %cond.true
  %cond.in = phi i16 [ %19, %cond.true ], [ %floor_material, %for.body32 ]
  %arrayidx41 = getelementptr inbounds [160 x i16], ptr %materials, i32 0, i32 %x28.090
  store i16 %cond.in, ptr %arrayidx41, align 2, !tbaa !34
  %inc43 = add nuw nsw i32 %x28.090, 1
  %exitcond95.not = icmp eq i32 %inc43, 160
  br i1 %exitcond95.not, label %for.cond.cleanup31, label %for.body32, !llvm.loop !82

if.end49:                                         ; preds = %for.cond.cleanup31
  br i1 %tobool17, label %if.then51, label %for.body58.preheader

if.then51:                                        ; preds = %if.end49
  %20 = load i32, ptr %sphere_hits, align 4, !tbaa !30
  %add = add i32 %20, %call27
  store i32 %add, ptr %sphere_hits, align 4, !tbaa !30
  br label %for.body58.preheader

for.body58.preheader:                             ; preds = %if.then51, %if.end49
  br label %for.body58

for.body58:                                       ; preds = %for.body58.preheader, %if.end105
  %x53.091 = phi i32 [ %inc107, %if.end105 ], [ 0, %for.body58.preheader ]
  %arrayidx60 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 6, i32 %x53.091
  %21 = load i16, ptr %arrayidx60, align 2, !tbaa !34
  %cmp62 = icmp ne i16 %21, 0
  br i1 %cmp62, label %cond.true70, label %cond.false80

cond.true70:                                      ; preds = %for.body58
  %arrayidx73 = getelementptr inbounds %struct.trace, ptr %work, i32 0, i32 7, i32 %x53.091
  %22 = load i8, ptr %arrayidx73, align 1, !tbaa !35
  %idxprom74 = zext i8 %22 to i32
  %arrayidx75 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom74
  %conv78 = sext i16 %21 to i32
  %z.i73 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom74, i32 2
  %23 = load i32, ptr %z.i73, align 4, !tbaa !40
  %sub.i74 = sub nsw i32 %23, %conv78
  %24 = load i32, ptr %arrayidx75, align 4, !tbaa !41
  %sub2.i = sub nsw i32 %x53.091, %24
  %mul.i75 = mul nsw i32 %sub2.i, %14
  %y4.i = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom74, i32 1
  %25 = load i32, ptr %y4.i, align 4, !tbaa !42
  %sub5.i = sub nsw i32 %y21.092, %25
  %mul7.i = mul nsw i32 %sub5.i, %15
  %mul8.i = shl nsw i32 %sub.i74, 5
  %add.i76 = add i32 %mul.i75, %mul8.i
  %add9.i = add i32 %add.i76, %mul7.i
  %radius.i77 = getelementptr inbounds [3 x %struct.sphere], ptr %work, i32 0, i32 %idxprom74, i32 3
  %26 = load i32, ptr %radius.i77, align 4, !tbaa !43
  %mul10.i = mul nsw i32 %16, %26
  %cmp.i78 = icmp slt i32 %add9.i, 1
  br i1 %cmp.i78, label %cond.end84, label %cond.false.i

cond.false.i:                                     ; preds = %cond.true70
  %cmp11.not.i = icmp slt i32 %add9.i, %mul10.i
  br i1 %cmp11.not.i, label %cond.false13.i, label %cond.end84

cond.false13.i:                                   ; preds = %cond.false.i
  %mul14.i = mul nsw i32 %add9.i, 183
  %div.i = sdiv i32 %mul14.i, %mul10.i
  %27 = add nsw i32 %div.i, 62
  br label %cond.end84

cond.false80:                                     ; preds = %for.body58
  %call65 = call fastcc zeroext i1 @in_shadow(ptr noundef nonnull %work, ptr noundef nonnull %lamp, i32 noundef %x53.091, i32 noundef %y21.092)
  %cond83 = select i1 %call65, i32 85, i32 255
  br label %cond.end84

cond.end84:                                       ; preds = %cond.false13.i, %cond.false.i, %cond.true70, %cond.false80
  %28 = phi i1 [ %call65, %cond.false80 ], [ false, %cond.true70 ], [ false, %cond.false.i ], [ false, %cond.false13.i ]
  %cond85 = phi i32 [ %cond83, %cond.false80 ], [ 62, %cond.true70 ], [ 245, %cond.false.i ], [ %27, %cond.false13.i ]
  %mul86 = shl nuw nsw i32 %x53.091, 1
  %arrayidx87 = getelementptr inbounds [320 x i16], ptr %colors, i32 0, i32 %mul86
  %29 = load i16, ptr %arrayidx87, align 2, !tbaa !34
  %add89 = or disjoint i32 %mul86, 1
  %arrayidx90 = getelementptr inbounds [320 x i16], ptr %colors, i32 0, i32 %add89
  %30 = load i16, ptr %arrayidx90, align 2, !tbaa !34
  %conv91 = zext i16 %29 to i32
  %shr = lshr i32 %conv91, 8
  %and = and i32 %conv91, 255
  %conv93 = zext i16 %30 to i32
  %mul.i79 = mul nsw i32 %shr, %cond85
  %div.i80 = sdiv i32 %mul.i79, 255
  %mul1.i = mul nsw i32 %and, %cond85
  %div2.i81 = sdiv i32 %mul1.i, 255
  %mul3.i = mul nsw i32 %cond85, %conv93
  %div4.i = sdiv i32 %mul3.i, 255
  %31 = shl i32 %div.i80, 8
  %shl.i = and i32 %31, 63488
  %32 = shl nsw i32 %div2.i81, 3
  %shl6.i = and i32 %32, 65504
  %shr7.i = lshr i32 %div4.i, 3
  %or.i = or i32 %shl6.i, %shr7.i
  %or8.i = or i32 %or.i, %shl.i
  %conv.i82 = trunc i32 %or8.i to i16
  %arrayidx95 = getelementptr inbounds i16, ptr %add.ptr, i32 %x53.091
  store i16 %conv.i82, ptr %arrayidx95, align 2, !tbaa !34
  br i1 %tobool17, label %if.then97, label %if.end105

if.then97:                                        ; preds = %cond.end84
  %conv99 = zext i1 %cmp62 to i32
  %33 = load i32, ptr %hit_pixels, align 4, !tbaa !44
  %add100 = add i32 %33, %conv99
  store i32 %add100, ptr %hit_pixels, align 4, !tbaa !44
  %conv102 = zext i1 %28 to i32
  %34 = load i32, ptr %shadow_pixels, align 4, !tbaa !45
  %add103 = add i32 %34, %conv102
  store i32 %add103, ptr %shadow_pixels, align 4, !tbaa !45
  %35 = load i32, ptr %checksum.i, align 4, !tbaa !46
  %and.i = and i32 %or.i, 255
  %xor.i = xor i32 %35, %and.i
  %mul.i84 = mul i32 %xor.i, 16777619
  %conv.i83 = lshr i32 %or8.i, 8
  %shr.i = and i32 %conv.i83, 255
  %xor4.i = xor i32 %mul.i84, %shr.i
  %mul5.i = mul i32 %xor4.i, 16777619
  store i32 %mul5.i, ptr %checksum.i, align 4, !tbaa !46
  br label %if.end105

if.end105:                                        ; preds = %if.then97, %cond.end84
  %inc107 = add nuw nsw i32 %x53.091, 1
  %exitcond96.not = icmp eq i32 %inc107, 160
  br i1 %exitcond96.not, label %for.cond22, label %for.body58, !llvm.loop !83

for.end118:                                       ; preds = %for.cond22
  %cmp120.old = icmp eq i32 %mode, 1
  %or.cond6.old = and i1 %cmp120.old, %tobool17
  br i1 %or.cond6.old, label %if.then122, label %cleanup125

if.then122:                                       ; preds = %for.end118
  %36 = load i32, ptr %sphere_hits, align 4, !tbaa !30
  %pie_active_lanes = getelementptr inbounds %struct.raytrace_demo_stats, ptr %stats, i32 0, i32 6
  store i32 %36, ptr %pie_active_lanes, align 4, !tbaa !48
  br label %cleanup125

cleanup125:                                       ; preds = %for.cond.cleanup31, %for.end118, %if.then122
  %cmp2387 = phi i1 [ %cmp23, %for.end118 ], [ %cmp23, %if.then122 ], [ %cmp2393, %for.cond.cleanup31 ]
  call void @llvm.lifetime.end.p0(i64 640, ptr nonnull %colors) #11
  call void @llvm.lifetime.end.p0(i64 320, ptr nonnull %materials) #11
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %lamp) #11
  br label %cleanup128

cleanup128:                                       ; preds = %for.body, %land.lhs.true4.i, %land.lhs.true9.i, %land.lhs.true14.i, %cleanup125
  %retval.7 = phi i1 [ %cmp2387, %cleanup125 ], [ false, %land.lhs.true14.i ], [ false, %land.lhs.true9.i ], [ false, %land.lhs.true4.i ], [ false, %for.body ]
  call void @llvm.lifetime.end.p0(i64 2896, ptr nonnull %work) #11
  br label %return

return:                                           ; preds = %entry, %valid_output.exit, %cleanup128
  %retval.8 = phi i1 [ %retval.7, %cleanup128 ], [ false, %valid_output.exit ], [ false, %entry ]
  ret i1 %retval.8
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.abs.i32(i32, i1 immarg) #9

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr nocapture writeonly, i8, i32, i1 immarg) #8

declare dso_local void @raytrace_demo_pie_row(ptr noundef, ptr noundef, ptr noundef, i32 noundef) local_unnamed_addr #10

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #3 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #6 = { nofree norecurse nosync nounwind memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #11 = { nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"target-abi", !"ilp32f"}
!2 = !{i32 8, !"SmallDataLimit", i32 8}
!3 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!4 = !{!5, !6, i64 0}
!5 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12}
!6 = !{!"int", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C/C++ TBAA"}
!9 = !{!5, !6, i64 4}
!10 = !{!5, !6, i64 8}
!11 = !{!5, !6, i64 12}
!12 = !{!13, !6, i64 0}
!13 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !14, i64 16}
!14 = !{!"short", !7, i64 0}
!15 = !{!13, !6, i64 4}
!16 = !{!13, !6, i64 12}
!17 = !{!13, !6, i64 8}
!18 = !{!19, !6, i64 84}
!19 = !{!"", !7, i64 0, !6, i64 84, !7, i64 96, !7, i64 1056, !7, i64 1376, !7, i64 2402, !7, i64 2722}
!20 = !{i64 0, i64 4, !21, i64 4, i64 4, !21, i64 8, i64 4, !21, i64 12, i64 4, !21, i64 16, i64 4, !21, i64 20, i64 4, !21, i64 24, i64 4, !21, i64 28, i64 4, !21}
!21 = !{!22, !22, i64 0}
!22 = !{!"long", !7, i64 0}
!23 = !{i64 0, i64 4, !21, i64 4, i64 4, !21, i64 8, i64 4, !21, i64 12, i64 4, !21, i64 16, i64 4, !21, i64 20, i64 4, !21, i64 24, i64 4, !21}
!24 = !{i64 0, i64 4, !21, i64 4, i64 4, !21, i64 8, i64 4, !21, i64 12, i64 4, !21, i64 16, i64 4, !21, i64 20, i64 4, !21}
!25 = !{i64 0, i64 4, !21, i64 4, i64 4, !21, i64 8, i64 4, !21, i64 12, i64 4, !21, i64 16, i64 4, !21}
!26 = !{i64 0, i64 4, !21, i64 4, i64 4, !21, i64 8, i64 4, !21, i64 12, i64 4, !21}
!27 = !{i64 0, i64 4, !21, i64 4, i64 4, !21, i64 8, i64 4, !21}
!28 = !{i64 0, i64 4, !21, i64 4, i64 4, !21}
!29 = !{i64 0, i64 4, !21}
!30 = !{!31, !22, i64 8}
!31 = !{!"", !22, i64 0, !22, i64 4, !22, i64 8, !22, i64 12, !22, i64 16, !22, i64 20, !22, i64 24, !22, i64 28}
!32 = distinct !{!32, !33}
!33 = !{!"llvm.loop.mustprogress"}
!34 = !{!14, !14, i64 0}
!35 = !{!7, !7, i64 0}
!36 = !{!37, !6, i64 16}
!37 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !6, i64 16, !6, i64 20, !6, i64 24}
!38 = !{!37, !6, i64 20}
!39 = !{!37, !6, i64 24}
!40 = !{!37, !6, i64 8}
!41 = !{!37, !6, i64 0}
!42 = !{!37, !6, i64 4}
!43 = !{!37, !6, i64 12}
!44 = !{!31, !22, i64 12}
!45 = !{!31, !22, i64 16}
!46 = !{!31, !22, i64 28}
!47 = distinct !{!47, !33}
!48 = !{!31, !22, i64 24}
!49 = !{i64 0, i64 4, !50, i64 4, i64 4, !50, i64 8, i64 4, !50, i64 12, i64 4, !50, i64 16, i64 4, !50, i64 20, i64 4, !50, i64 24, i64 4, !50}
!50 = !{!6, !6, i64 0}
!51 = !{i64 0, i64 4, !50, i64 4, i64 4, !50, i64 8, i64 4, !50, i64 12, i64 4, !50, i64 16, i64 4, !50, i64 20, i64 4, !50}
!52 = !{i64 0, i64 4, !50, i64 4, i64 4, !50, i64 8, i64 4, !50, i64 12, i64 4, !50, i64 16, i64 4, !50}
!53 = !{i64 0, i64 4, !50, i64 4, i64 4, !50, i64 8, i64 4, !50, i64 12, i64 4, !50}
!54 = !{i64 0, i64 4, !50, i64 4, i64 4, !50, i64 8, i64 4, !50}
!55 = !{i64 0, i64 4, !50, i64 4, i64 4, !50}
!56 = !{i64 0, i64 4, !50}
!57 = distinct !{!57, !33}
!58 = distinct !{!58, !33}
!59 = !{!60, !6, i64 0}
!60 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !7, i64 16, !7, i64 28, !7, i64 40, !7, i64 52}
!61 = !{!60, !6, i64 4}
!62 = !{!60, !6, i64 8}
!63 = distinct !{!63, !33}
!64 = !{!60, !6, i64 12}
!65 = distinct !{!65, !33}
!66 = distinct !{!66, !33}
!67 = distinct !{!67, !33}
!68 = distinct !{!68, !33}
!69 = distinct !{!69, !33}
!70 = distinct !{!70, !33}
!71 = distinct !{!71, !33}
!72 = distinct !{!72, !33}
!73 = distinct !{!73, !33}
!74 = distinct !{!74, !33}
!75 = distinct !{!75, !33}
!76 = distinct !{!76, !33}
!77 = distinct !{!77, !33}
!78 = distinct !{!78, !33}
!79 = distinct !{!79, !33}
!80 = distinct !{!80, !33}
!81 = !{!13, !14, i64 16}
!82 = distinct !{!82, !33}
!83 = distinct !{!83, !33}
