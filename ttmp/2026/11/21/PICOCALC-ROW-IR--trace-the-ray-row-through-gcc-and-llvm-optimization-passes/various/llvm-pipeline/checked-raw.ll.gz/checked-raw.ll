; ModuleID = '/home/manuel/code/wesen/2026-10-20--ds-js-os/ttmp/2026/11/21/PICOCALC-ROW-IR--trace-the-ray-row-through-gcc-and-llvm-optimization-passes/scripts/01-row.c'
source_filename = "/home/manuel/code/wesen/2026-10-20--ds-js-os/ttmp/2026/11/21/PICOCALC-ROW-IR--trace-the-ray-row-through-gcc-and-llvm-optimization-passes/scripts/01-row.c"
target datalayout = "e-m:e-p:32:32-i64:64-n32-S128"
target triple = "riscv32-unknown-unknown-elf"

%struct.buffer = type { i32, [0 x i16] }

; Function Attrs: nounwind
define dso_local i32 @row(ptr noundef %work, i32 noundef %y) #0 {
entry:
  %work.addr = alloca ptr, align 4
  %y.addr = alloca i32, align 4
  %x = alloca i32, align 4
  %count = alloca i32, align 4
  %s = alloca i32, align 4
  %cleanup.dest.slot = alloca i32, align 4
  %obj = alloca i32, align 4
  %dy = alloca i32, align 4
  %cz = alloca i32, align 4
  %r = alloca i32, align 4
  %term = alloca i32, align 4
  %horizontal = alloca i32, align 4
  %x24 = alloca i32, align 4
  %d = alloca i32, align 4
  %z = alloca i32, align 4
  %old = alloca i32, align 4
  store ptr %work, ptr %work.addr, align 4
  store i32 %y, ptr %y.addr, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %x) #4
  store i32 0, ptr %x, align 4
  br label %for.cond

for.cond:                                         ; preds = %for.inc, %entry
  %0 = load i32, ptr %x, align 4
  %cmp = icmp slt i32 %0, 160
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  call void @llvm.lifetime.end.p0(i64 4, ptr %x) #4
  br label %for.end

for.body:                                         ; preds = %for.cond
  %1 = load ptr, ptr %work.addr, align 4
  %2 = load i32, ptr %x, align 4
  %add = add i32 1545, %2
  %call = call ptr @element(ptr noundef %1, i32 noundef %add) #5
  store i16 0, ptr %call, align 2
  %3 = load ptr, ptr %work.addr, align 4
  %4 = load i32, ptr %x, align 4
  %add1 = add i32 1705, %4
  %call2 = call ptr @element(ptr noundef %3, i32 noundef %add1) #5
  store i16 0, ptr %call2, align 2
  br label %for.inc

for.inc:                                          ; preds = %for.body
  %5 = load i32, ptr %x, align 4
  %inc = add i32 %5, 1
  store i32 %inc, ptr %x, align 4
  br label %for.cond, !llvm.loop !4

for.end:                                          ; preds = %for.cond.cleanup
  call void @llvm.lifetime.start.p0(i64 4, ptr %count) #4
  %6 = load ptr, ptr %work.addr, align 4
  %call3 = call ptr @element(ptr noundef %6, i32 noundef 16) #5
  %7 = load i16, ptr %call3, align 2
  %conv = zext i16 %7 to i32
  store i32 %conv, ptr %count, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %s) #4
  store i32 0, ptr %s, align 4
  br label %for.cond4

for.cond4:                                        ; preds = %for.inc57, %for.end
  %8 = load i32, ptr %s, align 4
  %9 = load i32, ptr %count, align 4
  %cmp5 = icmp slt i32 %8, %9
  br i1 %cmp5, label %for.body8, label %for.cond.cleanup7

for.cond.cleanup7:                                ; preds = %for.cond4
  store i32 5, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %s) #4
  br label %for.end59

for.body8:                                        ; preds = %for.cond4
  call void @llvm.lifetime.start.p0(i64 4, ptr %obj) #4
  %10 = load i32, ptr %s, align 4
  %mul = mul i32 5, %10
  %add9 = add i32 1, %mul
  store i32 %add9, ptr %obj, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %dy) #4
  %11 = load i32, ptr %y.addr, align 4
  %12 = load ptr, ptr %work.addr, align 4
  %13 = load i32, ptr %obj, align 4
  %add10 = add i32 %13, 1
  %call11 = call ptr @element(ptr noundef %12, i32 noundef %add10) #5
  %14 = load i16, ptr %call11, align 2
  %conv12 = zext i16 %14 to i32
  %sub = sub i32 %11, %conv12
  store i32 %sub, ptr %dy, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %cz) #4
  %15 = load ptr, ptr %work.addr, align 4
  %16 = load i32, ptr %obj, align 4
  %add13 = add i32 %16, 2
  %call14 = call ptr @element(ptr noundef %15, i32 noundef %add13) #5
  %17 = load i16, ptr %call14, align 2
  %conv15 = zext i16 %17 to i32
  store i32 %conv15, ptr %cz, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %r) #4
  %18 = load ptr, ptr %work.addr, align 4
  %19 = load i32, ptr %obj, align 4
  %add16 = add i32 %19, 3
  %call17 = call ptr @element(ptr noundef %18, i32 noundef %add16) #5
  %20 = load i16, ptr %call17, align 2
  %conv18 = zext i16 %20 to i32
  store i32 %conv18, ptr %r, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %term) #4
  %21 = load i32, ptr %r, align 4
  %22 = load i32, ptr %r, align 4
  %mul19 = mul i32 %21, %22
  %23 = load i32, ptr %dy, align 4
  %24 = load i32, ptr %dy, align 4
  %mul20 = mul i32 %23, %24
  %sub21 = sub i32 %mul19, %mul20
  store i32 %sub21, ptr %term, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %horizontal) #4
  %25 = load i32, ptr %s, align 4
  %mul22 = mul i32 %25, 160
  %add23 = add i32 40, %mul22
  store i32 %add23, ptr %horizontal, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %x24) #4
  store i32 0, ptr %x24, align 4
  br label %for.cond25

for.cond25:                                       ; preds = %for.inc54, %for.body8
  %26 = load i32, ptr %x24, align 4
  %cmp26 = icmp slt i32 %26, 160
  br i1 %cmp26, label %for.body29, label %for.cond.cleanup28

for.cond.cleanup28:                               ; preds = %for.cond25
  store i32 8, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %x24) #4
  br label %for.end56

for.body29:                                       ; preds = %for.cond25
  call void @llvm.lifetime.start.p0(i64 4, ptr %d) #4
  %27 = load i32, ptr %term, align 4
  %28 = load ptr, ptr %work.addr, align 4
  %29 = load i32, ptr %horizontal, align 4
  %30 = load i32, ptr %x24, align 4
  %add30 = add i32 %29, %30
  %call31 = call ptr @element(ptr noundef %28, i32 noundef %add30) #5
  %31 = load i16, ptr %call31, align 2
  %conv32 = zext i16 %31 to i32
  %sub33 = sub i32 %27, %conv32
  store i32 %sub33, ptr %d, align 4
  %32 = load i32, ptr %d, align 4
  %cmp34 = icmp sge i32 %32, 0
  br i1 %cmp34, label %if.then, label %if.end53

if.then:                                          ; preds = %for.body29
  call void @llvm.lifetime.start.p0(i64 4, ptr %z) #4
  %33 = load i32, ptr %cz, align 4
  %34 = load ptr, ptr %work.addr, align 4
  %35 = load i32, ptr %d, align 4
  %add36 = add i32 520, %35
  %call37 = call ptr @element(ptr noundef %34, i32 noundef %add36) #5
  %36 = load i16, ptr %call37, align 2
  %conv38 = zext i16 %36 to i32
  %sub39 = sub i32 %33, %conv38
  store i32 %sub39, ptr %z, align 4
  call void @llvm.lifetime.start.p0(i64 4, ptr %old) #4
  %37 = load ptr, ptr %work.addr, align 4
  %38 = load i32, ptr %x24, align 4
  %add40 = add i32 1545, %38
  %call41 = call ptr @element(ptr noundef %37, i32 noundef %add40) #5
  %39 = load i16, ptr %call41, align 2
  %conv42 = zext i16 %39 to i32
  store i32 %conv42, ptr %old, align 4
  %40 = load i32, ptr %old, align 4
  %tobool = icmp ne i32 %40, 0
  br i1 %tobool, label %lor.lhs.false, label %if.then45

lor.lhs.false:                                    ; preds = %if.then
  %41 = load i32, ptr %z, align 4
  %42 = load i32, ptr %old, align 4
  %cmp43 = icmp slt i32 %41, %42
  br i1 %cmp43, label %if.then45, label %if.end

if.then45:                                        ; preds = %lor.lhs.false, %if.then
  %43 = load i32, ptr %z, align 4
  %conv46 = trunc i32 %43 to i16
  %44 = load ptr, ptr %work.addr, align 4
  %45 = load i32, ptr %x24, align 4
  %add47 = add i32 1545, %45
  %call48 = call ptr @element(ptr noundef %44, i32 noundef %add47) #5
  store i16 %conv46, ptr %call48, align 2
  %46 = load i32, ptr %s, align 4
  %add49 = add i32 %46, 1
  %conv50 = trunc i32 %add49 to i16
  %47 = load ptr, ptr %work.addr, align 4
  %48 = load i32, ptr %x24, align 4
  %add51 = add i32 1705, %48
  %call52 = call ptr @element(ptr noundef %47, i32 noundef %add51) #5
  store i16 %conv50, ptr %call52, align 2
  br label %if.end

if.end:                                           ; preds = %if.then45, %lor.lhs.false
  call void @llvm.lifetime.end.p0(i64 4, ptr %old) #4
  call void @llvm.lifetime.end.p0(i64 4, ptr %z) #4
  br label %if.end53

if.end53:                                         ; preds = %if.end, %for.body29
  call void @llvm.lifetime.end.p0(i64 4, ptr %d) #4
  br label %for.inc54

for.inc54:                                        ; preds = %if.end53
  %49 = load i32, ptr %x24, align 4
  %inc55 = add i32 %49, 1
  store i32 %inc55, ptr %x24, align 4
  br label %for.cond25, !llvm.loop !6

for.end56:                                        ; preds = %for.cond.cleanup28
  call void @llvm.lifetime.end.p0(i64 4, ptr %horizontal) #4
  call void @llvm.lifetime.end.p0(i64 4, ptr %term) #4
  call void @llvm.lifetime.end.p0(i64 4, ptr %r) #4
  call void @llvm.lifetime.end.p0(i64 4, ptr %cz) #4
  call void @llvm.lifetime.end.p0(i64 4, ptr %dy) #4
  call void @llvm.lifetime.end.p0(i64 4, ptr %obj) #4
  br label %for.inc57

for.inc57:                                        ; preds = %for.end56
  %50 = load i32, ptr %s, align 4
  %inc58 = add i32 %50, 1
  store i32 %inc58, ptr %s, align 4
  br label %for.cond4, !llvm.loop !7

for.end59:                                        ; preds = %for.cond.cleanup7
  store i32 1, ptr %cleanup.dest.slot, align 4
  call void @llvm.lifetime.end.p0(i64 4, ptr %count) #4
  ret i32 1
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: inlinehint nounwind
define internal ptr @element(ptr noundef %work, i32 noundef %index) #2 {
entry:
  %work.addr = alloca ptr, align 4
  %index.addr = alloca i32, align 4
  store ptr %work, ptr %work.addr, align 4
  store i32 %index, ptr %index.addr, align 4
  %0 = load i32, ptr %index.addr, align 4
  %1 = load ptr, ptr %work.addr, align 4
  %capacity = getelementptr inbounds %struct.buffer, ptr %1, i32 0, i32 0
  %2 = load i32, ptr %capacity, align 4
  %cmp = icmp uge i32 %0, %2
  br i1 %cmp, label %if.then, label %if.end

if.then:                                          ; preds = %entry
  call void @llvm.trap()
  br label %if.end

if.end:                                           ; preds = %if.then, %entry
  %3 = load ptr, ptr %work.addr, align 4
  %data = getelementptr inbounds %struct.buffer, ptr %3, i32 0, i32 1
  %arraydecay = getelementptr inbounds [0 x i16], ptr %data, i32 0, i32 0
  %4 = load i32, ptr %index.addr, align 4
  %add.ptr = getelementptr i16, ptr %arraydecay, i32 %4
  ret ptr %add.ptr
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #3

attributes #0 = { nounwind "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { inlinehint nounwind "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic-rv32" "target-features"="+32bit,+a,+c,+f,+m,+relax,+zicsr,-d,-e,-experimental-zacas,-experimental-zcmop,-experimental-zfbfmin,-experimental-zicfilp,-experimental-zicfiss,-experimental-zimop,-experimental-ztso,-experimental-zvfbfmin,-experimental-zvfbfwma,-h,-smaia,-smepmp,-ssaia,-svinval,-svnapot,-svpbmt,-v,-xcvalu,-xcvbi,-xcvbitmanip,-xcvelw,-xcvmac,-xcvmem,-xcvsimd,-xsfvcp,-xsfvfnrclipxfqf,-xsfvfwmaccqqq,-xsfvqmaccdod,-xsfvqmaccqoq,-xtheadba,-xtheadbb,-xtheadbs,-xtheadcmo,-xtheadcondmov,-xtheadfmemidx,-xtheadmac,-xtheadmemidx,-xtheadmempair,-xtheadsync,-xtheadvdot,-xventanacondops,-za128rs,-za64rs,-zawrs,-zba,-zbb,-zbc,-zbkb,-zbkc,-zbkx,-zbs,-zca,-zcb,-zcd,-zce,-zcf,-zcmp,-zcmt,-zdinx,-zfa,-zfh,-zfhmin,-zfinx,-zhinx,-zhinxmin,-zic64b,-zicbom,-zicbop,-zicboz,-ziccamoa,-ziccif,-zicclsm,-ziccrse,-zicntr,-zicond,-zifencei,-zihintntl,-zihintpause,-zihpm,-zk,-zkn,-zknd,-zkne,-zknh,-zkr,-zks,-zksed,-zksh,-zkt,-zmmul,-zvbb,-zvbc,-zve32f,-zve32x,-zve64d,-zve64f,-zve64x,-zvfh,-zvfhmin,-zvkb,-zvkg,-zvkn,-zvknc,-zvkned,-zvkng,-zvknha,-zvknhb,-zvks,-zvksc,-zvksed,-zvksg,-zvksh,-zvkt,-zvl1024b,-zvl128b,-zvl16384b,-zvl2048b,-zvl256b,-zvl32768b,-zvl32b,-zvl4096b,-zvl512b,-zvl64b,-zvl65536b,-zvl8192b" }
attributes #3 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #4 = { nounwind }
attributes #5 = { nobuiltin "no-builtins" }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 1, !"target-abi", !"ilp32f"}
!2 = !{i32 8, !"SmallDataLimit", i32 8}
!3 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!4 = distinct !{!4, !5}
!5 = !{!"llvm.loop.mustprogress"}
!6 = distinct !{!6, !5}
!7 = distinct !{!7, !5}
